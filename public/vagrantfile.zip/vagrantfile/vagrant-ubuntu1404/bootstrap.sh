#!/usr/bin/env bash

set -e

apt-get update

apt-get -y install \
		apache2 \
		php5 \
		php5-mysql \
		php5-dev \
		php5-mcrypt \
		php5-curl \
		php5-imagick \
		php5-xdebug \
		php5-memcached \
		php5-memcache \
		php5-gd \
		php-apc \
		git \
		make \
		curl \
		vim

echo 'mysql-server-5.6 mysql-server/root_password password root1234' | debconf-set-selections
echo 'mysql-server-5.6 mysql-server/root_password_again password root1234' | debconf-set-selections

apt-get -y install \
		mysql-server-5.6 \
		redis-server \
		memcached	

# install php-redis
if [ ! -d "/tmp/phpredis" ]; then
	git clone https://github.com/nicolasff/phpredis.git /tmp/phpredis
	cd /tmp/phpredis && /usr/bin/phpize && ./configure && make && make install
fi
# enable redis
echo "extension=redis.so" > /etc/php5/apache2/conf.d/redis.ini
echo "extension=redis.so" > /etc/php5/cli/conf.d/redis.ini
# enable mcrypt
echo "extension=mcrypt.so" > /etc/php5/apache2/conf.d/mcrypt.ini
echo "extension=mcrypt.so" > /etc/php5/cli/conf.d/mcrypt.ini

# set servername
echo "ServerName localhost" >> /etc/apache2/apache2.conf
# set apache evn to development
echo "SetEnv APPLICATION_ENV 'development'" >> /etc/apache2/apache2.conf
# copy mysql's config files 
cp /home/vagrant/mysql-server-setup/my.cnf /etc/mysql/conf.d/my.cnf
chmod 664 /etc/mysql/conf.d/my.cnf
cp /home/vagrant/mysql-server-setup/run.sh /usr/local/bin/run
chmod +x /usr/local/bin/run
# run setup db and user for mysql
bash /usr/local/bin/run

# enable apache modules
a2enmod rewrite; a2enmod expires; a2enmod auth_basic; a2enmod headers; a2enmod deflate; a2enmod env; a2enmod rewrite;
# enable .htaccess file
sed -i "10 i\
	<Directory \"/var/www/html\"> \\
	    AllowOverride All \\
	</Directory> \\
\
" /etc/apache2/sites-available/000-default.conf
#sed -i '11s/AllowOverride None/AllowOverride All/'  /etc/apache2/sites-available/default

service apache2 reload

chmod 777 -R /var/www/html/platform/app/tmp/
chmod 777 -R /var/www/html/platform/app/webroot/img/Upload/

echo "<?php \$_SERVER['APPLICATION_ENV'] = 'development';" > /var/www/html/platform/hiddenconfig.php
