Vagrant installs all requirement softwares, and complications and help team can develop on same environment. With example database was included with box, everyone can see immediately how do platform work on localhost.

Requirements:
-------------
 - On Windows, get git-bash by install git-preview http://git-scm.com/download/win
 - Install VirtualBox: https://www.virtualbox.org
 - Install Vagrant: http://www.vagrantup.com/
 - (Optional , use with Mobgame's platform): you must have platform's source code: https://github.com/Mobgame/plf/ , and copied `app/Config/.php.default -> app/Config/.php` , do same another apps: stats, ads,.. as you need.

Installation:
-------------
 - Rename `vagrant/Vagrantfile.default` to `vagrant/Vagrantfile`
 - Change this line: `config.vm.synced_folder "/var/www/d", "/var/www/platform/"` to `config.vm.synced_folder "/path/to/your/projects/", "/var/www/platform/"`. 
 - Run `git-bash` was installed from above requirements, navigate to `vagrant` folder, then type `vagrant up`, this process takes about 15-30 minutes to complete, depends on your network.
 - `git config core.fileMode false`
 - `tmp` and `app/webroot/img/Upload` folders must be writable by apache (chmod -R 777 when you can't do it). If you install box on windows then can ignore this step.

How does it work:
-----------------
- Enter http://localhost:8088/platform/ on browser at host machine (your computer are using ).
- Access database from GUI,
    + hostname: 127.0.0.1
    + port: 3307
    + usename: platform-admin
    + password: platform123
    + default-database(optional): platform
- `vagrant ssh` this command will SSH into running box.

How to improve Vagrant performance:
-----------------------------------

**LINUX**  
The host machine must have nfsd installed, the NFS server daemon. This comes pre-installed on Mac OS X, and is typically a simple package install on Linux.  
https://docs.vagrantup.com/v2/synced-folders/nfs.html  
`type: "nfs"`

**WINDOWS**  
https://www.vagrantup.com/docs/synced-folders/smb.html  
`type: "smb",  mount_options: ["dir_mode=0777,file_mode=0777"], smb_username: "{your Windows username}", smb_password: "{your Windows password}" `  
	

Error happen while installation
-------------------------
`
Failed to mount folders in Linux guest. This is usually because
the "vboxsf" file system is not available. Please verify that
the guest additions are properly installed in the guest and
can work properly. The command attempted was .....
`  
Try to fix that problem by ssh in vagrant box `vagrant ssh` then run command:  
`sudo ln -s /opt/VBoxGuestAdditions-4.3.10/lib/VBoxGuestAdditions /usr/lib/VBoxGuestAdditions`   
, continue to install by exit box and run `vagrant provision`.  
this is a virtualbox's problem.

