import {
    GET_GAMES_PLAYED,
    GET_ERROR_GAMES,
    GET_GAMES_CANCELLED,
    MERGE_DATA_GAMES,
    RESET_DATA_GAMES    
} from '../constants/gamesType';

export const getGamesPlayed = () => ({
    type:GET_GAMES_PLAYED
})
export const getErrorGames = (error) => ({
    type:GET_ERROR_GAMES,
    error    
})
export const getGameCancelled = () => ({
    type:GET_GAMES_CANCELLED    
})
export const mergeDataGames = (data) => ({
    type:MERGE_DATA_GAMES,
    payload:data
})
export const resetDataGames = () => ({
    type:RESET_DATA_GAMES    
})