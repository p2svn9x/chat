import {
    USER_LOGGED,
    USER_LOGOUT,
    CHANGE_USER_PROFILE,
    CHANGE_USER_SECURITY,
    CHANGE_USER_FUNCOIN,
    GET_USER_INFO,
    GET_USER_CANCELLED,
    CHANGE_USER_PAYMENT,
    CHANGE_USER_REWARD,
    CHANGE_USER_ACCOUNT,
    CLEAR_USER_INFO,
    USER_CLAIM_REWARD
} from '../constants/userType';

export const clearUserInfo = () => ({
    type:CLEAR_USER_INFO
})
export const getUserInfo = (token) => ({
    type:GET_USER_INFO,
    payload:{token}
})
export const getUserCancelled = () => ({
    type:GET_USER_CANCELLED    
})
export const userLogged = (user) => ({
    type:USER_LOGGED,
    payload:user
})
export const userLogout = () => ({
    type:USER_LOGOUT    
})
export const change_user_account = (data) => ({
    type:CHANGE_USER_ACCOUNT,    
    data
})
export const change_user_profile = (data) => ({
    type:CHANGE_USER_PROFILE,    
    data
})
export const change_user_security = (data) => ({
    type:CHANGE_USER_SECURITY,    
    data
})
export const change_user_payment = (data) => ({
    type:CHANGE_USER_PAYMENT,
    data
})
export const change_user_reward = (data) => ({
    type:CHANGE_USER_REWARD,
    data
})
export const change_user_funcoin = (data) => ({
    type:CHANGE_USER_FUNCOIN,
    data
})
export const claimReward = (type) => ({
    type:USER_CLAIM_REWARD,
    payload:{type}
})
