import {
    SYNC_DIRECTION,
    SYNC_ERROR_DIRECTION,
    MERGE_DATA_DIRECTION
} from '../constants/directionType';

export const syncDirection = () => ({
    type: SYNC_DIRECTION
})
export const syncErrorDirection = (error) => ({
    type: SYNC_ERROR_DIRECTION,
    error
})
export const mergeDataDirection = (data) => ({
    type: MERGE_DATA_DIRECTION,
    data
})

