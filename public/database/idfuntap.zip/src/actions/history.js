import {
    INIT_HISTORY_PAYMENT,
    GET_HISTORY_PAYMENT,
    SYNC_HISTORY_PAYMENT,
    SYNC_ERROR_HISTORY,
    SYNC_HISTORY_CANCELLED,
    MERGE_DATA_HISTORY,
    RESET_DATA_HISTORY   
} from '../constants/historyType';
export const initHistoryPayment = (type) => ({
    type:INIT_HISTORY_PAYMENT,
    meta:{type}
})
export const getHistoryPayment = (type,api) => ({
    type:GET_HISTORY_PAYMENT,
    meta:{
        type,
        api        
    }
})
export const syncHistoryPayment = (type,api,page) => ({
    type:SYNC_HISTORY_PAYMENT,
    payload:{page},
    meta:{
        type,
        api        
    }
})
export const syncErrorHistory = (type,error) => ({
    type:SYNC_ERROR_HISTORY,
    error,
    meta:{type}
})
export const syncHistoryCancelled = (type) => ({
    type:SYNC_HISTORY_CANCELLED,
    meta:{type}
})
export const mergeDataHistory = (type,data) => ({
    type:MERGE_DATA_HISTORY,
    payload:data,
    meta:{type}
})
export const resetDataHistory = () => ({
    type:RESET_DATA_HISTORY   
})

