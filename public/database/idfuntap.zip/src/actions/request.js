import {CREATE_VERIFY_CODE,CHANGE_SECURITY_INFO,SET_NEW_SECURITY,CREATE_CODE_SET_SECURITY, CHANGE_STATUS_2STEP, REQUEST_CONNECT_FACEBOOK, REQUEST_LOGIN_FACEBOOK, REQUEST_UPDATE_PASSWORD} from '../constants/requestType';

export const createVerifyCode = (type,api,callback) => ({
    type:CREATE_VERIFY_CODE,
    meta:{
        type,
        api,
        callback
    }
})
export const requestChangeSecurity = (callback) => ({
    type:CHANGE_SECURITY_INFO,
    meta:{callback}
})
export const requestSetNewEmail = (callback) => ({
    type:SET_NEW_SECURITY,
    meta:{type:'email',callback}
})
export const requestSetNewPhone = (callback) => ({
    type:SET_NEW_SECURITY,
    meta:{type:'phone',callback}
})
export const createCodeSetSecurity = (api,callback) => ({
    type:CREATE_CODE_SET_SECURITY,
    meta:{api,callback}
})
export const changeStatus2Step = (status,callback) => ({
    type:CHANGE_STATUS_2STEP,
    payload:{status},
    meta:{callback}
})
export const requestConnectFacebook = (accessToken,callback) => ({
    type:REQUEST_CONNECT_FACEBOOK,
    payload:{accessToken},
    meta:{callback}
})
export const requestLoginFacebook = (accessToken,callback) => ({
    type:REQUEST_LOGIN_FACEBOOK,
    payload:{accessToken},
    meta:{callback}
})
export const requestUpdatePassword = (callback) => ({
    type:REQUEST_UPDATE_PASSWORD,   
    meta:{callback}
})
// export const resendVerifyCode = (api,callback) => ({
//     type:RESEND_VERIFY_CODE,
//     meta:{
//         api,
//         callback
//     }
// })