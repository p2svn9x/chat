import {
    GET_RECENT_DEVICES,
    GET_ERROR_DEVICES,
    GET_DEVICES_CANCELLED,
    MERGE_DATA_DEVICES,
    REMOVE_TRUSTED_DEVICE,
    RESET_DATA_DEVICES   
} from '../constants/devicesType';

export const getRecentDevices = () => ({
    type:GET_RECENT_DEVICES    
})
export const getDevicesCancelled = () => ({
    type:GET_DEVICES_CANCELLED    
})
export const getErrorDevices = (error) => ({
    type:GET_ERROR_DEVICES,
    error    
})
export const mergeDataDevices = (data) => ({
    type:MERGE_DATA_DEVICES,
    payload:data
})
export const removeTrustedDevice = (deviceId,callback) => ({
    type:REMOVE_TRUSTED_DEVICE,
    payload:deviceId,
    meta:{callback}
})
export const resetDataDevices = () => ({
    type:RESET_DATA_DEVICES
})