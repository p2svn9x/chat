import {
    SYNC_HISTORY_TOPUP,
    SYNC_ERROR_HISTORY_TOPUP,
    IMPORT_HISTORY_TOPUP,
    CLEAR_HISTORY_TOPUP,
    SYNC_ENDED_HISTORY_TOPUP,
    RESET_HISTORY_TOPUP,
    CREATE_SHORT_HISTORY_TOPUP,
    IMPORT_SHORT_HISTORY_TOPUP
} from '../constants/topupType';
export const sync_history_topup = () => ({
    type:SYNC_HISTORY_TOPUP
})
export const sync_error_history_topup = (error) => ({
    type:SYNC_ERROR_HISTORY_TOPUP,
    error
})
export const import_history_topup = (data) => ({
    type:IMPORT_HISTORY_TOPUP,
    data
})
export const clear_history_topup = () => ({
    type:CLEAR_HISTORY_TOPUP    
})
export const sync_ended_history_topup = () => ({
    type:SYNC_ENDED_HISTORY_TOPUP    
})
export const reset_history_topup = () => ({
    type:RESET_HISTORY_TOPUP    
})
export const create_short_history_topup = () => ({
    type:CREATE_SHORT_HISTORY_TOPUP    
})
export const import_short_history_topup = (history) => ({
    type:IMPORT_SHORT_HISTORY_TOPUP,
    history    
})