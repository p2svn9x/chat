import {
    SUBMIT_FORM_PERSONAL,
    SUBMIT_VERIFY_PASSWORD,
    SUBMIT_FORM_VERIFY_CODE,  
    SUBMIT_UPDATE_SECURITY,  
    SUBMIT_UPDATE_PASSWORD,
    SUBMIT_FORM_LOGIN,
    SUBMIT_CANCEL,
    //SUBMIT_LOGIN_USE_FACEBOOK,
    SUBMIT_METHOD_RECOVERY,
    SUBMIT_VERIFY_METHOD_RECOVERY
} from '../constants/submitType';

export const submitFormPersonal = (payload,resolve,reject) => ({
    type:SUBMIT_FORM_PERSONAL,   
    payload,
    meta:{        
        resolve,
        reject
    } 
})
export const submitFormVerifyCode = (payload,api,callback) => ({
    type:SUBMIT_FORM_VERIFY_CODE,   
    payload,
    meta:{
        api,
        callback
    } 
})
export const submitVerifyPassword = (payload,resolve,reject) => ({
    type:SUBMIT_VERIFY_PASSWORD,    
    payload,
    meta:{
        resolve,
        reject
    }    
})
export const submitUpdateSecurity = (api,resolve,reject) => ({
    type:SUBMIT_UPDATE_SECURITY, 
    meta:{
        api,
        resolve,
        reject
    }    
})
export const submitUpdatePassword = (api,callback) => ({
    type:SUBMIT_UPDATE_PASSWORD,    
    meta:{
        api,
        callback
    }
})
export const submitFormLogin = (data,callback) => ({
    type:SUBMIT_FORM_LOGIN,
    payload:{
        data
    },
    meta:{
        callback
    }
})

export const submitMethodRecovery = (data,callback) => ({
    type:SUBMIT_METHOD_RECOVERY,
    payload:{
        data
    },
    meta:{
        callback
    }
})

export const submitVerifyMethodRecovery = (data,userId,callback) => ({
    type:SUBMIT_VERIFY_METHOD_RECOVERY,
    payload:{
        data,
        userId
    },
    meta:{
        callback
    }
})

export const submitCancel = () => ({
    type:SUBMIT_CANCEL
})