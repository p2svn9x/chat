import {
    CREATE_BROWSER_ID,
    SET_BROWSER_ID  
} from '../constants/browserType';

export const createBrowserId = () => ({
    type:CREATE_BROWSER_ID    
})
export const setBrowserId = (id) => ({
    type:SET_BROWSER_ID,
    payload:{id}   
})

