import {
    CREATED_CODE_NEW_PHONE,
    REMOVE_CODE_NEW_PHONE,
    CREATED_CODE_OLD_PHONE,
    REMOVE_CODE_OLD_PHONE,
    CREATED_CODE_NEW_EMAIL,   
    REMOVE_CODE_NEW_EMAIL,
    CREATED_CODE_OLD_EMAIL,
    REMOVE_CODE_OLD_EMAIL,
    MERGE_DATA_TEMPORARY,    
    RESET_DATA_TEMPORARY,
    MEGRE_USER_TEMPORARY
} from '../constants/temporaryType';

export const createdCodeNewPhone = (time,phone) => ({
    type:CREATED_CODE_NEW_PHONE,
    payload:{
        time,
        phone
    }
})
export const removeCodeNewPhone = () => ({
    type:REMOVE_CODE_NEW_PHONE
})
export const createdCodeOldPhone = (time) => ({
    type:CREATED_CODE_OLD_PHONE,
    payload:{time}
})
export const removeCodeOldPhone = () => ({
    type:REMOVE_CODE_OLD_PHONE
})

export const createdCodeNewEmail = (time,email) => ({
    type:CREATED_CODE_NEW_EMAIL,
    payload:{
        time,
        email
    }
})
export const removeCodeNewEmail = () => ({
    type:REMOVE_CODE_NEW_EMAIL
})
export const createdCodeOldEmail = (time) => ({
    type:CREATED_CODE_OLD_EMAIL,
    payload:{time}
})
export const removeCodeOldEmail = () => ({
    type:REMOVE_CODE_OLD_EMAIL
})
export const mergeDataTemporary = (data) => ({
    type:MERGE_DATA_TEMPORARY,
    payload:{data}
})
export const mergeUserTemporary = (data) => ({
    type:MEGRE_USER_TEMPORARY,
    payload:{data}
})
export const resetDataTemporary = () => ({
    type:RESET_DATA_TEMPORARY    
})