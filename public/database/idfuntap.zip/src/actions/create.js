import {CREATE_VERIFY_CODE,RESEND_VERIFY_CODE} from '../constants/requestType';

export const createVerifyCode = (api,callback) => ({
    type:CREATE_VERIFY_CODE,  
    meta:{
        api,
        callback
    } 
})
export const resendVerifyCode = (api,callback) => ({
    type:RESEND_VERIFY_CODE,  
    meta:{
        api,
        callback
    } 
})