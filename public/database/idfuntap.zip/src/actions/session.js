import {
    SET_SESSION_OTP,
    REMOVE_SESSION_OTP,
    SET_SESSION_PASSWORD,
    REMOVE_SESSION_PASSWORD,        
    RESET_DATA_SESSION
} from '../constants/sessionType';

export const setSessionPassword = (payload) => ({
    type:SET_SESSION_PASSWORD,
    payload
})
export const removeSessionPassword = () => ({
    type:REMOVE_SESSION_PASSWORD    
})
export const setSessionOTP = (payload) => ({
    type:SET_SESSION_OTP,
    payload
})
export const removeSessionOTP = () => ({
    type:REMOVE_SESSION_OTP    
})
export const resetDataSession = () => ({
    type:RESET_DATA_SESSION    
})
