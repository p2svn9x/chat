import 'rxjs';
import {CREATE_BROWSER_ID} from '../constants/browserType';
//import {empty} from '../actions/empty';
//import { map,catchError} from 'rxjs/operators';
//import {import_browser_id} from '../actions/browser';
import MD5 from 'md5';
import { setBrowserId } from '../actions/browser';


function fingerprint() {
    var e = (new Date()).getTime();
    return window.performance && "function" == typeof window.performance.now && (e += performance.now()), "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
        var n = (e + 16 * Math.random()) % 16 | 0;
        return e = Math.floor(e / 16), ("x" == t ? n : 3 & n | 8).toString(16)
    })
}
function createBID() {
    let fgprt = fingerprint();
    return `${fgprt}-${MD5(navigator.userAgent)}`
}

export const createBrowserIdEpic = (action$) => 
    action$.ofType(CREATE_BROWSER_ID).map(() => {
        try {
            if (!!window.localStorage && localStorage.getItem('BID')){               
                let bid = localStorage.getItem('BID');                           
                return setBrowserId(bid)                   
            } else {               
                return setBrowserId(createBID())
            }
        } catch(err){             
            return setBrowserId(createBID())
        }              
    })
