import 'rxjs';
import { of } from 'rxjs/observable/of';
import { concat } from 'rxjs/observable/concat';
import { flatMap,map,catchError,takeUntil,retry } from 'rxjs/operators';
import {
    GET_USER_INFO,
    USER_LOGOUT, 
    USER_CLAIM_REWARD,
    CLAIM_REWARD_SERVER, 
    USER_LOGGED,     
    CLEAR_USER_INFO
} from '../constants/userType';
import {     
    change_user_funcoin,
    change_user_reward,    
    getUserCancelled,
    clearUserInfo,
    userLogged,
    change_user_security
} from '../actions/user';
import {resetDataDevices} from '../actions/devices';
import {resetDataGames} from '../actions/games';
import {resetDataHistory} from '../actions/history';

import {
    resetDataSession,
    setSessionOTP,
    setSessionPassword
} from '../actions/session';
import {
    createdCodeNewPhone,
    createdCodeOldPhone,
    createdCodeNewEmail,
    createdCodeOldEmail,
    mergeDataTemporary,
    resetDataTemporary
} from '../actions/temporary';

import {empty} from '../actions/empty';
import {logout,get_userinfo} from '../configs/api';
import {getUserInfo, getSessionFromStorage, getTmpFromStorage} from '../helpers/filters';

//import {isNumber} from '../helpers/validate';

function initSessionUser(action,payload){
    if (!payload){
        return of(empty())
    }
    return of(action(payload))
}
function initCreatedCodeUser(action,payload){
    if (!payload.time){
       return of(empty())
    }    
    return of(action(payload.time,payload.phone || payload.email))
}
function initChangedSecurity(data){
    if (!data.newEmail && !data.newPhone){
        return of(empty())
    }
    return of(change_user_security({new_email:data.newEmail || null,new_phone:data.newPhone || null}))    
}
export const getUserEpic = (action$) => 
    action$.ofType(GET_USER_INFO).mergeMap((action) => {
        const tokenLogged = action.payload.token || '';                     
        return get_userinfo(tokenLogged).pipe(            
            flatMap((r) => {
                const response = r.response;
                try {
                    if (!!response.error){                        
                        return of(getUserCancelled())
                    } else if (response.status === 200 && !!response.data){
                        const secretKey = response.data.Account ? (response.data.Account.id || null) : null;
                        let session = getSessionFromStorage(secretKey);
                        let tmp = getTmpFromStorage(secretKey);  
                        return concat(
                            of(userLogged(response.data)),
                            initSessionUser(setSessionOTP,session.lastVerifiedOTP),
                            initSessionUser(setSessionPassword,session.lastVerifiedPassword),
                            of(mergeDataTemporary(tmp)),
                            initChangedSecurity({newEmail:tmp.newEmail,newPhone:tmp.newPhone}),
                            initCreatedCodeUser(createdCodeNewEmail,{time:tmp.createdCodeNewEmail,email:tmp.newEmail || null}),
                            initCreatedCodeUser(createdCodeOldEmail,{time:tmp.createdCodeOldEmail}),
                            initCreatedCodeUser(createdCodeNewPhone,{time:tmp.createdCodeNewPhone,phone:tmp.newPhone || null}),
                            initCreatedCodeUser(createdCodeOldPhone,{time:tmp.createdCodeOldPhone}),
                        )
                    } else {                        
                        return of(getUserCancelled())
                    }
                } catch(err){                    
                    return of(getUserCancelled())
                }
            }),              
            retry(2),
            catchError(() => {                
                return of(getUserCancelled())
            })
        )         
    })

export const userLoggedEpic = action$ => 
    action$.ofType(USER_LOGGED).map(() => {  
        console.log('user logged');  
        return empty()
    })
    
export const userLogoutEpic = (action$) => 
    action$.ofType(USER_LOGOUT).mergeMap(() => 
        logout().pipe(
                map(() => {
                    return clearUserInfo()  
                }),
                takeUntil(action$.ofType(USER_LOGOUT)),
                catchError(() => of(getUserCancelled())
            )
        )
    )
export const clearUserInfoEpic = (action$) => 
    action$.ofType(CLEAR_USER_INFO).flatMap(() =>  
        of(
            resetDataHistory(),           
            resetDataGames(),
            resetDataTemporary(),
            resetDataDevices(),
            resetDataSession()
        )        
    )
const claimRewardFromServer = () => ({type:CLAIM_REWARD_SERVER});
export const userClaimRewardEpic = (action$,store$) => 
    action$.ofType(USER_CLAIM_REWARD).mergeMap((action) => {
        let state = store$.getState();
        let typeReward = action.payload.type;       
        if (typeReward === 'profile_info'){
            //reward profile +5 FC
            let reward = getUserInfo(state,'Reward')('profile_info');            
            if (Number(reward) > 0){
                return of(claimRewardFromServer())
            } 
            return of(empty())       
        } else if (typeReward === 'security_info'){
            // reward completed security info
            let reward = getUserInfo(state,'Reward')('security_info');                         
            if (Number(reward) > 0){
                let security = getUserInfo(state,'Security')('email_verified','phone_verified','password','email');
                let email_verified = !!security.email && security.email_verified;
                if (email_verified && security.phone_verified && security.password){   
                    return of(claimRewardFromServer())
                }                  
            } 
            return of(empty())           
        } else if (typeReward = 'connect_facebook'){
            // reward completed connect fb
            let reward = getUserInfo(state,'Reward')('connect_facebook');
            if (Number(reward) > 0){
                return of(claimRewardFromServer())
            } 
        }
        return of(empty())
    }) 

export const requestClaimRewardServerEpic = (action$) => 
    action$.ofType(CLAIM_REWARD_SERVER).mergeMap(() => 
        get_userinfo().pipe(
            flatMap((r) => {
                const response = r.response;
                if (response.status === 200 && response.data){                            
                    return of(
                        change_user_funcoin(response.data.Funcoin),
                        change_user_reward(response.data.Reward)
                    )
                } else {
                    return of(empty())
                }
            })
        )
    )