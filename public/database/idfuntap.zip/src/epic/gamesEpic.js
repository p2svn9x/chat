import 'rxjs';
import { of } from 'rxjs/observable/of';
import { map,catchError, takeUntil } from 'rxjs/operators';
import {GET_GAMES_PLAYED} from '../constants/gamesType';
import {mergeDataGames,getErrorGames,getGameCancelled} from '../actions/games';
import {sync_recent_games} from '../configs/api';
import { clearUserInfo } from '../actions/user';

export const getGamesPlayedEpic = (action$,store) => 
    action$.ofType(GET_GAMES_PLAYED).mergeMap(() => {
        const state = store.getState().games;        
        if (Date.now() > (state.lastedTimeUpdate || 0) + 300000){ //cache 5'
            return sync_recent_games().pipe(
                map((r) => {
                    const response = r.response;
                    try {
                        if (!!response.error){
                            if (response.error.code === 0){
                                return clearUserInfo()
                            }
                            return getErrorGames(response.error)
                        } else if (response.status === 200){
                           if (!!response.data){
                            return mergeDataGames(response.data)
                           } else {
                            return getGameCancelled()
                           }                    
                        } else {
                            return getErrorGames({message:'Lỗi không xác định!'})
                        }
                    } catch(err){
                        return getErrorGames({message:'Đã có lỗi xảy ra!'})
                    }
                }),
                catchError(() => of(getErrorGames({code:501,message:'Mất kết nối tới máy chủ!'}))),
                takeUntil(action$.ofType(GET_GAMES_PLAYED))
            )
        } else {
            return of( getGameCancelled())
        }        
    }    
)