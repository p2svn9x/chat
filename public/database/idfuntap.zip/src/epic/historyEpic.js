import 'rxjs';
//import { of } from 'rxjs/observable/of';
import { map,catchError,takeUntil } from 'rxjs/operators';
import {GET_HISTORY_PAYMENT, SYNC_HISTORY_PAYMENT} from '../constants/historyType';
import {   
    syncHistoryCancelled,
    syncErrorHistory,
    mergeDataHistory,
    syncHistoryPayment
} from '../actions/history';
//import {empty} from '../actions/empty';
import { clearUserInfo } from '../actions/user';  

export const getHistoryPaymentEpic = (action$,store$) => 
    action$.ofType(GET_HISTORY_PAYMENT).map((action) => {        
        const {api,type} = action.meta;
        const state = store$.getState().history[type] || {};
        if (
            (!!state.data && state.data.length === 0) || 
            (Date.now() > (state.lastedTimeUpdate || 0) + 300000)
        ){
            return syncHistoryPayment(type,api,1)
        } 
        return syncHistoryCancelled(type)  
    })
export const syncHistoryPaymentEpic = (action$,store$) => 
    action$.ofType(SYNC_HISTORY_PAYMENT).mergeMap((action) => {        
        const {api,type} = action.meta;         
        const state = store$.getState().history[type] || {};   
        const page = action.payload.page || state.page + 1   
        return api(page).pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0){
                            return clearUserInfo()
                        }
                        return syncErrorHistory(type,{message:response.error.message})                    
                    } else if (response.status === 200){
                        if (Array.isArray(response.data) && response.data.length > 0){
                            let dataMerge = {
                                page,
                                data:state.data.concat(response.data)
                            }
                            return mergeDataHistory(type,dataMerge)
                        } else {
                            return syncHistoryCancelled()
                        }
                    } else {
                       return syncErrorHistory(type,{message:'Đã có lỗi xảy ra!'})
                    }                
                } catch(err){               
                    return syncErrorHistory(type,{message:'Đã có lỗi xảy ra!!'})
                }           
            }),
            catchError(() => {
                return syncErrorHistory(type,{message:'Mất kết nối tới máy chủ'})           
            }),
            takeUntil(action$.ofType(GET_HISTORY_PAYMENT,SYNC_HISTORY_PAYMENT))
        ) 
              
    })

// export const shortHistoryFuncoinEpic = (action$,store) => 
//     action$.ofType(CREATE_SHORT_HISTORY_FUNCOIN).mergeMap(() => {
//         const state = store.getState();
//         if (state.logfuncoin.history.length > 60){
//             let newHistory = state.logfuncoin.history.splice(0,59);
//             return of(import_short_history_funcoin(newHistory))
//         }
//         return empty()
        
//     })