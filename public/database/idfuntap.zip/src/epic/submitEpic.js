import 'rxjs';
import {of} from 'rxjs/observable/of';
import { map,catchError,takeUntil } from 'rxjs/operators';
import {
    SUBMIT_FORM_PERSONAL,
    SUBMIT_VERIFY_PASSWORD,
    SUBMIT_CANCEL,
    SUBMIT_FORM_VERIFY_CODE,    
    SUBMIT_UPDATE_SECURITY,
    SUBMIT_UPDATE_PASSWORD,
    SUBMIT_FORM_LOGIN,
    SUBMIT_METHOD_RECOVERY,
    SUBMIT_VERIFY_METHOD_RECOVERY
} from '../constants/submitType';
import {empty} from '../actions/empty';
import { clearUserInfo } from '../actions/user';
import {request_verify_password,request_change_profile, login, type_forgot_password, verify_method_security} from '../configs/api';
import {removeSessionOTP} from '../actions/session';
import {detectLoginType, errorFromPhoneNumber} from '../helpers/validate';

export const submitFormPersonalEpic = (action$,store$) => 
    action$.ofType(SUBMIT_FORM_PERSONAL)  
    .mergeMap((action) => {
        let {payload} = action;  
        let { resolve, reject } = action.meta || {};
        const state = store$.getState();       
        if (state.userInfo.Security.password && !state.session.lastVerifiedPassword){
            reject({code:1,message:'Xác thực lại mật khẩu!'})
            return of(empty())
        }       
        return request_change_profile(payload).pipe(                      
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else {
                            reject({message:response.error.message})                            
                        }
                    } else if (response.status === 200){    
                        resolve(response.data)                         
                    } else {
                        reject({message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'})                        
                    }
                    return empty()
                } catch(err){
                    reject({message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'})
                    return empty()
                }                
            }),
            takeUntil(action$.ofType(SUBMIT_CANCEL)),
            catchError(() => {
                reject({message:'Mất kết nối tới máy chủ!'})
                return of(empty())
            })
        )
    })

export const submitVerifyPasswordEpic = action$ => 
    action$.ofType(SUBMIT_VERIFY_PASSWORD)  
    .mergeMap((action) => {
        let {payload} = action;
        let { resolve, reject } = action.meta || {};  
        return request_verify_password(payload).pipe(            
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else if (response.error.code === 4){
                            reject({code:4,message:response.error.message})
                        } else {
                            reject({message:response.error.message})                            
                        }
                    } else if (response.status === 200){    
                        resolve()                         
                    } else {
                        reject({message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'})                        
                    }
                    return empty()
                } catch(err){
                    reject({message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'})
                    return empty()
                }                
            }),
            takeUntil(action$.ofType(SUBMIT_CANCEL)),
            catchError(() => {
                reject({message:'Mất kết nối tới máy chủ!'})
                return of(empty())
            })
        )
    })

export const submitVerifyCodeEpic = action$ => 
    action$.ofType(SUBMIT_FORM_VERIFY_CODE)  
    .mergeMap((action) => {
        let {payload} = action;
        let { api, callback } = action.meta;         
        return api(payload).pipe(            
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else if ((response.error.code === 1 && response.error.type === 1) || (response.error.code === 3 && response.error.type === 3)){
                            callback({error:{code:2}})
                        } else if (response.error.code === 4){                            
                            callback({error:{code:4,message:response.error.message}})
                        } else {
                            callback({error:{message:response.error.message}})                            
                        }
                    } else if (response.status === 200){    
                        callback({message:'Xác thực thành công!'})                         
                    } else {
                        callback({error:{message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'}})                                              
                    }
                    return empty()
                } catch(err){                   
                    callback({error:{message:'Đã có lỗi xảy ra, vui lòng thử lại sau!!'}}) 
                    return empty()
                }                
            }),
            takeUntil(action$.ofType(SUBMIT_CANCEL)),
            catchError(() => {
                callback({error:{message:'Mất kết nối tới máy chủ!'}})              
                return of(empty())
            })
        )
    })

export const submitUpdateSecurityEpic = (action$) => 
    action$.ofType(SUBMIT_UPDATE_SECURITY).mergeMap((action) => {       
        let {api,resolve,reject} = action.meta;   
        return api().pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){  
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else if ((response.error.code === 1 && response.error.type === 1) || (response.error.code === 3 && response.error.type === 3)){
                            reject({code:2})
                            return removeSessionOTP()
                        } else if (response.error.code === 4) {                           
                           reject({code:4,message:response.error.message})                           
                        } else {    
                           reject({message:response.error.message})
                        }
                    } else if (response.status === 200){
                        resolve()                        
                    } else {                        
                        reject({message:'Đã có lỗi xảy ra, hãy thử lại sau!'})  
                    }
                    return empty()
                } catch(err){
                    reject({message:'Đã có lỗi xảy ra, hãy thử lại sau!'})              
                    return empty()
                }
            }),
            catchError(() => {
                reject({message:'Mất kết nối tới máy chủ!'})              
                return of(empty())
            })
        )
    })

export const submitUpdatePasswordEpic = action$ => 
    action$.ofType(SUBMIT_UPDATE_PASSWORD).mergeMap((action) => {        
        let {api,callback} = action.meta;        
        return api().pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else {
                            callback({error:{message:response.error.message}})
                        }
                    } else if (response.status === 200){
                        callback({message:'Đổi mật khẩu thành công!'})
                    } else {
                        callback({error:{message:'Đã có lỗi xảy ra!'}})
                    }
                    return empty()
                } catch(err){
                    callback({error:{message:'Đã có lỗi xảy ra!!'}})
                    return empty()
                }                
            }),
            catchError(() => {
                callback({error:{message:'Mất kết nối tới máy chủ!'}})              
                return of(empty())
            })
        )
    })

export const submitFormLoginEpic = (action$,store$) => 
    action$.ofType(SUBMIT_FORM_LOGIN).mergeMap((action) => {
        let {data} = action.payload;
        let {callback} = action.meta;
        let bid = store$.getState().browser.browserId;
        if (detectLoginType(data.email) === 'phone'){
            let err = errorFromPhoneNumber(data.email);
            if (err){
                callback({
                    error:{ 
                        code:5,               
                        message:err
                    }
                })                            
                return of(empty())
            }            
        }
        return login(data,bid).pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        callback({
                            error:{
                                message:response.error.message
                            }
                        })
                    } else if (response.status === 200){
                        if (response.message === '2-STEP-VERIFICATION'){
                            // xu ly dang nhap 2 lop
                           callback({message:'2-STEP-VERIFICATION',data:response.data})
                        } else {
                            callback({message:'Đăng nhập thành công!'})
                        }
                    } else {
                        callback({
                            error:{
                                message:'Đã có lỗi xảy ra!'
                            }
                        })
                    }
                    return empty()
                } catch(err){
                    callback({
                        error:{
                            message:'Đã có lỗi xảy ra!!'
                        }
                    })
                    return empty()
                }
            }),
            catchError(() => {
                callback({
                    error:{
                        message:'Mất kết nối tới máy chủ!'
                    }
                })                           
                return of(empty())
            })
        )        
    })

export const submitMethodRecoveryEpic = (action$) => 
    action$.ofType(SUBMIT_METHOD_RECOVERY).mergeMap((action) => {
        const {callback} = action.meta;
        const {data} = action.payload;
        if (detectLoginType(data.email) === 'phone'){
            let err = errorFromPhoneNumber(data.email);
            if (err){
                callback({
                    error:{
                        code:5,                                
                        message:err
                    }
                })                            
                return of(empty())
            }            
        }
        return type_forgot_password(data).pipe(
            map((r) => {
                const response = r.response;
                try {
                    if(!!response.error){
                        callback({
                            error:{
                                message:response.error.message
                            }
                        })
                    } else if (response.status === 200) {
                        callback({
                            message:'Success!',
                            data:response.data
                        })
                    } else {
                        callback({
                            error:{
                                message:'Đã có lỗi xảy ra!'
                            }
                        })
                    }
                    return empty()
                } catch(err){
                    callback({
                        error:{
                            message:'Đã có lỗi xảy ra!!'
                        }
                    })                           
                    return empty()
                }
            }),
            catchError(() => {
                callback({
                    error:{
                        message:'Mất kết nối tới máy chủ!'
                    }
                })                           
                return of(empty())
            })
        )
    })

export const submitVerifyMethodRecovery = (action$) => 
    action$.ofType(SUBMIT_VERIFY_METHOD_RECOVERY).mergeMap((action) => {
        let {callback} = action.meta;
        let {data,userId} = action.payload;        
        return verify_method_security(data,userId).pipe(
            map((r) => {
                const response = r.response;
                try {
                    if(!!response.error){
                        callback({
                            error:{
                                message:response.error.message
                            }
                        })
                    } else if (response.status === 200) {
                        callback({
                            message:'Success!'                           
                        })
                    } else {
                        callback({
                            error:{
                                message:'Đã có lỗi xảy ra!'
                            }
                        })
                    }
                    return empty()
                } catch(err){
                    callback({
                        error:{
                            message:'Đã có lỗi xảy ra!!'
                        }
                    })                           
                    return empty()
                }
            }),
            catchError(() => {
                callback({
                    error:{
                        message:'Mất kết nối tới máy chủ!'
                    }
                })                           
                return of(empty())
            })
        )
    })