import { combineEpics } from 'redux-observable';
import {createBrowserIdEpic} from './browserEpic';
import {syncDirectionEpic} from './directionEpic';
import {
  getUserEpic,
  userLogoutEpic,
  userClaimRewardEpic,
  requestClaimRewardServerEpic,
  userLoggedEpic,
  clearUserInfoEpic  
} from './userEpic';
import {
  setSessionOTPEpic,
  setSessionPasswordEpic,  
  setSessionToStorageEpic,
  resetDataSessionEpic
} from './sessionEpic';
import {
  createdCodeNewPhoneEpic,
  createdCodeOldPhoneEpic,
  createdCodeNewEmailEpic,
  createdCodeOldEmailEpic,
  setTemporaryToStorageEpic,
  resetDataTemporaryEpic
} from './temporaryEpic';

import {getRecentDevicesEpic,removeTrustedDeviceEpic} from './devicesEpic';
import {getGamesPlayedEpic} from './gamesEpic';
import {
  submitFormPersonalEpic,
  submitVerifyPasswordEpic,
  submitVerifyCodeEpic,
  submitUpdateSecurityEpic,
  submitUpdatePasswordEpic,
  submitFormLoginEpic,
  submitMethodRecoveryEpic,
  submitVerifyMethodRecovery
} from './submitEpic';
import {
  getHistoryPaymentEpic,
  syncHistoryPaymentEpic
} from './historyEpic';
import {
  requestChangeSecurityEpic,
  createVerifyCodeEpic,
  requestSetNewSecurityEpic,  
  createCodeSetSecurityEpic,
  requestConnectFacebookEpic,
  requestLoginFacebookEpic,
  changeStatus2StepEpic,
  requestUpdatePasswordEpic 
} from './requestEpic';


const rootEpic = combineEpics(
  createBrowserIdEpic,
  syncDirectionEpic,
  getUserEpic, 
  requestClaimRewardServerEpic,
  userLoggedEpic,
  userLogoutEpic,
  clearUserInfoEpic,
  userClaimRewardEpic,
  //session
  setSessionPasswordEpic,
  setSessionOTPEpic,  
  setSessionToStorageEpic,
  resetDataSessionEpic,
  //temporary
  createdCodeNewPhoneEpic,
  createdCodeOldPhoneEpic,
  createdCodeNewEmailEpic,
  createdCodeOldEmailEpic,
  setTemporaryToStorageEpic, 
  resetDataTemporaryEpic,
  //recent device
  getRecentDevicesEpic,  
  removeTrustedDeviceEpic,
  //recent games
  getGamesPlayedEpic,
  //history
  getHistoryPaymentEpic,
  syncHistoryPaymentEpic,
  //submit
  submitFormPersonalEpic,
  submitVerifyPasswordEpic,
  submitVerifyCodeEpic,
  submitUpdateSecurityEpic,
  submitUpdatePasswordEpic,
  submitFormLoginEpic,  
  submitMethodRecoveryEpic,
  submitVerifyMethodRecovery,
  //request
  createVerifyCodeEpic,
  requestChangeSecurityEpic,
  requestSetNewSecurityEpic,  
  createCodeSetSecurityEpic,
  changeStatus2StepEpic,
  requestConnectFacebookEpic,
  requestLoginFacebookEpic,
  requestUpdatePasswordEpic
);
  
  export default rootEpic;