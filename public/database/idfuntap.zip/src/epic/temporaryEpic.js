import 'rxjs';
import { of } from 'rxjs/observable/of';
import { timer } from 'rxjs/observable/timer';
import {empty} from '../actions/empty';
//import { map,catchError  } from 'rxjs/operators';
import {   
    CREATED_CODE_NEW_PHONE,
    REMOVE_CODE_NEW_PHONE,
    CREATED_CODE_OLD_PHONE,
    REMOVE_CODE_OLD_PHONE,
    CREATED_CODE_NEW_EMAIL,
    REMOVE_CODE_NEW_EMAIL,
    CREATED_CODE_OLD_EMAIL,
    REMOVE_CODE_OLD_EMAIL,
    RESET_DATA_TEMPORARY,
} from '../constants/temporaryType';
import {
    removeCodeNewPhone,
    removeCodeOldPhone,
    removeCodeNewEmail,
    removeCodeOldEmail       
} from '../actions/temporary';
import {encryptBlowfish} from '../helpers/cryption';

const sessionLiveTime = 59000;

export const createdCodeNewPhoneEpic = (action$) => 
    action$.ofType(CREATED_CODE_NEW_PHONE).mergeMap((action) => {        
        let current = Date.now();
        let timeSet = Number(action.payload.time);
        if ((current >= timeSet) && (current - timeSet < sessionLiveTime)){ // 1 phut countdown                   
            return timer((timeSet + sessionLiveTime) - current)
            .takeUntil(action$.ofType(CREATED_CODE_NEW_PHONE,REMOVE_CODE_NEW_PHONE))
            .mapTo(removeCodeNewPhone())
        } 
        return of(removeCodeNewPhone())
    })
export const createdCodeOldPhoneEpic = (action$) => 
    action$.ofType(CREATED_CODE_OLD_PHONE).mergeMap((action) => {        
        let current = Date.now();
        let timeSet = Number(action.payload.time);
        if ((current >= timeSet) && (current - timeSet < sessionLiveTime)){ // 1 phut countdown                      
            return timer((timeSet + sessionLiveTime) - current)
            .takeUntil(action$.ofType(CREATED_CODE_OLD_PHONE,REMOVE_CODE_OLD_PHONE))
            .mapTo(removeCodeOldPhone())
        } 
        return of(removeCodeOldPhone())
    })

export const createdCodeNewEmailEpic = action$ => 
    action$.ofType(CREATED_CODE_NEW_EMAIL).mergeMap((action) => {        
        let current = Date.now();
        let timeSet = Number(action.payload.time);
        if ((current >= timeSet) && (current - timeSet < sessionLiveTime)){ // 1 phut countdown                         
            return timer((timeSet + sessionLiveTime) - current)
            .takeUntil(action$.ofType(CREATED_CODE_NEW_EMAIL,REMOVE_CODE_NEW_EMAIL))
            .mapTo(removeCodeNewEmail())
        } 
        return of(removeCodeNewEmail())
    })
export const createdCodeOldEmailEpic = action$ => 
    action$.ofType(CREATED_CODE_OLD_EMAIL).mergeMap((action) => {        
        let current = Date.now();
        let timeSet = Number(action.payload.time);
        if ((current >= timeSet) && (current - timeSet < sessionLiveTime)){ // 1 phut countdown                       
            return timer((timeSet + sessionLiveTime) - current)
            .takeUntil(action$.ofType(CREATED_CODE_OLD_EMAIL,REMOVE_CODE_OLD_EMAIL))
            .mapTo(removeCodeOldEmail())
        } 
        return of(removeCodeOldEmail())
    })

export const resetDataTemporaryEpic = (action$) => 
    action$.ofType(RESET_DATA_TEMPORARY).map(() => {
        try {
            if (!!window.localStorage && localStorage.getItem('TMP')){
                localStorage.removeItem('TMP')
            }
        } catch(err){}        
        return empty()
    })

export const setTemporaryToStorageEpic = (action$,store$) =>        
    action$.ofType(
        CREATED_CODE_NEW_PHONE,
        REMOVE_CODE_NEW_PHONE,
        CREATED_CODE_OLD_PHONE,
        REMOVE_CODE_OLD_PHONE,
        CREATED_CODE_NEW_EMAIL,
        REMOVE_CODE_NEW_EMAIL,
        CREATED_CODE_OLD_EMAIL,
        REMOVE_CODE_OLD_EMAIL
    ).map(() => {      
        try {
            if (!!window.localStorage){ 
                const userInfo = store$.getState().userInfo;
                const secretKey = !!userInfo.Account ? userInfo.Account.id : null;
                let ciphertext = encryptBlowfish(JSON.stringify(store$.getState().temporary),secretKey);            
                localStorage.setItem('TMP',ciphertext);
            }
        } catch(err){
            console.error(err)
        }             
        return empty()
    })
    