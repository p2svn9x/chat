import 'rxjs';
import { of } from 'rxjs/observable/of';
import { empty } from 'rxjs/observable/empty';
import { map,catchError, takeUntil  } from 'rxjs/operators';
import {SYNC_DIRECTION} from '../constants/directionType';
import {mergeDataDirection,syncErrorDirection} from '../actions/direction';
import {sync_country_add} from '../configs/api';


export const syncDirectionEpic = (action$,store$) => 
    action$.ofType(SYNC_DIRECTION).mergeMap(() => {        
        let data = store$.getState().direction.data;
        if (data.length === 0){
            return sync_country_add().pipe(
                map((r) => {
                    const response = r.response;
                    try {
                        if (!!response.error){
                            return syncErrorDirection(response.error);
                        } else if (response.status === 200 && !!response.data){
                            let provinces = response.data;
                            provinces.sort((p,_p) => {
                                if (p.province_name < _p.province_name){
                                    return -1
                                }
                                if (p.province_name > _p.province_name) {
                                    return 1;
                                }
                                return 0
                            })                    
                            return mergeDataDirection(provinces)
                        } else {
                            return syncErrorDirection({message:'Lỗi không xác định!'})
                        }
                    } catch(err){
                        return syncErrorDirection({message:'Đã có lỗi xảy ra!'})
                    }
                    
                }),
                takeUntil(action$.ofType(SYNC_DIRECTION)),
                catchError(() => of(syncErrorDirection({code:501,message:'Mất kết nối tới máy chủ!'})))
            )
        }
        return empty()
    })
