import 'rxjs';
import {of} from 'rxjs/observable/of';
import { map,catchError } from 'rxjs/operators';
import { CREATE_VERIFY_CODE, CHANGE_SECURITY_INFO, SET_NEW_SECURITY, CREATE_CODE_SET_SECURITY, CHANGE_STATUS_2STEP, REQUEST_CONNECT_FACEBOOK, REQUEST_LOGIN_FACEBOOK, REQUEST_UPDATE_PASSWORD } from '../constants/requestType';
import { clearUserInfo, claimReward } from '../actions/user';
import {removeSessionOTP} from '../actions/session';
import {empty} from '../actions/empty';
import { toggle_two_step, connect_facebook, login_facebook } from '../configs/api';

function isVerifyPassword(state){
    if (!!state.userInfo.Security && 
        state.userInfo.Security.password && 
        !state.session.lastVerifiedPassword
    ){
        return !1       
    }
    return !0
}
function isVerifyOTP(state){
    let security = state.userInfo.Security;
    let email_verified = !!security && security.email_verified && !!security.email;
    if (!!security && ( (security.phone_verified || email_verified) && !state.session.lastVerifiedOTP) ){
        return !1       
    }
    return !0
}

function isVerifiedPhoneOTP(state){
    if (state.userInfo.Security.phone_verified && !state.session.lastVerifiedOTP){
        return !1
    }
    return !0
}

function isVerifiedEmailOTP(state){
    let security = state.userInfo.Security;
    if (security.email && security.email_verified && !state.session.lastVerifiedOTP){
        return !1
    }
    return !0
}

export const requestUpdatePasswordEpic = (action$,store$) => 
    action$.ofType(REQUEST_UPDATE_PASSWORD).map((action) => {
        let {callback} = action.meta;
        const state = store$.getState();
        if (state.userInfo.Security.password){            
            callback({error:{code:1}})
        } else {
            callback({message:'Tài khoản chưa có mật khẩu'})
        }        
        return empty()
    })

export const createVerifyCodeEpic = (action$,store$) => 
    action$.ofType(CREATE_VERIFY_CODE).mergeMap((action) => {
        let { api, callback, type } = action.meta;
        const state = store$.getState();
        if (!isVerifyPassword(state)){
            callback({error:{code:1,message:'Hãy xác thực lại mật khẩu'}})
            return of(empty())
        }
        if (type === 'SET' && !isVerifyOTP(state)){
            callback({error:{code:2}})
            return of(empty())
        }
        return api().pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else if ((response.error.code === 1 && response.error.type === 1) || (response.error.code === 3 && response.error.type === 3)){
                            callback({error:{code:2}})
                        } else {
                            callback({error:{message:response.error.message}})                            
                        }
                    } else if (response.status === 200){
                        callback({message:'Gửi mã xác thực thành công!'})
                    } else {
                        callback({error:{message:'Lỗi không xác định!'}})
                    }
                    return empty()
                } catch(err){
                    callback({error:{message:'Đã có lỗi xảy ra!'}})
                    return empty()
                }
            }),                
            catchError(() => {
                callback({error:{message:'Mất kết nối tới máy chủ!'}})
                return of(empty())
            })                
        )
    })

export const requestChangeSecurityEpic = (action$,store$) => 
    action$.ofType(CHANGE_SECURITY_INFO).mergeMap((action) => {
        const state = store$.getState();
        const {callback} = action.meta;
        if (isVerifyPassword(state)){
            if (isVerifyOTP(state)){
                callback({message:'Đã xác thực mật khẩu và OTP'})
            } else {
                callback({error:{code:2,message:'Xác thực lại OTP!'}})
            }
            return of(empty())
        } else {
            callback({error:{code:1,message:'Xác thực lại mật khẩu!'}})
            return of(empty())
        }
    })

export const requestSetNewSecurityEpic = (action$,store$) => 
    action$.ofType(SET_NEW_SECURITY).mergeMap((action) => {
        const state = store$.getState();
        const {callback,type} = action.meta;
        if (isVerifyPassword(state)){
            let isVerifiedOTP = (type === 'email' ? isVerifiedPhoneOTP(state) : isVerifiedEmailOTP(state));
            if (isVerifiedOTP){
                callback({message:'Đã xác thực mật khẩu và OTP'})
            } else {
                callback({error:{code:2,message:'Xác thực lại OTP!'}})
            }
            return of(empty())
        } else {
            callback({error:{code:1,message:'Xác thực lại mật khẩu!'}})
            return of(empty())
        }
    })

export const createCodeSetSecurityEpic = (action$) => 
    action$.ofType(CREATE_CODE_SET_SECURITY).mergeMap((action) => {
        const {api,callback} = action.meta;
        return api().pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else if ((response.error.code === 1 && response.error.type === 1) || (response.error.code === 3 && response.error.type === 3)){
                            callback({error:{code:2}})
                            return removeSessionOTP()
                        } else if (response.error.code === 4){
                            callback({error:{code:4,message:response.error.message}})
                        } else {
                            callback({error:{message:response.error.message}})                            
                        }
                    } else if (response.status === 200){
                        callback({message:'Gửi mã xác thực thành công!'})
                    } else {
                        callback({error:{message:'Lỗi không xác định!'}})
                    }
                    return empty()
                } catch(err){
                    callback({error:{message:'Đã có lỗi xảy ra!'}})
                    return empty()
                }
            }),
            catchError(() => {
                callback({error:{message:'Mất kết nối tới máy chủ!'}})
                return of(empty())
            })             
        )
    })

export const changeStatus2StepEpic = (action$) => 
    action$.ofType(CHANGE_STATUS_2STEP).mergeMap((action) => {
        const {callback} = action.meta;
        const {status} = action.payload;
        return toggle_two_step(status).pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else if ((response.error.code === 1 && response.error.type === 1) || (response.error.code === 3 && response.error.type === 3)){
                            callback({error:{code:2}})
                            return removeSessionOTP()
                        } else {
                            callback({error:{message:response.error.message}})                            
                        }
                    } else if (response.status === 200){
                        callback({message:'Đổi trạng thái thành công!'})
                    } else {
                        callback({error:{message:'Lỗi không xác định!'}})
                    }
                    return empty()
                } catch(err){
                    callback({error:{message:'Đã có lỗi xảy ra!'}})
                    return empty()
                }
            }),
            catchError(() => {
                callback({error:{message:'Mất kết nối tới máy chủ!'}})
                return of(empty())
            })             
        )
    })

export const requestConnectFacebookEpic = (action$) => 
    action$.ofType(REQUEST_CONNECT_FACEBOOK).mergeMap((action) => {
        const {callback} = action.meta;   
        const {accessToken} = action.payload;     
        return connect_facebook(accessToken).pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 0 && response.error.type === 0){
                            return clearUserInfo()
                        } else {
                            callback({error:{message:response.error.message}})                            
                        }
                    } else if (response.status === 200){
                        callback({message:'Kết nối tài khoản với facebook thành công!'})
                        return claimReward('connect_facebook')
                    } else {
                        callback({error:{message:'Lỗi không xác định!'}})
                    }
                    return empty()
                } catch(err){
                    callback({error:{message:'Đã có lỗi xảy ra!'}})
                    return empty()
                }
            }),
            catchError(() => {
                callback({error:{message:'Mất kết nối tới máy chủ!'}})
                return of(empty())
            })             
        )
    })


export const requestLoginFacebookEpic = (action$,store$) => 
    action$.ofType(REQUEST_LOGIN_FACEBOOK).mergeMap((action) => {
        const {callback} = action.meta;   
        const {accessToken} = action.payload;   
        const bid = store$.getState().browser.browserId;  
        return login_facebook(accessToken,bid).pipe(
            map((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        callback({
                            error:{
                                message:response.error.message
                            }
                        })
                    } else if (response.status === 200){
                        if (response.message === '2-STEP-VERIFICATION'){
                            // xu ly dang nhap 2 lop
                           callback({message:'2-STEP-VERIFICATION',data:response.data})
                        } else {
                            callback({message:'Đăng nhập thành công!'})
                        }
                    } else {
                        callback({
                            error:{
                                message:'Đã có lỗi xảy ra!'
                            }
                        })
                    }
                } catch(err){
                    callback({
                        error:{
                            message:'Đã có lỗi xảy ra!!'
                        }
                    })
                }
                return empty()
            }),
            catchError(() => {
                callback({error:{message:'Mất kết nối tới máy chủ!'}})
                return of(empty())
            })             
        )
    })