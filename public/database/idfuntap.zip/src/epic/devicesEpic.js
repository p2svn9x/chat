import 'rxjs';
import { of } from 'rxjs/observable/of';
import { map,catchError, takeUntil} from 'rxjs/operators';
import {GET_RECENT_DEVICES, REMOVE_TRUSTED_DEVICE } from '../constants/devicesType';
import {mergeDataDevices,getErrorDevices,getDevicesCancelled} from '../actions/devices';
import {sync_recent_devices,remove_trusted_device} from '../configs/api';
import { clearUserInfo } from '../actions/user';
import { empty } from '../actions/empty';

export const getRecentDevicesEpic = (action$,store$) =>
    action$.ofType(GET_RECENT_DEVICES).mergeMap(() => {
        const state = store$.getState().devices;  
        if (Date.now() > (state.lastedTimeUpdate || 0) + 300000){ // cache trong 5 phut
            return sync_recent_devices().pipe(
                map((r) => {
                    const response = r.response;
                    try {
                        if (!!response.error){
                            if (response.error.code === 0){
                                return clearUserInfo()
                            }
                            return getErrorDevices(response.error)
                        } else if (response.status === 200){
                            if (!!response.data){
                                return mergeDataDevices(response.data)
                            } else {
                                return getDevicesCancelled()
                            }                            
                        } else {
                            return getErrorDevices({message:'Lỗi không xác định!'})
                        }
                    } catch(err){
                        return getErrorDevices({message:'Lỗi không xác định!'})
                    }
                    
                }),
                catchError(() => of(getErrorDevices({code:501,message:'Mất kết nối tới máy chủ!'}))),
                takeUntil(action$.ofType(GET_RECENT_DEVICES))
            )
        } else {
            return of(getDevicesCancelled())
        }       
    })

export const removeTrustedDeviceEpic = (action$,store$) => 
    action$.ofType(REMOVE_TRUSTED_DEVICE).mergeMap((action) => {
        let deviceId = action.payload;
        let {callback} = action.meta;
        let dataDevices = store$.getState().devices.data;
        if (!!deviceId){
            return remove_trusted_device('true',deviceId).pipe(
                map((r) => {
                    const response = r.response;
                    try {
                        if (!!response.error){
                            if (response.error.code === 0){
                                return clearUserInfo()
                            } 
                            callback({error:{message:response.error.message}})
                        } else if (response.status === 200){
                            callback({message:'Thay đổi trạng thái thành công!'});
                            let idx = dataDevices.findIndex((device) => device.device_id === deviceId);
                            if (idx >= 0){    
                                dataDevices[idx].trusted = !1;                          
                                return mergeDataDevices(dataDevices)
                            }                            
                        } else {
                            callback({error:{message:'Đã có lỗi xảy ra!'}})
                        }
                        return empty()
                    } catch(err){
                        callback({error:{message:'Đã có lỗi xảy ra!'}})
                        return empty()
                    }
                }),                
                catchError(() => {
                    callback({error:{message:'Mất kết nối tới máy chủ!'}})
                    return of(empty())
                }),
                takeUntil(action$.ofType(REMOVE_TRUSTED_DEVICE)),
            )
        } else {
            callback({error:{message:'Đã có lỗi xảy ra!!'}})
            return of(empty())
        }
    })