import 'rxjs';
import { of } from 'rxjs/observable/of';
import { timer } from 'rxjs/observable/timer';
//import { map,catchError  } from 'rxjs/operators';
import {
    SET_SESSION_OTP,
    REMOVE_SESSION_OTP,
    SET_SESSION_PASSWORD,
    REMOVE_SESSION_PASSWORD,   
    RESET_DATA_SESSION
} from '../constants/sessionType';
import {
    removeSessionOTP,
    removeSessionPassword   
} from '../actions/session';
import {empty} from '../actions/empty';
import {encryptBlowfish} from '../helpers/cryption';

const sessionLiveTime = 1799000;

export const setSessionPasswordEpic = (action$) => 
    action$.ofType(SET_SESSION_PASSWORD).mergeMap((action) => {
        let current = Date.now();  
        let timeSet = Number(action.payload);        
        if ((current >= timeSet) && (current - timeSet < sessionLiveTime)){ 
            return timer((timeSet + sessionLiveTime) - current)
            .takeUntil(action$.ofType(SET_SESSION_PASSWORD,REMOVE_SESSION_PASSWORD))
            .mapTo(removeSessionPassword())
        }      
        return of(removeSessionPassword())
    }) 

export const setSessionOTPEpic = (action$) => 
    action$.ofType(SET_SESSION_OTP).mergeMap((action) => {        
        let current = Date.now();
        let timeSet = Number(action.payload);
        if ((current >= timeSet) && (current - timeSet < sessionLiveTime)){  
            return timer((timeSet + sessionLiveTime) - current)
            .takeUntil(action$.ofType(SET_SESSION_OTP,REMOVE_SESSION_OTP))
            .mapTo(removeSessionOTP())
        } 
        return of(removeSessionOTP())
    })

export const resetDataSessionEpic = (action$) => 
    action$.ofType(RESET_DATA_SESSION).map(() => {     
        try {
            if (!!window.localStorage && localStorage.getItem('SESSION')){
                localStorage.removeItem('SESSION')
            }
        } catch(err){}
        return empty()
    }  
)

export const setSessionToStorageEpic = (action$,store$) =>        
    action$.ofType(SET_SESSION_OTP,SET_SESSION_PASSWORD,REMOVE_SESSION_PASSWORD,REMOVE_SESSION_OTP).map(() => { 
        try {
            if (!!window.localStorage){           
                const userInfo = store$.getState().userInfo;
                const secretKey = !!userInfo.Account ? userInfo.Account.id : null;
                let ciphertext = encryptBlowfish(JSON.stringify(store$.getState().session),secretKey);            
                localStorage.setItem('SESSION',ciphertext);
            }
        } catch(err){}  
        return empty()
    })

