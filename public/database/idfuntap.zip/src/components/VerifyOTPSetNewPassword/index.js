import React from 'react';
import { connect } from 'react-redux';
import VerifyCodeUseEmail from '../VerifyCodeUseEmail';
import VerifyCodeUsePhone from '../VerifyCodeUsePhone';
import { getUserInfo } from '../../helpers/filters';

const type = ['phone','email'];

const SwitchMethodButton = ({show,label,onClick}) => {
    if (show){
        return (
            <a style={{cursor:'pointer'}} onClick={() => onClick()} className="btn-txt-xt">Xác thực bằng <span>{label}</span></a>
        )
    }
    return null
}

class VerifyOTPSetNewPassword extends React.Component {       
    constructor(props){
        super(props);
        this.phoneVerified = props.phoneVerified;
        this.emailVerified = props.emailVerified;
        this.verifyMethod = props.phoneVerified ? type[0] : type[1];        
    }
    changeMethod(method){
        this.verifyMethod = method;
        this.forceUpdate()
    }    
    render(){
        const {onVerified} = this.props;       
        const {phoneVerified,emailVerified,verifyMethod} = this;     
        if (phoneVerified && verifyMethod === type[0]){
            return (
                <div>
                    <VerifyCodeUsePhone   
                        type="pw"                      
                        onVerified={() => onVerified()}
                    />
                    <SwitchMethodButton 
                        show={!!emailVerified} 
                        onClick={() => this.changeMethod(type[1])}
                        label="Email"
                    />                    
                </div>
            ) 
        } else if (emailVerified && verifyMethod === type[1]) {
            return (
                <div>
                    <VerifyCodeUseEmail 
                        type="pw"                               
                        onVerified={() => onVerified()} 
                    />
                    <SwitchMethodButton 
                        show={!!phoneVerified} 
                        onClick={() => this.changeMethod(type[0])}
                        label="SĐT"
                    />                    
                </div>
            )
        } else {
            return null
        }
    }
}
export default connect((state) => {  
    const userInfo = getUserInfo(state,'Security')('phone_verified','email_verified','email');   
    return {
        phoneVerified:userInfo.phone_verified,
        emailVerified:!!userInfo.email && userInfo.email_verified,
    }
},null)(VerifyOTPSetNewPassword);

VerifyOTPSetNewPassword.defaultProps = {
    onVerified:() => {}    
}