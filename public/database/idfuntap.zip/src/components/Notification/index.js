import React from 'react';

class Notification extends React.Component {
    constructor(){
        super();
        this.handleNotification = this.handleNotification.bind(this);
    }  
    componentWillMount(){        
        document.addEventListener('click',this.handleNotification);
        document.addEventListener('touchstart',this.handleNotification);
        this.timeout = setTimeout(() => {
            if (this.props.remove) this.props.remove();            
        },5000);        
    }
    componentWillUnmount(){
        if (this.timeout) clearTimeout(this.timeout);
        document.removeEventListener('click',this.handleNotification);
        document.removeEventListener('touchstart',this.handleNotification);               
    }    
    
    handleNotification = (e) => {
        if (this.notification && !this.notification.contains(e.target)){
            if (this.props.remove) this.props.remove();
        }
    }
    render(){
        const {notification} = this.props;
        let center = window.innerHeight/2;
        return (
            <div 
                className={notification.type === 'error' ? 'box-mess error' : 'box-mess'} 
                style={{top:`${center}px`}}
                ref={(el) => this.notification = el}>
                {notification.message}
            </div>
        )
    }
}

export default Notification;