import React from 'react';

const NotFound = () => (
    <div className="box-fullh">
        <div className="box-fullh-center">
            <div className="mui--text-display3 mui--text-center">404</div>
            <div className="mui--text-subhead mui--text-center">Không tìm thấy trang</div>
        </div>
    </div>
)

export default NotFound;