import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import Steps from '../Steps';
import VerifyOTPSetNewPassword from '../VerifyOTPSetNewPassword';
import {change_user_security} from '../../actions/user';
import UpdateSuccess from '../UpdateSuccess';
import ConfirmPassword from '../ConfirmPassword';
import Loading from '../Loading';
import { changeStatus2Step, requestChangeSecurity } from '../../actions/request';
import LineErrorMessage from '../LineErrorMessage';

const uniqkey = Math.random().toString(36).substr(2, 6);

const Modal = ({show,onClose,onAgree}) => {
    if (show){
       return ( 
        <div className="pop-baomat">
                <div className="box-tat-baomat">
                    <h2 className="rs">Tắt bảo mật 2 bước</h2>
                    <p className="rs caption">Khi tắt bảo mật 2 bước, bảo mật tài khoản sẽ bị giảm đi. Bạn vẫn muốn tiếp tục ?</p>
                    <p className="rs ct-bm">
                        <a style={{cursor:'pointer'}} onClick={onClose}>HỦY</a>
                        <a style={{cursor:'pointer'}} className="btn-tat-bm" onClick={onAgree}>TẮT</a>
                    </p>
                </div>
            </div>
        )
    }
    return null
}

class ToggleTwoStep extends React.Component {
    constructor(props){
        super(props);        
        this.state = {
            modal:!1,
            error:'',
            loading:!1
        } 
        this.status = props.status;
        this.onChangeStatus = this.onChangeStatus.bind(this);
    }
    showModal(){
        this.setState({modal:!0});        
        document.body.style.overflow = 'hidden';        
    }
    hideModal(){
        this.setState({modal:!1});  
        document.body.style.overflow = '';       
    }
    setErrorFromServer(message){
        this.setState({loading:!1,error:message})
    }
    onToggle(){
        const {onReverify,onRequestChangeSecurity} = this.props;        
        const {onChangeStatus,setErrorFromServer} = this;
        this.setState({loading:!0,error:''});
        if (this.state.modal){
            this.hideModal()
        } 
        if (this.status){
            onRequestChangeSecurity((response) => {
                if (!!response.error){
                    if (response.error.code === 1 || response.error.code === 2){
                        onReverify()
                    } else {
                        setErrorFromServer(response.error.message)                       
                    }
                } else {
                    onChangeStatus()
                }
            })
        } else {
            onChangeStatus()
        }
    }
    onChangeStatus(){
        this.props.onRequestChangeStatus(this.status ? 'off' : 'on',this.responseHandle.bind(this))
    }
    responseHandle = (response) => {
        const {onChanged,onReverify} = this.props;        
        if (!!response.error){
            if (response.error.code === 2){
                onReverify()
            } else {
                this.setErrorFromServer(response.error.message) 
            }
        } else {
            onChanged()
        }
    }
    render(){
        const {status} = this;
        const {loading,modal,error} = this.state;         
        return (
            <div>
                <Loading isLoading={loading} />                
                <Modal 
                    show={modal} 
                    onClose={() => this.hideModal()} 
                    onAgree={() => this.onToggle()}
                />                
                {status ? (
                    <div>
                        <p className="rs txt-dn2">Bảo vệ tài khoản bằng Bảo mật 2 bước</p>
                        <p className="rs txt-dn3">Khi tắt bảo mật 2 bước, bảo mật tài khoản của bạn sẽ bị giảm đi. Bạn vẫn muốn tiếp tục ? </p>
                    </div>                
                ) : (
                    <div>
                        <p className="rs txt-dn2">Bảo vệ tài khoản bằng Bảo mật 2 bước</p>
                        <p className="rs txt-dn3">Mỗi khi đăng nhập Tài khoản FunID, bạn sẽ cần mật khẩu và mã xác thực. </p>
                    </div>
                )}                
                <br/>
                <LineErrorMessage type="error" message={error} />
                <a onClick={() => {if (status){this.showModal()}else{this.onToggle()} } } className="mui-btn f-btn-orage f-btn-100 btn-h40">{status ? 'Tắt bảo mật 2 bước' : 'Bật bảo mật 2 bước'}</a>
            </div>
        )
    }
}

class TwoStepSetting extends React.Component {
    constructor(){
        super();
        this.step = 1;
    }
    componentWillMount(){
        if (!this.props.status){
            this.changestep(3)
        }
    }
    changestep(step){
        this.step = step;        
        this.forceUpdate()
    }
    render(){       
        const {onRequestChangeSecurity,onRequestChangeStatus,changeSecurity,status} = this.props;        
        return (
                <TransitionGroup>
                <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                    <Steps order={this.step}>
                        <ConfirmPassword 
                            show={!0} 
                            step={1} 
                            onConfirmed={() => this.changestep(2)} 
                        />
                        <VerifyOTPSetNewPassword 
                            step={2} 
                            onVerified={() => this.changestep(3)} 
                        />
                        <ToggleTwoStep 
                            step={3} 
                            onRequestChangeSecurity={onRequestChangeSecurity}
                            onRequestChangeStatus={onRequestChangeStatus}
                            onReverify={() => this.changestep(3)}
                            onChanged={() => this.changestep(4)}                           
                            status={status} 
                        />
                        <UpdateSuccess 
                            step={4} 
                            timer={5} 
                            title={!status ? 'Bật bảo mật 2 bước thành công' : 'Tắt bảo mật 2 bước thành công'}
                            onRemove={() => changeSecurity({two_step:!status})} 
                        />
                    </Steps>
                </CSSTransition>   
                </TransitionGroup>
           
        )
    }
}

export default connect(null,(dispatch) => ({
    changeSecurity: bindActionCreators(change_user_security,dispatch),
    onRequestChangeSecurity:bindActionCreators(requestChangeSecurity,dispatch),
    onRequestChangeStatus: bindActionCreators(changeStatus2Step,dispatch)
}))(TwoStepSetting);