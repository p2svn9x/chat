import React from 'react';

const Description = ({icon,title,desc}) => (
    <div className="userDesc userDesc-inner">
        <i className={icon}></i>
        <h3 className="rs">{title}</h3>
        <p className="rs txt-desc-inf">{desc}</p>               
    </div>
)
 export default Description;