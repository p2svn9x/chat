import React from 'react';
import Button from 'muicss/lib/react/button';

class Modal extends React.Component {    
    componentWillMount(){
        document.body.style.overflow = 'hidden'
    }
    componentWillUnmount(){
        document.body.style.overflow = ''
    }
    render(){
        const {onClose,message} = this.props;
        return (
            <div className="box-modal">
                <div className="modal-inner cnt" style={{width:'320px'}}>
                    <h3 className="rs">  
                        Chú ý
                        <a className="ico-hide" onClick={() => onClose()} />
                    </h3>
                    <div className="box-thanhcong" style={{padding:'15px 9px'}}> 
                        {message}
                        <Button className="f-btn-red" onClick={() => onClose()}>Tôi đã hiểu</Button>
                    </div>
                </div>
            </div>            
        )
    }
}

export default Modal;