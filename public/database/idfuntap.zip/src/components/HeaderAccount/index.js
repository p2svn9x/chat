import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {userLogout} from '../../actions/user';

class HeaderAccount extends React.Component {
    constructor(){
        super();        
        this.state = {
            open: !1
        }
        this.handleDropdown = this.handleDropdown.bind(this);
    }    
    componentWillReceiveProps(nextProps){
        if (!nextProps.userInfo.Account){
            this.setState({open:!1})
        }
    }
    toggleDropdown(){
        this.setState({open:!this.state.open});
        if (!this.state.open){
            this.addEvent()
        } else {
            this.removeEvent()
        }        
    }
    handleDropdown = (e) => {
        if (this.dropdown && !this.dropdown.contains(e.target) && this.btndrodown && !this.btndrodown.contains(e.target)){
            this.setState({open:!1});
            this.removeEvent()
        }        
    }
    addEvent(){
        document.addEventListener('click',this.handleDropdown);
        document.addEventListener('touchstart',this.handleDropdown)
    }
    removeEvent(){
        document.removeEventListener('click',this.handleDropdown);
        document.removeEventListener('touchstart',this.handleDropdown)
    }
    render(){
        const {userInfo,onLogout} = this.props;
        if (!userInfo.Account){
            return null
        }
        const fw = userInfo.Account.username.charAt(0).toUpperCase();     
        return (
            <div className="box-login-done">
                <a className={`ico-avata no-indent click-animation ${fw}`} 
                    ref={(btn) => this.btndrodown = btn} onClick={() => this.toggleDropdown()} 
                >
                {fw}
                </a>
                <ul className={`mui-dropdown__menu mui-dropdown__menu1 mui-dropdown__menu--right ${this.state.open ? 'mui--is-open' : ''}`} 
                    style={{top: '30px'}} ref={(dropdown) => this.dropdown = dropdown}>
                    <li>
                        <a>
                            <i className={`ico-avata-min avatar-letter ${fw}`}>{fw}</i>
                            {userInfo.Account.username}
                        </a>
                    </li>
                    <li>
                        <a style={{cursor:'pointer'}} onClick={onLogout}>
                            <i className="ico-logout"></i>
                            Thoát
                        </a>
                    </li>
                </ul>
            </div>
        )
    }
}

export default connect((state) => ({
    userInfo:state.userInfo
}),(dispatch) => ({
    onLogout: () => bindActionCreators(userLogout,dispatch)()
}))(HeaderAccount);
