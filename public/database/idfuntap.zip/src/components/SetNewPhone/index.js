import React from 'react';
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import Input from 'muicss/lib/react/input';
import Loading from '../Loading';
import {verify_new_phone} from '../../configs/api';
import {createdCodeNewPhone} from '../../actions/temporary';
import {change_user_security} from '../../actions/user';
import { createCodeSetSecurity } from '../../actions/request';
import { getUserInfo } from '../../helpers/filters';
import LineErrorMessage from '../LineErrorMessage';
import { maskPhone } from '../../helpers/utils';

class SetNewPhone extends React.Component {
    constructor(){
        super();           
        this.state = {
            loading:!1,
            error:''
        }
    }   
    handleResponse = (response) => {     
        const {onSuccess,onError,changeSecurity,phone,onCreatedCodeNewPhone} = this.props;   
        if (!!response.error){
            if (response.error.code === 2){
                onError()
            } else {
                this.setState({loading:!1,error:response.error.message})
            }
        } else {
            changeSecurity({new_phone:phone});
            onCreatedCodeNewPhone(phone);
            onSuccess()
        }
    }
    handleSubmit = () => {
        const {onSubmit,onCreateCodeNewPhone} = this.props;
        if (!this.state.loading){
            this.setState({loading:!0,error:''});
            onSubmit(() => {                
                onCreateCodeNewPhone(this.handleResponse.bind(this))
            })
        }        
    }   
    render(){
        const {phone,onChangeType} = this.props;
        const {loading,error} = this.state;        
        return ( 
            <div>                
                <Loading isLoading={loading} />
                <h3 className="rs tlt-dn">Thiết lập số điện thoại của bạn</h3>
                <p className="rs txt-dn">
                    Số điện thoại khôi phục của bạn được sử dụng để liên lạc với bạn trong trường 
                    hợp chúng tôi phát hiện thấy hoạt động bất thường trong tài khoản của 
                    bạn hoặc bạn vô tình bị chặn.
                </p>
                <LineErrorMessage type="error" message={error} />
                <Input value={maskPhone(phone)} label="Số điện thoại của bạn" disabled={!0} />
                <a 
                    className="mui-btn f-btn-orage f-btn-100" 
                    style={{cursor:'pointer'}} 
                    onClick={this.handleSubmit}
                >Xác thực</a>
                <a 
                    className="mui-btn mui-btn-m10 f-btn-gray f-btn-100" 
                    onClick={onChangeType} 
                    style={{cursor:'pointer'}}
                >Thay đổi SĐT</a>
            </div> 
        )
    }
}
export default connect((state) => ({
    phone:getUserInfo(state,'Security')('phone')     
}),(dispatch) => ({
    changeSecurity: bindActionCreators(change_user_security,dispatch),   
    onCreatedCodeNewPhone:(phone) => bindActionCreators(createdCodeNewPhone,dispatch)(Date.now(),phone),
    onCreateCodeNewPhone:(callback) => bindActionCreators(createCodeSetSecurity,dispatch)(verify_new_phone,callback)
}))(SetNewPhone);

