import React from 'react';

const LineErrorMessage = ({type,message}) => {
    if (message){
        let cls = 'text-canhbao';
        if (type === 'error'){
            cls += ' text-red';
        } else if (type === 'success'){
            cls+= ' text-green'
        }
        return (
            <p className={cls} dangerouslySetInnerHTML={{__html:message}} />
        )
    }
    return null
}

export default LineErrorMessage;