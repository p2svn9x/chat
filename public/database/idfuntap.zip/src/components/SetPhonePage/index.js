import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {CSSTransition,TransitionGroup} from 'react-transition-group';
import Steps from '../Steps';
import CreateNewPhone from '../CreateNewPhone';
import SetNewPhone from '../SetNewPhone';
import VerifyCodeNewPhone from '../VerifyCodeNewPhone';
import UpdateSuccess from '../UpdateSuccess';
import {change_user_security,claimReward} from '../../actions/user';
import { getUserInfo } from '../../helpers/filters';
import VerifyCodeUseEmail from '../VerifyCodeUseEmail';
import ConfirmPassword from '../ConfirmPassword';
import { requestSetNewPhone} from '../../actions/request';


class SetPhonePage extends React.Component {   
    constructor(){
        super();
        this.phoneTmp = null;
        this.handleRequestSet = this.handleRequestSet.bind(this)
    }  
    componentWillMount(){
        if (this.props.createdCodeNewPhone && this.props.newPhone){
            this.step = 5
        } else {
            this.handleType()
        }
    }   
    changestep(step){        
        this.step = step;                
        this.forceUpdate()
    }
    handleType(){
        if (this.phoneTmp){
            this.changestep(2)
        } else if (this.props.phone){
            this.changestep(1)
        } else {
            this.changestep(2)
        }        
    }
    handleRequestSet = (response) => {
        this.handleResponse(response)
    }
    handleSubmitSet = (callback) => {
        this.props.onRequestSetPhone((response) => {
            this.handleResponse(response,callback)            
        })
    }
    handleResponse(response,callback){
        if (!!response.error){
            if (response.error.code === 1){
                this.changestep(3)
            } else {
                this.changestep(4)
            }
        } else {  
            if (typeof callback === 'function'){
                callback()
            } else {                
                this.handleType()
            }  
        }
    }
    render(){
       const {
           newPhone,
           changeSercurity,
           onRequestSetPhone,
           onClaimReward        
       } = this.props;       
        return (
            <div>                   
                <TransitionGroup>
                    <CSSTransition classNames="fade" key={`set-${this.step}`} timeout={300}>
                        <Steps order={this.step || 1}>
                            <SetNewPhone
                                step={1}
                                onChangeType={() => this.changestep(2)}
                                onSubmit={this.handleSubmitSet.bind(this)}
                                onSuccess={() => this.changestep(5)}
                                onError={() => this.changestep(4)}                                                       
                            />
                            <CreateNewPhone 
                                step={2}          
                                phoneTmp={this.phoneTmp}
                                onSetPhoneTmp={(phone) => this.phoneTmp = phone}
                                onSubmit={this.handleSubmitSet.bind(this)}                     
                                onSuccess={() => this.changestep(5)}
                                onReverify={() => this.changestep(4)}
                            /> 
                            <ConfirmPassword 
                                step={3} 
                                show={!0} 
                                onConfirmed={() => onRequestSetPhone(this.handleRequestSet)} 
                            />
                            <VerifyCodeUseEmail
                                step={4}
                                onVerified={() => this.handleType()}
                             />                          
                            <VerifyCodeNewPhone 
                                step={5}
                                newPhone={newPhone}
                                onVerified={() => this.changestep(6)}
                                onReverify={() => this.changestep(4)}
                            />
                            <UpdateSuccess 
                                step={6} 
                                title="Xác thực số điện thoại thành công" 
                                timer={5} 
                                onRemove={() => {
                                    changeSercurity({new_phone:'',phone:newPhone,phone_verified:!0})                                   
                                    onClaimReward()
                                }} 
                            />                               
                        </Steps>
                    </CSSTransition>
                </TransitionGroup>     
            </div>              
        )
        
    }
}

export default connect((state) => {
    const securityInfo = getUserInfo(state,'Security')('phone','new_phone') || {};    
    return {
        phone:securityInfo.phone || null,
        newPhone:securityInfo.new_phone || null,
        createdCodeNewPhone:state.temporary.createdCodeNewPhone
    }
},(dispatch) => ({
    changeSercurity:bindActionCreators(change_user_security,dispatch),
    onRequestSetPhone: bindActionCreators(requestSetNewPhone,dispatch),
    onClaimReward:() => bindActionCreators(claimReward,dispatch)('security_info'),
}))(SetPhonePage);


