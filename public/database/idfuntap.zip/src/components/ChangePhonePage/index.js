import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
//import {Prompt} from 'react-router-dom';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import {Button,Input} from 'muicss/react';
import UpdateSuccess from '../UpdateSuccess';
import VerifyCodeUsePhone from '../VerifyCodeUsePhone';
import UpdateNewPhone from '../UpdateNewPhone';
import VerifyCodeNewPhone from '../VerifyCodeNewPhone';
import ConfirmPassword from '../ConfirmPassword';
import Steps from '../Steps';
import { getUserInfo } from '../../helpers/filters';
import { requestChangeSecurity } from '../../actions/request';
import {change_user_security} from '../../actions/user';
import { maskPhone } from '../../helpers/utils';

const uniqkey = Math.random().toString(36).substr(2, 6);

 
const ChangePhone = connect((state) => ({   
    phone:getUserInfo(state,'Security')('phone')    
}),null)(({phone,onRequest}) => (
    <div>
        <h3 className="rs tlt-dn">Thiết lập SĐT của bạn</h3>
        <p className="rs txt-dn">
            SĐT khôi phục của bạn được sử dụng để liên lạc với bạn trong trường hợp chúng 
            tôi phát hiện thấy hoạt động bất thường trong tài khoản của bạn hoặc bạn vô tình bị chặn.
        </p>
        <Input value={maskPhone(phone)} disabled={!0} />
        <Button className="f-btn-gray f-btn-100" onClick={onRequest}>Thay đổi SĐT</Button>
    </div>
));

class ChangePhonePage extends React.Component {
    constructor(){
        super();
        this.step = 1;        
        this.changestep = this.changestep.bind(this);
        this.handleRequestChangeSecurity = this.handleRequestChangeSecurity.bind(this);
    }
    componentWillMount(){
        if (this.props.newPhone && this.props.createdCodeNewPhone){
            this.step = 5
        } else if (this.props.createdCodeOldPhone){
            this.step = 3
        }
    }
    changestep(step){
        this.step = step;       
        this.forceUpdate();
    }  
    handleRequestChangeSecurity = (response) => {           
        if (!!response.error){
            if (response.error.code === 1){
                this.changestep(2)
            } else {
                this.changestep(3)
            }
        } else {
            this.changestep(4)
        }
    }
    render(){ 
        const {
            changeSecurity,
            onRequestChangeSecurity,
            newPhone,           
            //onSetSessionOTP,
            //onSetSessionSendedNewEmail,
            //onRemoveSessionSendedNewEmail         
        } = this.props;         
        //<Prompt when={!!(this.step > 1 && this.step < 5)} message="Sau khi thoát bạn sẽ phải thực hiện lại toàn bộ từ đầu, bạn có chắc muốn thoát không ?" />    
        return (
            <div>                
                <TransitionGroup>
                    <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                        <Steps order={this.step}>   
                            <ChangePhone 
                                step={1} 
                                onRequest={() => onRequestChangeSecurity(this.handleRequestChangeSecurity)} 
                            />
                            <ConfirmPassword 
                                step={2} 
                                show={!0}
                                onConfirmed={() => onRequestChangeSecurity(this.handleRequestChangeSecurity)} 
                            />
                            <VerifyCodeUsePhone
                                step={3}
                                onVerified={() => this.changestep(4)}
                            />                                  
                            <UpdateNewPhone                         
                                step={4}   
                                onReverify={() => this.changestep(3)}                                                                                                                
                                onNext={() => this.changestep(5)}                         
                            />
                            <VerifyCodeNewPhone
                                step={5} 
                                type="update_phone"
                                newPhone={newPhone}   
                                onReverify={() => this.changestep(3)}                                                           
                                onVerified={() => this.changestep(6)}
                            />
                            <UpdateSuccess 
                                step={6} 
                                timer={5} 
                                title="Thay đổi số điện thoại thành công"
                                onRemove={() => {                                    
                                    changeSecurity({phone:newPhone,new_phone:''})
                                }} 
                            />                
                        </Steps>  
                    </CSSTransition>   
                </TransitionGroup> 
            </div>   
        )
    }
}

export default connect((state) => ({
    newPhone:getUserInfo(state,'Security')('new_phone'),
    createdCodeNewPhone:state.temporary.createdCodeNewPhone,
    createdCodeOldPhone:state.temporary.createdCodeOldPhone
}),(dispatch) => ({
    onRequestChangeSecurity: bindActionCreators(requestChangeSecurity,dispatch),
    changeSecurity: bindActionCreators(change_user_security,dispatch) 
}))(ChangePhonePage);


