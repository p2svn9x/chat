import React from 'react';
import Loading from '../Loading';
import {sync_history_funcoin} from '../../configs/api';
import withHistoryPaymentLayout from '../withHistoryPaymentLayout';

const LineError = ({message}) => (
    <div style={{padding:'15px',color:'red'}}>{message}</div>
)

const HistoryUseFuncoinPage = ({sync,error,data}) => {  
    if (data.length === 0){
        if (sync){
            return <Loading isLoading={!0} />
        } else if (!!error.message){
            return <LineError message={error.message} />
        } else {
            return <LineError message="Bạn chưa sử dụng Funcoin trong 30 ngày gần đây" />
        }
    } 
    return (
        <div>
            {data.map((h,i) => {
                let class_type = '';
                switch(h.types){
                    case 'update_info':
                    class_type = 'accountIcon';
                    break;
                    case 'update_info_login':
                    class_type = 'accountIcon';
                    break;
                    case 'update_info_personal':
                    class_type = 'accountIcon';
                    break;
                    case 'update_info_security':
                    class_type = 'accountIcon';
                    break;
                    case 'register':
                    class_type = 'accountIcon';
                    break;
                    case 'likeFacebook':
                    class_type = 'likeIcon';
                    break;
                    case 'shareFacebook':
                    class_type = 'shareIcon';
                    break;                       
                    case 'login_daily':
                    class_type = 'calenderIcon';
                    break;
                    case 'first_login':
                    class_type = 'calenderIcon';
                    break;
                    case '3days_login':
                    class_type = 'calenderIcon';
                    break;
                    case '7days_login':
                    class_type = 'calenderIcon';
                    break;
                    case '30days_login':
                    class_type = 'calenderIcon';
                    break;
                    case 'payment':
                    class_type = 'dollarIcon';
                    break;
                    case 'compense_payment':
                    class_type = 'dollarIcon';
                    break;
                    case 'birthday':
                    class_type = 'birthdayIcon';
                    break;
                    case 'reset_cskh':
                    class_type = 'revertIcon';
                    break;
                    case 'play_game_ads':
                    class_type = 'playIcon';
                    break;
                    case 'install_game_ads':
                    class_type = 'dlIcon';
                    break;
                    case 'inviteFriend':
                    class_type = 'emailIcon';
                    break;
                    default:
                    class_type = 'defaultIcon';
                }
                return (
                    <div key={i} className={`taskUser ${i === 0 ? 'first' : ''}`}>
                        <div className="taskUserInner">
                            <div className={`taskIcon taskIcon50 ${class_type} taskInnerLeft`}></div>
                            <p className="rs taskText">{h.time}</p>
                            <h3 className="rs taskName">{h.title}</h3>
                            {Number(h.points) > 0 && (<a className="taskIcon taskCheck taskInnerRight"></a>)}
                        </div>
                        <div className="taskPrize">
                            <span className="taskPrizeCoin">
                                <i className="taskIcon taskCoin"></i> {Number(h.points) > 0 ? `+${Number(h.points)}` : h.points}
                            </span>
                        </div>
                    </div>
                )
            })}
            {!!error.message && (<LineError message={error.message} />)}                
        </div>
    )    
}

export default withHistoryPaymentLayout({
    type:'funcoin',
    api:sync_history_funcoin
})(HistoryUseFuncoinPage);