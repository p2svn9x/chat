import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import {reduxForm,Field,SubmissionError} from 'redux-form';
import {Button} from 'muicss/react';
import Loading from '../Loading';
import {InputField} from '../FormFields';
import { submitVerifyMethodRecovery } from '../../actions/submit';
import { 
    detectLoginType,
    validatePhoneNumber,
    validateEmail,    
    errorFromPhoneNumber
} from '../../helpers/validate';
import {FORM_VERIFY_METHOD_SECURITY} from '../../constants/formid';
import Steps from '../Steps';
import LineErrorMessage from '../LineErrorMessage';

const uniqkey = Math.random().toString(36).substr(2, 6);

const SwitchButton = ({show,onClick,type}) => {
    if (show){
        return (
            <a 
                style={{cursor:'pointer'}} 
                onClick={onClick} 
                className="xacthuc2">
                <i className={type === 'email' ? 'ico-sm-email2' : 'ico-sm-phone2'}></i> 
                Xác thực bằng <span>{type === 'email' ? 'Email' : 'SĐT'}</span>
            </a>
        )
    }
    return null
}
const PhoneMethodForm = reduxForm({
    form:FORM_VERIFY_METHOD_SECURITY,    
    onSubmit: (values,dispatch,{onSubmitForm}) => {
        const errors = {};
        if (!values.phone){
            errors.phone = 'Không được để trống!'
        } else if (!validatePhoneNumber(values.phone)){
            errors.phone = 'Số điện thoại không đúng định dạng!'
        }
        if (Object.keys(errors).length === 0){
            onSubmitForm(values)
        } else {
            throw new SubmissionError(errors)
        }        
    }
})(({handleSubmit,phoneRecovery,onSwitch,errorMessage,isEmailRecovery,change}) => {
    if (!phoneRecovery){
        return null
    }
    return (
        <form onSubmit={handleSubmit}>
            <h3 className="rs tlt-dn">Xác thực số điện thoại</h3>
            <p className="rs txt-dn text-fade">
                Vui lòng nhập số điện thoại của bạn. 
                Chúng tôi sẽ gửi mã xác thực qua tin nhắn
            </p>             
            <LineErrorMessage type="error" message={errorMessage} />         
            <Field 
                name="phone" 
                type="tel"
                placeholder={phoneRecovery} 
                label="Số điện thoại" 
                component={InputField} 
                numberOnly={!0}
                onSetValue={(value) => change('phone',value)}
                onClear={() => change('phone','')}
            />
            <Button className="f-btn-orage f-btn-100 btn-h40">Xác thực</Button>
            <SwitchButton type="email" show={isEmailRecovery} onClick={onSwitch} />
        </form>
    )
})

const EmailMethodForm = reduxForm({
    form:FORM_VERIFY_METHOD_SECURITY,
    onSubmit: (values,dispatch,{onSubmitForm}) => {
        const errors = {};
        if (!values.email){
            errors.email = 'Không được để trống!'
        } else if (!validateEmail(values.email)){
            errors.email = 'Email không đúng định dạng!'
        }
        if (Object.keys(errors).length === 0){
            onSubmitForm(values)
        } else {
            throw new SubmissionError(errors)
        }        
    }    
})(({handleSubmit,emailRecovery,isPhoneRecovery,errorMessage,onSwitch,change}) => {
    if (!emailRecovery){
        return null
    }
    return (
        <form onSubmit={handleSubmit}>
            <h3 className="rs tlt-dn">Xác thực email</h3>
            <p className="rs txt-dn text-fade">
                Vui lòng nhập email của bạn. 
                Chúng tôi sẽ gửi mã xác thực qua email
            </p>
            <LineErrorMessage type="error" message={errorMessage} />
            <Field 
                name="email"
                placeholder={emailRecovery} 
                label="Email" 
                component={InputField}             
                onClear={() => change('email','')}
            />        
            <Button className="f-btn-orage f-btn-100 btn-h40">Xác thực</Button>
            <SwitchButton type="phone" show={isPhoneRecovery} onClick={onSwitch} />
        </form>
    )
})

class VerifyMethodRecovery extends React.Component {
    constructor(props){
        super(props);
        this.dataRecovery = props.dataRecovery; 
        this.step = 1;       
        this.state = {
            loading:!1,
            error:''            
        }           
    }    
    componentWillMount(){
        const {dataRecovery} = this;        
        if (dataRecovery){
            if (!!dataRecovery.phone){
                this.step = 1
            } else {
                this.step = 2
            }
        }        
    }   
    handleResponse = (response,value) => {
        if (!!response.error){
            this.setState({loading:!1,error:response.error.message})
        } else {
            let type = detectLoginType(value);
            this.props.onSelected({
                type,
                data:{
                    userId:this.dataRecovery.userId,
                    [type]:value
                }
            })
        }
    }
    submitHandle = (values) => {       
        if (!!values.phone){
            let err = errorFromPhoneNumber(values.phone);
            if (err){
                this.setState({error:err});
                return !1 
            }                       
        } 
        this.setState({loading:!0,error:''});
        this.props.onSubmitForm(values,this.dataRecovery.userId,(response) => this.handleResponse.call(this,response,values.phone || values.email))
    }
    changestep(step){
       this.setState({error:''});
       this.step = step;
       this.forceUpdate()
    }   
    render(){
        if (!this.dataRecovery || !this.dataRecovery.userId){
            return null
        } 
        const {phone,email} = this.dataRecovery;
        const {loading,error} = this.state; 
        return (
            <div>          
                <Loading isLoading={loading} /> 
                <TransitionGroup>
                    <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                        <Steps order={this.step}>
                            <PhoneMethodForm 
                                step={1}
                                errorMessage={error}
                                onSubmitForm={this.submitHandle.bind(this)} 
                                phoneRecovery={phone} 
                                isEmailRecovery={!!email}
                                onSwitch={() => {this.changestep(2)}}
                            />
                            <EmailMethodForm 
                                step={2}
                                errorMessage={error}
                                onSubmitForm={this.submitHandle.bind(this)} 
                                emailRecovery={email} 
                                isPhoneRecovery={!!phone}
                                onSwitch={() => this.changestep(1)}
                            />
                        </Steps>
                    </CSSTransition>   
                </TransitionGroup> 
            </div>
        )             
    }
}

export default connect(null,(dispatch) => ({
    onSubmitForm:bindActionCreators(submitVerifyMethodRecovery,dispatch)
}))(VerifyMethodRecovery)

VerifyMethodRecovery.defaultProps = {
    onSelected: () => {}
}