import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import Steps from '../Steps';
import MethodRecovery from './MethodRecovery';
import SetPassword from '../SetPassword';
import UpdateSuccess from '../UpdateSuccess';
import VerifyCode from '../VerifyCode';
import {
    request_code_phone,
    verify_old_email,
    verify_code_phone,
    resend_code_phone,
    verify_code_email,
    resendcode_set_new_email,
    update_password    
} from '../../configs/api';
import {
    createdCodeOldPhone,
    createdCodeOldEmail,
    resetDataTemporary, 
    mergeUserTemporary
} from '../../actions/temporary';
import { getTmpFromStorage } from '../../helpers/filters';
import VerifyMethodRecovery from './VerifyMethodRecovery';
import { calcResendTimer } from '../../helpers/utils';

const uniqkey = Math.random().toString(36).substr(2, 6);

const VerifyCodeOldPhone = connect((state) => ({
    createdCodeOldPhone:state.temporary.createdCodeOldPhone
}),null)(({
    phone,    
    userId,
    createdCodeOldPhone,
    onCreatedCodeOldPhone,
    onMergeUserTemporary,    
    onVerified
}) => (
    <VerifyCode 
        step={3} 
        title="Xác thực tài khoản của bạn"
        description={
            `Hệ thống đã gửi mã tới số điện thoại <span>${phone}</span> 
            chưa nhận được vui lòng chờ trong giây lát.`
        }
        buttonText="Xác thực"
        submitAPI={(values) => request_code_phone(values,'forgot_pass',userId)}
        createAPI={() => verify_code_phone('forgot_pass',userId)}
        resendAPI={() => resend_code_phone('forgot_pass',userId)} 
        initTimer={calcResendTimer(createdCodeOldPhone)}
        onCodeCreated={() => {
            onMergeUserTemporary({oldPhone:phone,userId,userType:'forgot'});
            onCreatedCodeOldPhone(Date.now())
        }}                                                                      
        onVerified={onVerified}                                   
    /> 
))

const VerifyCodeOldEmail = connect((state) => ({
    createdCodeOldEmail:state.temporary.createdCodeOldEmail
}),null)(({
    email,    
    userId,
    createdCodeOldEmail,
    onCreatedCodeOldEmail,
    onMergeUserTemporary,    
    onVerified
}) => (
    <VerifyCode 
        step={4} 
        title="Xác thực tài khoản của bạn"
        description={
            `Hệ thống đã gửi mã tới email <span>${email}</span>.  
            Nếu chưa nhận được vui lòng chờ trong giây lát hoặc kiểm tra thư mục Spam.`
        }
        buttonText="Xác thực"
        submitAPI={(values) => verify_old_email(values,'forgot_pass',userId)}
        createAPI={() => verify_code_email('forgot_pass',userId)}
        resendAPI={() => resendcode_set_new_email('forgot_pass',userId)}  
        initTimer={calcResendTimer(createdCodeOldEmail)}
        onCodeCreated={() => {
            onMergeUserTemporary({oldEmail:email,userId:userId,userType:'forgot'});
            onCreatedCodeOldEmail(Date.now())
        }}                                                                      
        onVerified={onVerified}                                    
    /> 
))

class ForgotPasswordPage extends React.Component {
    constructor(){
        super();
        this.step = 1;
        this.dataRecovery = null;            
    }  
    componentWillMount(){       
        const tmp = getTmpFromStorage();        
        if (!!tmp.userId && tmp.userType === 'forgot'){
            if (!!tmp.oldPhone && !!tmp.createdCodeOldPhone){ 
                this.props.onMergeUserTemporary({
                    userId:tmp.userId,
                    olPhone:tmp.oldPhone,
                    userType:'forgot'
                })
                this.props.onCreatedCodeOldPhone(tmp.createdCodeOldPhone);                
                this.dataRecovery = {
                    userId:tmp.userId,
                    phone:tmp.olPhone                       
                }
                this.step = 3                                        
            } else if (!!tmp.oldEmail && !!tmp.createdCodeOldEmail){                
                this.props.onMergeUserTemporary({
                    userId:tmp.userId,
                    oldEmail:tmp.oldEmail,
                    userType:'forgot'
                })        
                this.props.onCreatedCodeOldEmail(tmp.createdCodeOldEmail);              
                this.dataRecovery = {
                    userId:tmp.userId,
                    email:tmp.oldEmail                        
                }
                this.step = 4                                 
            }
        }
    }  
    componentWillUnmount(){
        this.props.onResetDataTemporary()
    }   
    changestep(step){
        this.step = step;      
        this.forceUpdate()
    }   
    handleSelectedMethod = (action) => {
        this.dataRecovery = action.data;
        if (action.type === 'username'){           
            this.changestep(2)
        } else if (action.type === 'phone'){            
            this.changestep(3)
        } else if (action.type === 'email') {            
            this.changestep(4)
        }
    }
    render(){   
        const dataRecovery = this.dataRecovery || {};  
        const {           
            onCreatedCodeOldPhone,
            onCreatedCodeOldEmail,
            onResetDataTemporary,
            onMergeUserTemporary
        } = this.props; 
        return (
            <div className="box-main">
                <div className="box-canhan">                    
                    <TransitionGroup>
                        <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                            <Steps order={this.step}>
                                <MethodRecovery 
                                    step={1} 
                                    onSelected={this.handleSelectedMethod.bind(this)}                                    
                                />
                                <VerifyMethodRecovery 
                                    step={2} 
                                    dataRecovery={this.dataRecovery}                                    
                                    onSelected={this.handleSelectedMethod.bind(this)}
                                />
                                <VerifyCodeOldPhone
                                    step={3} 
                                    phone={dataRecovery.phone}
                                    userId={dataRecovery.userId}
                                    onMergeUserTemporary={onMergeUserTemporary}
                                    onCreatedCodeOldPhone={onCreatedCodeOldPhone}
                                    onVerified={() => {onResetDataTemporary();this.changestep(5)}}
                                 />  
                                <VerifyCodeOldEmail
                                    step={4} 
                                    email={dataRecovery.email}
                                    userId={dataRecovery.userId}
                                    onMergeUserTemporary={onMergeUserTemporary}
                                    onCreatedCodeOldEmail={onCreatedCodeOldEmail}
                                    onVerified={() => {onResetDataTemporary();this.changestep(5)}}
                                 />
                                <SetPassword 
                                    step={5} 
                                    type="FORGOT"
                                    submitAPI={(values) => update_password(values,'forgot_pass',dataRecovery.userId)} 
                                    onSuccess={() => this.changestep(6)} 
                                />
                                <UpdateSuccess step={6} timer={5} title="Đổi mật khẩu thành công" />
                            </Steps>
                        </CSSTransition>
                    </TransitionGroup>
                </div>
            </div>
        )
    }
}
export default connect(null,(dispatch) => ({
    onCreatedCodeOldPhone:bindActionCreators(createdCodeOldPhone,dispatch),
    onCreatedCodeOldEmail:bindActionCreators(createdCodeOldEmail,dispatch),
    onMergeUserTemporary:bindActionCreators(mergeUserTemporary,dispatch),
    onResetDataTemporary:bindActionCreators(resetDataTemporary,dispatch)
}))(ForgotPasswordPage);
