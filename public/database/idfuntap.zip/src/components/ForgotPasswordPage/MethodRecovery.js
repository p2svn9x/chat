import React from 'react';
import { connect } from 'react-redux';
import {reduxForm,Field,SubmissionError} from 'redux-form';
import {Button} from 'muicss/react';
import {InputField} from '../FormFields';
import {SELECT_METHOD_RECOVERY} from '../../constants/formid';
import {detectLoginType} from '../../helpers/validate';
import Loading from '../Loading';
import { bindActionCreators } from '../../../node_modules/redux';
import { submitMethodRecovery } from '../../actions/submit';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors = {};
    if (!values.email){
        errors.email = 'Bạn chưa điền Email/Tên đăng nhập/SĐT'
    } else if (!detectLoginType(values.email)){
        errors.email = 'Nhập sai Email/Tên đăng nhập/SĐT'
    }
    return errors
}

const SelectMethodForm = reduxForm({    
    form:SELECT_METHOD_RECOVERY,
    onSubmit: (values,dispatch,{onSubmitForm}) => {    
        const errors = validate(values);
        if (Object.keys(errors).length === 0){
            onSubmitForm(values)
        } else {
           throw new SubmissionError(errors)
        }              
    }
})(({handleSubmit,change}) => (
    <form onSubmit={handleSubmit}> 
        <Field 
            name="email" 
            label="Email/Tên đăng nhập/SĐT" 
            component={InputField} 
            regex="\s"
            onSetValue={(value) => change('email',value)}
            onClear={() => change('email','')}  
        />       
        <Button className="f-btn-orage f-btn-100 btn-h40">Tiếp tục</Button>
    </form>
))

function recoveryType(data){
    if (!!data && typeof data === 'object'){
        if (data.hasOwnProperty('email') && !!data.hasOwnProperty('phone')){
            return 'username'
        }
        if (!!data.email){
            return 'email'
        }
        if (!!data.phone){
            return 'phone'
        }
    }
    return null
}

class MethodRecoveryPassword extends React.Component {
    state = {
        loading:!1,       
        error:''        
    }     
    handleResponse = (response,values) => {
        if (!!response.error){
            this.setState({loading:!1,error:response.error.message})            
        } else {
            this.setState({loading:!1});
            let type = recoveryType(response.data);
            let data = Object.assign({},response.data);
            if (!!type){
                data.type = type === 'username' ? values.email : response.data[type]
            }
            this.props.onSelected({
                data,
                type
            })
        }
    }
    onSubmitHandle = (values) => {
        this.setState({loading:!0,error:''});
        this.props.onSubmitForm(values,(response) => this.handleResponse.call(this,response,values))
    }
    render(){
        const {loading,error} = this.state;       
        return (
            <div>  
                <Loading isLoading={loading} />
                <p><b>Xác thực tài khoản của bạn</b></p>
                <p>Chọn phương thức nhận mã xác thực</p>
                <LineErrorMessage type="error" message={error} />               
                <SelectMethodForm onSubmitForm={this.onSubmitHandle.bind(this)} />
            </div>                        
        )
    }
}
export default connect(null,(dispatch) => ({
   onSubmitForm:bindActionCreators(submitMethodRecovery,dispatch)
}))(MethodRecoveryPassword);

MethodRecoveryPassword.defaultProps = {
    onSelected:() => {}
}