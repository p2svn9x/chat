import React from 'react';
import { connect } from 'react-redux';
import {Route} from 'react-router';
import {Redirect} from 'react-router-dom';
import { TransitionGroup, CSSTransition } from "react-transition-group";
import ErrorPage from '../ErrorPage';
import { PATH_LOGIN,PATH_DASHBOARD } from '../../constants/pathname';

const Transition =({component:Component,...props}) => {
    return (
        <TransitionGroup>
            <CSSTransition 
                classNames="fade" 
                key={props.location.pathname} 
                timeout={300}                                        
                mountOnEnter={!1} 
                unmountOnExit={!1}>
                <Component {...props} />
            </CSSTransition>
        </TransitionGroup>
    )
}  

function mapStateToProps(state){
    return {
        sync:state.userInfo.sync,
        isAuthenticated:!!state.userInfo.Account
    }
}   

export const GuestRoute = connect(mapStateToProps,null)(
    ({component:Component,isAuthenticated,sync,...rest}) => {        
        return (
            <Route {...rest} render={(props) => {
                if (sync){
                    return <ErrorPage description="Loading..." />
                }
                if (!isAuthenticated){                    
                    return <Transition component={Component} {...props} />                                       
                } else {
                    return <Redirect to={PATH_DASHBOARD} />
                }
            }} 
            />
        )
    }
); 

export const AuthRoute = connect(mapStateToProps,null)(
    ({component:Component,isAuthenticated,sync,...rest}) => (
        <Route {...rest} render={(props) => {
            if (sync){
                return <ErrorPage description="Loading..." />
            }           
            if (isAuthenticated){
                return <Transition component={Component} {...props} />
            } else {
                return <Redirect to={PATH_LOGIN} />
            }
        }} 
        />
    )
);

export const IndexRoute = connect(mapStateToProps,null)(
    ({isAuthenticated,sync,...rest}) => (
        <Route {...rest} render={() => {
            if (sync){
                return <ErrorPage description="Loading..." />
            }           
            if (isAuthenticated){
                return <Redirect to={PATH_DASHBOARD} />
            } else {
                return <Redirect to={PATH_LOGIN} />
            }
        }} 
        />
    )
)
