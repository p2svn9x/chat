import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
//import {Prompt} from 'react-router-dom';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import {Button,Input} from 'muicss/react';
import UpdateSuccess from '../UpdateSuccess';
import VerifyCodeUseEmail from '../VerifyCodeUseEmail';
import VerifyCodeNewEmail from '../VerifyCodeNewEmail';
import UpdateNewEmail from '../UpdateNewEmail';
import ConfirmPassword from '../ConfirmPassword';
import Steps from '../Steps';
import { getUserInfo } from '../../helpers/filters';
import { requestChangeSecurity } from '../../actions/request';
import {change_user_security} from '../../actions/user';
import { maskEmail } from '../../helpers/utils';

const uniqkey = Math.random().toString(36).substr(2, 6);   

const ChangeEmail = connect((state) => ({   
    email:getUserInfo(state,'Security')('email')    
}),null)(({email,onRequest}) => (
    <div>
        <h3 className="rs tlt-dn">Thiết lập email của bạn</h3>
        <p className="rs txt-dn">
            Email khôi phục của bạn được sử dụng để liên lạc 
            với bạn trong trường hợp chúng tôi phát hiện thấy hoạt 
            động bất thường trong tài khoản của bạn hoặc bạn vô tình 
            bị chặn.
        </p>
        <Input value={maskEmail(email)} disabled={!0} />
        <Button className="f-btn-gray f-btn-100" onClick={onRequest}>Thay đổi email</Button>
    </div>
));

class ChangeEmailPage extends React.Component {
    constructor(){
        super();
        this.step = 1; 
        this.changestep = this.changestep.bind(this);
        this.handleRequestChangeSecurity = this.handleRequestChangeSecurity.bind(this);
    }
    componentWillMount(){
        if (this.props.newEmail && this.props.createdCodeNewEmail){
            this.step = 5
        } else if (this.props.createdCodeOldEmail){
            this.step = 3
        }
    }
    changestep(step){
        this.step = step;       
        this.forceUpdate();
    }  
    handleRequestChangeSecurity = (response) => {           
        if (!!response.error){
            if (response.error.code === 1){
                this.changestep(2)
            } else {
                this.changestep(3)
            }
        } else {
            this.changestep(4)
        }
    }
    render(){ 
        const {
            changeSecurity,
            onRequestChangeSecurity,
            newEmail     
        } = this.props;         
        //<Prompt when={!!(this.step > 1 && this.step < 5)} message="Sau khi thoát bạn sẽ phải thực hiện lại toàn bộ từ đầu, bạn có chắc muốn thoát không ?" />    
        return (
            <div>                
                <TransitionGroup>
                    <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                        <Steps order={this.step}>   
                            <ChangeEmail 
                                step={1} 
                                onRequest={() => onRequestChangeSecurity(this.handleRequestChangeSecurity)} 
                            />
                            <ConfirmPassword 
                                step={2} 
                                show={!0}
                                onConfirmed={() => onRequestChangeSecurity(this.handleRequestChangeSecurity)} 
                            />
                            <VerifyCodeUseEmail
                                step={3}
                                onVerified={() => this.changestep(4)}
                            />                                  
                            <UpdateNewEmail                         
                                step={4}                                  
                                onReverify={() => this.changestep(3)}                                                                                                                                           
                                onNext={() => this.changestep(5)}                         
                            />
                            <VerifyCodeNewEmail
                                step={5} 
                                type="update_email"
                                newEmail={newEmail}                                                              
                                onVerified={() => this.changestep(6)}
                                onReverify={() => this.changestep(3)}
                            />
                            <UpdateSuccess 
                                step={6} 
                                timer={5} 
                                title="Thay đổi email thành công"
                                onRemove={() => {                                    
                                    changeSecurity({email:newEmail,new_email:''})
                                }} 
                            />                
                        </Steps>  
                    </CSSTransition>   
                </TransitionGroup> 
            </div>   
        )
    }
}

export default connect((state) => ({
    newEmail:getUserInfo(state,'Security')('new_email'),
    createdCodeNewEmail:state.temporary.createdCodeNewEmail,
    createdCodeOldEmail:state.temporary.createdCodeOldEmail
}),(dispatch) => ({
    onRequestChangeSecurity: bindActionCreators(requestChangeSecurity,dispatch),
    changeSecurity: bindActionCreators(change_user_security,dispatch) 
}))(ChangeEmailPage);