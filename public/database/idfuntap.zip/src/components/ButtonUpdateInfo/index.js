import React from 'react';
import moment from 'moment';
import {Link} from 'react-router-dom'; 
import Modal from '../Modal';
import {
    PATH_UPDATE_EMAIL,
    PATH_UPDATE_PHONE,
    PATH_UPDATE_PASSWORD,
    PATH_TWO_STEP_VERIFICATION,
    PATH_PERSONAL_INFORMATION
} from '../../constants/pathname';
import { maskEmail, maskPhone } from '../../helpers/utils';

const ButtonUpdateInfo = ({to,label,verified,onClick,smallText,bigText}) => {
    return (
        <Link to={to} onClick={onClick} className={`ripple ripple1 txt-dual ${verified ? 'bm-done' : 'txt-dual--text-noticer'}`}>
            <i className="ico-noticer"></i>{label}
            <br />
            {bigText && (<span className="text-noticer">{bigText}</span>)}
            {smallText && (<span>{smallText}</span> )}                           
        </Link>
    )
}
ButtonUpdateInfo.defaultProps = {
    onClick: () => {}
}

export const ButtonEmail = ({email,email_verified}) => (
    <ButtonUpdateInfo 
        to={PATH_UPDATE_EMAIL}
        verified={email_verified}
        label="Email"
        smallText={email ? maskEmail(email) : 'Chưa có email'}
        bigText={!email_verified ? (email ? 'Xác thực' : 'Thêm mới') : ''}         
    />
)

export const ButtonPhone = ({phone,phone_verified}) => (
    <ButtonUpdateInfo 
        to={PATH_UPDATE_PHONE}
        verified={phone_verified}
        label="Số điện thoại"
        smallText={phone ? maskPhone(phone) : 'Chưa có số điện thoại'}
        bigText={!phone_verified ? (phone ? 'Xác thực' : 'Thêm mới') : ''}         
    />
)

export const ButtonPassword = ({password,modified}) => (
    <ButtonUpdateInfo 
        to={PATH_UPDATE_PASSWORD}
        verified={password}
        label="Mật khẩu"
        smallText={password ? (modified ? `Thay đổi lần cuối ${moment(Number(modified)*1000).format('DD/MM/YYYY')}` : 'Thay đổi mật khẩu') : 'Chưa có mật khẩu'}
        bigText={!password ? 'Thiết lập' : ''}         
    />
)

export const ButtonPersonal = ({completed}) => (
    <ButtonUpdateInfo 
        to={PATH_PERSONAL_INFORMATION}
        verified={completed}
        label="Thông tin cá nhân"
        smallText={completed ? 'Bạn đã hoàn thành' : 'Chưa nhập thông tin cá nhân'}
        bigText={!completed ? 'Cập nhật' : ''}         
    />
)

export class ButtonTwoStep extends React.Component {
    state = {
        modal:!1
    }
    render(){
        const {two_step,unaccess} = this.props;
        const {modal} = this.state;
        return (
            <div>
                <ButtonUpdateInfo 
                    to={PATH_TWO_STEP_VERIFICATION}
                    verified={two_step}
                    label="Bảo mật 2 bước"
                    smallText={two_step ? 'Bật' : 'Tắt'}
                    bigText={!two_step ? 'Bật' : ''} 
                    onClick={(e) => {
                        if (unaccess){
                            e.preventDefault();
                            this.setState({modal:!0})                                                           
                        }
                    }}        
                />
                {modal && (
                    <Modal 
                        message="Bạn cần cập nhập thông tin đăng nhập, thông tin bảo mật trước khi bật xác thực 2 lớp" 
                        onClose={() => this.setState({modal:!1})} 
                    />
                )}
            </div>
        )
    }
}
