import React from 'react';
//import {connect} from 'react-redux';
import {withRouter} from 'react-router';
import {Link} from 'react-router-dom';
import Appbar from 'muicss/lib/react/appbar';
import Container from 'muicss/lib/react/container';
import HeaderAccount from '../HeaderAccount';
import HelMet from '../HelMet';
import Sidebar from './Sidebar';
//import {getFormNames} from 'redux-form';
import set_title from '../../helpers/setTitle';
import { 
    PATH_DASHBOARD,     
    PATH_LOGIN, 
    PATH_REGISTER
    // PATH_UPDATE_EMAIL,
    // PATH_UPDATE_PASSWORD,
    // PATH_UPDATE_PHONE
    //PATH_FORGOT_PASSWORD   
} from '../../constants/pathname';
//import {  FORM_VERIFY_CODE_CREATE } from '../../constants/formid';
import {matchPath} from '../../helpers/utils'; 
//import { getSDKoption, getWebOption } from '../../helpers/filters';

const BackButton = ({history}) => (
    <a onClick={() => { 
        history.goBack();         
    }} className="sidedrawer-toggle f-ico-back f-ico-arr-back spr click-animation" />
)

const HeaderTitle = ({pathname}) => {    
    if (pathname.replace(/\//g,'') === PATH_DASHBOARD.replace(/\//g,'')){
        return (<h1><a className="f-logo">{set_title(pathname)}</a></h1>)
    } else {
        return (<h1><a>{set_title(pathname)}</a></h1>)
    }
} 

const Jumbotron = ({show}) => {
    if (show){
        return (
            <div className="header-first">
                <Link className="header-first-logo" to={PATH_LOGIN}></Link>
            </div>
        )
    }
    return null
}  

const Header = ({location:{pathname},history}) => {
    let showHeader = !0;
    let showJumbotron = !1;     
    if (pathname === '/' || matchPath(pathname,PATH_LOGIN) || matchPath(pathname,PATH_REGISTER)){
        showHeader = !1;
        showJumbotron = !0;
    } 
    let headerStyle = {display:showHeader ? 'block' : 'none'};
    return ( 
        <div> 
            <header style={headerStyle} id="header" className="header-shadow">            
                <Appbar className="mui--appbar-line-height">
                    <Container fluid={!0}>
                        <div className="header-container">
                            {matchPath(pathname,PATH_DASHBOARD) ? 
                                <Sidebar /> : <BackButton history={history} pathname={pathname} />
                            }                    
                            <div className="mui--text-title f-txtheader">
                            <HeaderTitle pathname={pathname} />
                            </div>   
                            <HeaderAccount />   
                        </div>                                  
                    </Container>
                </Appbar>                    
            </header>
            <HelMet pathname={pathname} />
            <div className="mui--appbar-height" style={headerStyle}></div>
            <Jumbotron show={showJumbotron} />  
        </div>
    )    
} 
export default withRouter(Header);