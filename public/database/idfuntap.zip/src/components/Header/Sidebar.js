
import React from 'react';
import {NavLink,Link} from 'react-router-dom';
import overlayFn from 'muicss/lib/js/overlay';
import {    
    //PATH_DIRECT_PAYMENT, 
    PATH_HISTORY_USE_FUNCOIN, LINK_DIRECT_PAYMENT, LINK_HISTORY_TOPUP, 
    //PATH_HISTORY_TOPUP 
} from '../../constants/pathname';

const ALink = ({href,label,icon}) => (
    <li>
        <a className="ripple" href={href} target="_blank" rel="noopener noreferrer"><i className={`spr f-ico ${icon}`}></i>{label}</a>
    </li>
)
const LinkApp = ({to,label,icon}) => (
    <li>
        <Link className="ripple" to={to}><i className={`spr f-ico ${icon}`}></i>{label}</Link>
    </li>
)
const NavLinkApp = ({to,label,icon}) => (
    <li>
        <NavLink className="ripple" activeClassName="active" to={to} onClick={() => overlayFn('off')}>
            <i className={`spr f-ico ${icon}`}></i> {label}
        </NavLink>
    </li>
)

class Sidebar extends React.Component {
    componentWillUnmount(){ 
        overlayFn('off');   
        if (document.getElementById('sidedrawer')) document.getElementById('sidedrawer').remove();    
    }
    showSidebar = (e) => {
        e.preventDefault();        
        var sidedrawer = this.refs.sidedrawer;           
        const options = {
            onclose: function() {
                sidedrawer.classList.remove('active');                
                document.body.appendChild(sidedrawer);
            }
        }         
        const overlay = overlayFn('on', options);     
        overlay.appendChild(sidedrawer);
        setTimeout(function() {
            sidedrawer.classList.add('active');
        }, 20);
    }    
    render(){      
        return (
            <React.Fragment>
                <a className="sidedrawer-toggle js-show-sidedrawer click-animation f-ico-touch" onClick={this.showSidebar} />
                <div style={{display:'none'}} ref="sidedrawwrap">
                    <div id="sidedrawer" className="mui--no-user-select" ref="sidedrawer">
                        <div className="mui-divider"></div>
                        <ul>
                            <NavLinkApp to="/" icon="f-ico-home" label="Trang chủ" />
                            <ALink href={LINK_DIRECT_PAYMENT} icon="f-ico-tt" label="Tài khoản TTTT" /> 
                            <LinkApp to={PATH_HISTORY_USE_FUNCOIN} icon="f-ico-fc" label="Tài khoản Funcoin" />
                            <ALink href="https://khtt.funtap.vn/" icon="f-ico-khtt" label="Khách hàng thân thiết" />                                
                            <ALink href={LINK_HISTORY_TOPUP} icon="f-ico-ls" label="Lịch sử nạp" />
                            <ALink href="https://gc.funtap.vn" icon="f-ico-gc" label="Nhận & đổi giftcode" /> 
                            <ALink href="https://hotro.funtap.vn" icon="f-ico-bl" label="Hỗ trợ" />     
                        </ul>
                    </div>
                </div>                
            </React.Fragment>
          )
    }
}
export default Sidebar;