import React from 'react';
//import {compose} from 'redux';
//import {connect} from 'react-redux';
//import {withRouter} from 'react-router';
import {Helmet} from 'react-helmet';
import { 
    PATH_LOGIN,
    PATH_REGISTER,
    PATH_FORGOT_PASSWORD,
    PATH_DASHBOARD,
    PATH_PERSONAL_INFORMATION,
    PATH_SECURITY_INFORMATION,
    PATH_UPDATE_EMAIL,
    PATH_UPDATE_PHONE,
    PATH_UPDATE_PASSWORD,
    PATH_TWO_STEP_VERIFICATION,
    // PATH_DIRECT_PAYMENT,
    // PATH_CREATE_DIRECT_PAYMENT,
    PATH_RECENT_DEVICES,
    PATH_RECENT_GAMES,
    PATH_HISTORY_USE_FUNCOIN,
    //PATH_HISTORY_TOPUP,
    PATH_RECENT
} from '../../constants/pathname';
import {matchPath} from '../../helpers/utils';
import google_tag from '../../configs/googletag';


const setMeta = (pathname) => {
    let meta = {};
    if (pathname === '/'){
        meta = {}
    } else if (matchPath(pathname,PATH_LOGIN)){
        meta = {
            title:'Đăng nhập | Funtap',
            description:'Đăng nhập tài khoản FunID'
        }
    } else if (matchPath(pathname,PATH_REGISTER)){
        meta = {
            title:'Đăng ký | Funtap',
            description:'Đăng ký tài khoản FunID'
        }
    } else if (matchPath(pathname,PATH_FORGOT_PASSWORD)){
        meta = {
            title:'Quên mật khẩu | Funtap',
            description:'Quên mật khẩu FunID'
        }
    } else if (matchPath(pathname,PATH_DASHBOARD)){
        meta = {
            title:'Dashboard | Funtap',
            description:'Dashboard FunID'
        }
    } else if (matchPath(pathname,PATH_PERSONAL_INFORMATION)){
        meta = {
            title:'Thông tin cá nhân | Funtap',
            description:'Thông tin cá nhân FunID'
        }
    } else if (matchPath(pathname,PATH_SECURITY_INFORMATION)){
        meta = {
            title:'Thông tin bảo mật | Funtap',
            description:'Thông tin bảo mật FunID'
        }
    } else if (matchPath(pathname,PATH_UPDATE_EMAIL)){
        meta = {
            title:'Cập nhật email bảo mật | Funtap',
            description:'Cập nhật email bảo mật FunID'
        }
    } else if (matchPath(pathname,PATH_UPDATE_PHONE)){
        meta = {
            title:'Cập nhật số điện thoại bảo mật | Funtap',
            description:'Cập nhật số điện thoại bảo mật FunID'
        }
    } else if (matchPath(pathname,PATH_UPDATE_PASSWORD)){
        meta = {
            title:'Cập nhật mật khẩu | Funtap',
            description:'Cập nhật mật khẩu FunID'
        }
    } else if (matchPath(pathname,PATH_TWO_STEP_VERIFICATION)){
        meta = {
            title:'Bảo mật hai lớp | Funtap',
            description:'Bảo mật hai lớp FunID'
        }
    } else 
    // if (matchPath(pathname,PATH_DIRECT_PAYMENT)){
    //     meta = {
    //         title:'Thanh toán trực tiếp | Funtap',
    //         description:'Thanh toán trực tiếp Funtap'
    //     }
    // } else if (matchPath(pathname,PATH_CREATE_DIRECT_PAYMENT)){
    //     meta = {
    //         title:'Yêu cầu thanh toán trực tiếp | Funtap',
    //         description:'Yêu cầu thanh toán trực tiếp Funtap'
    //     }
    // } else 
    if (matchPath(pathname,PATH_RECENT_DEVICES)){
        meta = {
            title:'Thiết bị đã truy cập | Funtap',
            description:'Thiết bị đã truy cập FunID'
        }
    } else if (matchPath(pathname,PATH_RECENT_GAMES)){
        meta = {
            title:'Games đã chơi gần đây | Funtap',
            description:'Games đã chơi gần đây'
        }
    } else if (matchPath(pathname,PATH_HISTORY_USE_FUNCOIN)){
        meta = {
            title:'Lịch sử Funcoin | Funtap',
            description:'Lịch sử Funcoin'
        }
    } else 
    // if (matchPath(pathname,PATH_HISTORY_TOPUP)){
    //     meta = {
    //         title:'Lịch sử nạp | Funtap',
    //         description:'Lịch sử nạp'
    //     }
    // } else 
    if (matchPath(pathname,PATH_RECENT)){
        meta = {
            title:'Lịch sử đăng nhập | Funtap',
            description:'Lịch sử đăng nhập'
        }
    } else {
        meta = {
            title: '404 | Funtap',
            description:'404'
        }
    }
    
    return meta
}

class HelMetInner extends React.Component {
    componentWillMount(){
        if (this.props.meta.title){
            google_tag(this.props.meta.title,this.props.pathname)        
            //console.log('Set Google Tag: ' + JSON.stringify(this.props.meta));   
        }
    }
    componentDidUpdate(prevProps){
        if (this.props.pathname !== prevProps.pathname || this.props.meta.title !== prevProps.meta.title){
            if (this.props.meta.title){
                //console.log('Set Google Tag: ' + JSON.stringify(this.props.meta));
                google_tag(this.props.meta.title,this.props.pathname)                
            } 
        }
    }
    render(){
        const {pathname,meta} = this.props;        
        //let meta = setMeta(pathname);        
        return (
            <Helmet>
                <title>{meta.title}</title>            
                <meta name="description" content={meta.description} />
                <meta name="og:site_name" content="ID Funtap" />
                <meta name="og:type" content="article" />
                <meta name="og:title" content={meta.title} />
                <meta name="og:url" content={`https://id.funtap.vn${pathname}`} />
                <meta name="og:description" content={meta.description} />
                <meta name="og:image" content="http://funtap.vn/uncommon/funtap/images/funtap.jpg" />
                <link href={`https://id.funtap.vn${pathname}`} rel="canonical" />            
            </Helmet>
        )
    }
}

const HelMet = ({pathname}) => {
    const meta = setMeta(pathname);
    return (
        <HelMetInner pathname={pathname} meta={meta} />
    )
}

export default HelMet;