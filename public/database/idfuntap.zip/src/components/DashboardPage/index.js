import React from 'react';
//import moment from 'moment';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {Link} from 'react-router-dom';
import FacebookLogin from 'react-facebook-login/dist/facebook-login-render-props';
import Notification from '../Notification';
import {formatMoney, isTestMode} from '../../helpers/utils';
//import default_ava from '../../assets/images/mob/ico-ava.svg';
import {Collapse} from 'react-collapse';
//import Modal from '../Modal';
import { 
    PATH_PERSONAL_INFORMATION, 
    PATH_SECURITY_INFORMATION, 
    // PATH_UPDATE_EMAIL, 
    // PATH_UPDATE_PHONE, 
    // PATH_UPDATE_PASSWORD, 
    // PATH_TWO_STEP_VERIFICATION,
    //PATH_DIRECT_PAYMENT,
    PATH_HISTORY_USE_FUNCOIN,
    PATH_RECENT,
    LINK_DIRECT_PAYMENT
    //PATH_DASHBOARD
} from '../../constants/pathname';
import { FB_APPID, FB_APP_VERSION, FB_APP_LOCALE } from '../../configs/facebook';
import { requestConnectFacebook } from '../../actions/request';
import Loading from '../Loading';
import { ButtonEmail, ButtonPhone, ButtonPassword, ButtonPersonal, ButtonTwoStep } from '../ButtonUpdateInfo';

const UserInfo = ({userInfo}) => {    
    var fw = userInfo.Account.username.charAt(0).toUpperCase();    
    var icon_member = 'icoNormal';
    var member = 'Hội viên';
    switch(Number(userInfo.Funcoin.member)){
        case 1:
        icon_member = 'icoNormal';
        member = 'Hội viên';
        break;
        case 2:
        icon_member = 'icoSilver1';
        member = 'Silver 1';
        break;
        case 3:
        icon_member = 'icoSilver2';
        member = 'Silver 2';
        break;
        case 4:
        icon_member = 'icoSilver3';
        member = 'Silver 3';
        break;
        case 5:
        icon_member = 'icoGold1';
        member = 'Gold 1';
        break;
        case 6:
        icon_member = 'icoGold2';
        member = 'Gold 2';
        break;
        case 7:
        icon_member = 'icoGold3';
        member = 'Gold 3';
        break;
        case 8:
        icon_member = 'icoPlatinum';
        member = 'Platinum';
        break;
        default: 
        icon_member = 'icoNormal';
        member = 'Hội viên';
    }        
    //<img style={{borderRadius:'50%'}} src={default_ava} alt={userInfo.Account.username} className="img-fix" />
    return (    
        <div className="userDesc">
			<div className="userInfo mui--clearfix">
				<div className={`userAvatar userAvatarLetter ${fw}`}>				
					{fw}
				</div>
				<div className="userInfoName">
					<p className="txt-userInfoName">
                        <span className="txt-userInfoNameIn">{userInfo.Account.username}</span> 
                    </p>
					<p className="txt-userInfoId">ID: {userInfo.Account.id}</p>
					<p className="txt-userInfoVip">Hạng thành viên: <strong>{member}</strong></p>
				</div>
			</div>
			<div className="userMedal mui--clearfix">
				<div className="userType mui--text-center">
					<p className="txt-userRank rs">{formatMoney(userInfo.Payment.money)} <i className="ico-thoc"></i></p>
					<p className="rs"><a href={LINK_DIRECT_PAYMENT} target="_blank">TK TTTT</a></p>
				</div>
				<div className="userTypeMember"><i className={`icoMember ${icon_member}`}></i></div>
				<div className="userCoin mui--text-center">
					<p className="txt-userRank rs">{formatMoney(userInfo.Funcoin.funcoin_wallet)} <i className="ico-fc"></i></p>
					<p className="rs"><Link to={PATH_HISTORY_USE_FUNCOIN}>TK FunCoin</Link></p>
				</div>
			</div>
		</div>
    )
}

class Tasks extends React.Component {   
    state = {
        show:!1
    }   
    render(){        
        const {show} = this.state;
        const {security,profile_completed} = this.props;    
        const inTestMode = isTestMode();   
        const email_verified = security.email_verified && !!security.email;
        return (
            <div style={{position:'relative',zIndex:'10',borderBottom:'solid 1px #eee'}}>                
                    <ul className="rs lstTask" style={{borderBottom:0}}> 
                        <Collapse isOpened={email_verified ? show : !0}>           
                        <li>
                            <ButtonEmail email={security.email} email_verified={email_verified} />                            
                        </li>
                        </Collapse>
                        <Collapse isOpened={security.phone_verified ? show : !0}>
                        <li>
                            <ButtonPhone phone={security.phone} phone_verified={security.phone_verified} />                            
                        </li>
                        </Collapse>
                        <Collapse isOpened={security.password ? show: !0}>
                        <li>
                            <ButtonPassword password={security.password} modified={security.modified_password} />                            
                        </li>
                        </Collapse>
                        <Collapse isOpened={profile_completed ? show : !0}> 
                        <li>
                            <ButtonPersonal completed={profile_completed} />                           
                        </li>
                        </Collapse>   
                        {inTestMode && (
                            <Collapse isOpened={security.two_step ? show : !0}>
                                <li>
                                   <ButtonTwoStep two_step={security.two_step} unaccess={!security.password || (!email_verified && !security.phone_verified)} />
                                </li>  
                            </Collapse>
                        )}       
                    </ul>  
                <a onClick={() => this.setState({show:!show})} className={show ? "btn-toggle" : "btn-toggle active"} style={{cursor:'pointer',top:'auto',bottom:'-16px'}}></a>
            </div>
        )
    }
} 

const SecurityLevelDesc = ({completed}) => {
    if (completed === 100){
        return (
            <p className="rs">Tuyệt quá! Tài khoản của bạn đã ở mức bảo mật cao nhất</p>
        )
    } else if (completed >= 75){
        return (
            <p className="rs">Tăng cường mức độ bảo mật bằng cách hoàn thiện thông tin đăng nhập và thông tin cá nhân</p>
        )
    } else {
        return (
            <p className="rs">Tài khoản của bạn hiện tại có thể bị đe dọa bảo mật. Hãy hoàn thiện các thông tin bên dưới</p>
        )
    }
}
const SecurityLevelCricle = ({completed}) => {
    let color = 'red';
    let title = 'YẾU';   
    if (completed === 100){
        color = 'green';
        title = 'MẠNH'
    } else if (completed >= 75){
        color = 'orange';
        title = <span>TRUNG<br/>BÌNH</span>
    }
    return (
        <div className={`c100 p${completed} small ${color}`}>
            <span>{title}</span>
            <div className="slice">
                <div className="bar"></div>
                <div className="fill"></div>
            </div>
        </div>
    )
}

const SecurityLevel = ({security,profile_completed}) => { 
    const inTestMode = isTestMode();
    let completed = inTestMode ? 0 : 15; 

    if (security.password) completed = completed + 10;
    if (security.two_step && inTestMode) completed = completed + 15;  
    if (security.email) completed = completed + 15;   
    if (security.email_verified && !!security.email) completed = completed + 15;
    if (security.phone) completed = completed + 15;  
    if (security.phone_verified) completed = completed + 15;
    if (profile_completed) completed = completed + 15;   
    return (    
        <div className="box-tb-baomat">
            <div style={{position:'absolute',left:'16px',top:'25px'}}>
                <SecurityLevelCricle completed={completed} /> 
            </div>
            <h3 className="rs">Mức độ bảo mật </h3>
            <SecurityLevelDesc completed={completed} />
        </div>
    )
} 

class ConnectFacebookButton extends React.Component {
    constructor(){
        super();       
        this.state = {
            loading:!1,
            error:''
        }       
    }      
    setErrorServer(message){
        this.setState({
            loading:!1,
            error:message
        })
    } 
    handleResponse = (response) => {
        if (!!response.error){
            this.setErrorServer(response.error.message)            
        } else {
            this.setState({loading:!1})
        }
    }
    handleConnectFB(response){ 
        if (!!response.accessToken && !this.requesting){             
            this.setState({loading:!0});
            this.props.onRequestConnectFacebook(response.accessToken,this.handleResponse.bind(this))
        } else {
            this.setErrorServer('Quyền truy cập thông tin từ Facebook bị từ chối!')            
        }
    }
    render(){
        const {reward} = this.props;
        const {loading,error} = this.state;
        //<button onClick={() => this.handleConnectFB({accessToken:'123456'})}>Test ket noi FB</button>     
        return (
            <li>
                <Loading isLoading={loading} />               
                {!!error && <Notification notification={{type:'error',message:error}} remove={() => this.setState({error:''})} />}
                <FacebookLogin 
                    appId={FB_APPID}
                    version={FB_APP_VERSION} 
                    language={FB_APP_LOCALE}
                    isMobile={!1}    
                    xfbml={!0}                
                    render={renderProps => (
                        <a style={{cursor:'pointer'}} onClick={renderProps.onClick} className="ico-bm-fb">
                            <strong>Kết nối với Facebook {Number(reward) > 0 && (<i className="ico-add-fc">+ {reward}</i>)}</strong>
                            <span>Kết nối với Facebook để đăng nhập nhanh hơn và kết nối với bạn bè</span>
                        </a>                       
                      )}                    
                    scope="public_profile,email"
                    callback={this.handleConnectFB.bind(this)}
                />                           
            </li>
        )
    }
}
const ConnectFacebook = connect(null,(dispatch) => ({  
    onRequestConnectFacebook:bindActionCreators(requestConnectFacebook,dispatch)    
}))(ConnectFacebookButton);


const SecurityBox = ({reward}) => {
    return (    
        <div className="box-baomat-home">         
            <ul className="rs lst-baomat-home">
                <li>
                    <Link to={PATH_SECURITY_INFORMATION} className="ico-bm-dn">
                        <strong>Đăng nhập, mật khẩu và bảo mật {Number(reward.security_info) > 0 && (<i className="ico-add-fc">+ {reward.security_info}</i>)}</strong>
                        <span>Cài đặt thông tin đăng nhập, mật khẩu và bảo mật tài khoản</span>
                    </Link>
                </li>
                <li>
                    <Link to={PATH_PERSONAL_INFORMATION} className="ico-bm-cn">
                        <strong>Thông tin cá nhân {Number(reward.profile_info) > 0 && (<i className="ico-add-fc">+ {reward.profile_info}</i>)}</strong>
                        <span>Cập nhật thông tin cá nhân đầy đủ, kịp thời giúp bảo vệ tài khoản và được hỗ trợ nhanh chóng</span>
                    </Link>
                </li>  
                <li>
                    <Link to={PATH_RECENT} className="ico-bm-lg">
                        <strong>Lịch sử đăng nhập</strong>
                        <span>Kiểm tra lịch sử đăng nhập tài khoản FunID của bạn</span>
                    </Link>
                </li>                     
                {Number(reward.connect_facebook) > 0 && (<ConnectFacebook reward={Number(reward.connect_facebook)} />)}
            </ul>
        </div>
    )
} 

const DashboardPage = ({userInfo}) => {
    const profile = userInfo.Profile || {};
    var profile_completed = !1;
    if (
        profile.fullname && 
        profile.birthday && 
        profile.gender && 
        profile.province && 
        profile.district && 
        profile.address && 
        profile.peopleId && 
        profile.peopleId_place_get &&
        profile.peopleId_date_get
    ){
        profile_completed = !0
    } 
    return (
        <div className="box-main">
            <UserInfo 
                userInfo={{
                    Account:userInfo.Account,
                    Profile:userInfo.Profile,
                    Security:userInfo.Security,
                    Funcoin:userInfo.Funcoin,
                    Payment:userInfo.Payment,
                    Reward:userInfo.Reward
                }} 
                profile_completed={profile_completed} 
            />
            <div className="userTask">
                <SecurityLevel 
                    security={userInfo.Security} 
                    profile_completed={profile_completed}                    
                />
                <Tasks 
                    security={userInfo.Security} 
                    profile_completed={profile_completed}                    
                />
                <SecurityBox reward={userInfo.Reward} />    
            </div>
        </div>
    )
} 

export default connect((state) => ({       
    userInfo: state.userInfo
}),null)(DashboardPage);