import React from 'react';
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import VerifyCode from '../VerifyCode';
import {    
    verify_set_new_email,    
    resendcode_set_new_email
} from '../../configs/api';
//import ConfirmPassword from '../ConfirmPassword';
import {setSessionOTP} from '../../actions/session';
import {createdCodeNewEmail,removeCodeNewEmail} from '../../actions/temporary';
import { calcResendTimer, maskEmail } from '../../helpers/utils';
const VerifyCodeNewEmail = ({
    type,
    onVerified,
    onReverify,
    onSetSessionOTP,
    onCreatedCodeNewEmail,
    onRemoveCodeNewEmail,
    createdCodeNewEmail,
    newEmail
}) => ( 
    <VerifyCode                          
        title="Xác thực tài khoản của bạn"
        description={
            `Hệ thống đã gửi mã tới email mới <span>${maskEmail(newEmail)}</span> 
            Nếu chưa nhận được vui lòng chờ trong giây lát hoặc kiểm tra thư mục Spam`
        }
        buttonText="Hoàn tất"
        submitAPI={(values) => verify_set_new_email(values,type)}
        resendAPI={() => resendcode_set_new_email(type)}       
        onCodeCreated={() => onCreatedCodeNewEmail(newEmail)}        
        initTimer={calcResendTimer(createdCodeNewEmail) || 60}
        onVerified={() => {onSetSessionOTP();onRemoveCodeNewEmail();onVerified()}}
        onReverify={() => onReverify()}       
    />              
);   


export default connect((state) => ({   
    createdCodeNewEmail:state.temporary.createdCodeNewEmail
}),(dispatch) => ({
    onSetSessionOTP:() => bindActionCreators(setSessionOTP,dispatch)(Date.now()),
    onCreatedCodeNewEmail:(email) => bindActionCreators(createdCodeNewEmail,dispatch)(Date.now(),email),
    onRemoveCodeNewEmail:bindActionCreators(removeCodeNewEmail,dispatch)
}))(VerifyCodeNewEmail);

VerifyCodeNewEmail.defaultProps = {
    type:'',
    newEmail:'',
    onVerified:() => {},
    onReverify:() => {}
}