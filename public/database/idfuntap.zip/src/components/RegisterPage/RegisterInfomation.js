import React from 'react';
import moment from 'moment';
import {bindActionCreators,compose} from 'redux';
import { connect } from 'react-redux';
import {Button} from 'muicss/react';
import {reduxForm,Field,stopSubmit,getFormValues,clearAsyncError,SubmissionError} from 'redux-form';
import {FORM_REGISTER_INFORMATION,FORM_REGISTER_ACCOUNT} from '../../constants/formid';
import {InputField,SelectProvince,InputDateField} from '../FormFields';
import Title from './Title';
import BottomForm from './BottomForm';
import Loading from '../Loading';
import {
    validateFullname,
    validateDatetime,
    validateAddress,
    validatePeopleId,
    validateProvince
} from '../../helpers/validate';
import {registerAccount} from '../../configs/api';
import LineErrorMessage from '../LineErrorMessage';
import {prefixProvince} from '../../helpers/utils';

const validate = (values) => {
    const errors = {};   
    if (!values.fullname){
        errors.fullname = 'Chưa điền họ tên!'
    } else if (!validateFullname(values.fullname)) {
        errors.fullname = 'Họ và tên không đúng định dạng!'
    } else if (values.fullname.length < 3){
        errors.fullname = 'Họ và tên quá ngắn!'
    } 
    if (!values.birthday){
        errors.birthday = 'Chưa chọn ngày tháng năm sinh!'
    } else if (!validateDatetime(values.birthday)){
        errors.birthday = 'Ngày tháng năm sinh không hợp lệ!'
    }
    if (!values.address){
        errors.address = 'Không được để trống!'
    } else if (!validateAddress(values.address)){
        errors.address = 'Địa chỉ không đúng định dạng!'
    }
    if (!values.peopleId){
        errors.peopleId = 'Chưa điền CMND/CCCD/Hộ chiếu'
    } else if (!validatePeopleId(values.peopleId)){
        errors.peopleId = 'CMND/CCCD/Hộ chiếu chưa đúng định dạng'
    }
    if (!values.peopleId_place_get){
        errors.peopleId_place_get = 'Không được để trống!'
    } else if (!validateProvince(values.peopleId_place_get)){
        errors.peopleId_place_get = 'Nơi cấp không có trong danh sách chọn!'
    }
    if (!values.peopleId_date_get){
        errors.peopleId_date_get = 'Không được để trống!'
    } else if (!validateDatetime(values.peopleId_date_get)){
        errors.peopleId_date_get = 'Ngày cấp không hợp lệ!'
    }
    return errors
}

const RegisterInformationForm = compose(
    connect((state) => {
        var provinces = [];
        provinces = state.direction.data.map((province) => ({province_name:province.province_name,province_id:province.province_id})); 
        return {provinces}
    },null),
    reduxForm({
        form:FORM_REGISTER_INFORMATION, 
        onSubmit:(values,dispatch,{onRequest}) => {
            const errors = validate(values);
            if (Object.keys(errors).length === 0){
                onRequest(values)
            } else {
                throw new SubmissionError(errors)
            }            
        }
    })
)(({handleSubmit,change,provinces}) => (
    <form onSubmit={handleSubmit} className="regis-form">
        <Field 
            name="fullname" 
            label="Họ và tên" 
            component={InputField}
            onClear={() => change('fullname','')}
        /> 
        <Field 
            name="birthday" 
            label="Ngày sinh" 
            component={InputDateField} 
            onSetValue={(value) => change('birthday',value)}
        />       
        <Field 
            name="address" 
            label="Địa chỉ thường trú" 
            component={InputField} 
            onClear={() => change('fullname','')}
        />
        <Field 
            name="peopleId" 
            label="CMT/CCCD/Hộ chiếu" 
            component={InputField} 
            onClear={() => change('fullname','')}
        />
        <Field 
            name="peopleId_place_get" 
            label="Nơi cấp" 
            options={provinces} 
            component={SelectProvince} 
        />
        <Field 
            name="peopleId_date_get" 
            label="Ngày cấp" 
            component={InputDateField} 
            onSetValue={(value) => change('peopleId_date_get',value)}
        />
        <Button className="f-btn-orage f-btn-100 btn-h40">Hoàn thành</Button>
    </form>
))
    
 


class RegisterInformation extends React.Component {
    state = {
        requesting:!1,
        error:''     
    }
    setErrorResponseServer(message){
        this.setState({requesting:!1,error:message})
    }
    setSuccessResponseServer(){
        this.setState({requesting:!1});
        this.props.onSuccess()
    }
    request(values){
        if (!this.state.requesting){
            const _this = this;
            this.setState({requesting:!0,error:''});
            const data = {
                ...this.props.account,
                ...values,                
                birthday:moment(values.birthday,'DD/MM/YYYY').format('YYYY-MM-DD'),
                peopleId_place_get:prefixProvince(values.peopleId_place_get,!1),
                peopleId_date_get:moment(values.peopleId_date_get,'DD/MM/YYYY').format('YYYY-MM-DD') 
            }
            registerAccount(data).subscribe((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 4 && response.error.type === 1 && !!response.error.data){
                            const errorsData = response.error.data;
                            if (errorsData.password || errorsData.username || errorsData.email){
                                _this.props.onStopSubmit(FORM_REGISTER_ACCOUNT,errorsData)
                                _this.backStage();
                                return !1
                            }
                            _this.setState({requesting:!1});
                            _this.props.onStopSubmit(FORM_REGISTER_INFORMATION,errorsData);                                                      
                        } else {
                            _this.setErrorResponseServer(response.error.message)
                        }                        
                    } else if (response.status === 200){
                        _this.setSuccessResponseServer()
                    } else {
                        _this.setErrorResponseServer('Đã có lỗi xảy ra, vui lòng thử lại sau!')
                    }                    
                } catch(err){
                    _this.setErrorResponseServer('Đã có lỗi xảy ra, vui lòng thử lại sau!')
                }                
            },() => _this.setErrorResponseServer('Mất kết nối tới máy chủ!'))
        }
    }    
    backStage = () => {
        this.props.goBack()
    }    
    render(){
        const {error,requesting} = this.state;
        return (
            <div>
                <Loading isLoading={requesting} />              
                <Title>Hoàn thiện thông tin <a className="back" onClick={this.backStage}>Back</a></Title>
                <LineErrorMessage type="error" message={error} />
                <RegisterInformationForm onRequest={this.request.bind(this)} />
                <BottomForm />
            </div>
        )
    }
}
export default connect((state) => ({
    account:getFormValues(FORM_REGISTER_ACCOUNT)(state),
}),(dispatch) => ({
    onStopSubmit:bindActionCreators(stopSubmit,dispatch),
    onClearError:(field) => bindActionCreators(clearAsyncError,dispatch)(FORM_REGISTER_INFORMATION,field)
}))(RegisterInformation);