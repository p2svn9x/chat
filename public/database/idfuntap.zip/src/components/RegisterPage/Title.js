import React from 'react';

const Title = ({children}) => (
    <h2 className="rs regis-title">
        {children}
    </h2>
)
export default Title;