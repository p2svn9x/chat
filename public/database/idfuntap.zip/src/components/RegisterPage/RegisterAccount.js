import React from 'react';
import {bindActionCreators} from 'redux';
import { connect } from 'react-redux';
import {Button} from 'muicss/react';
import {reduxForm,Field,stopSubmit,SubmissionError} from 'redux-form';
import {FORM_REGISTER_ACCOUNT} from '../../constants/formid';
import {InputField,InputPasswordField} from '../FormFields';
import Title from './Title';
import BottomForm from './BottomForm';
import Loading from '../Loading';
import {validateUsername,validateEmail} from '../../helpers/validate';
import {validateRegisterAccount} from '../../configs/api';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors = {};   
    if (!values.email){
        errors.email = 'Không được để trống!'
    } else if (!validateEmail(values.email)){
        errors.email = 'Email không hợp lệ!'
    } 
    if (!values.username){
        errors.username = 'Không được để trống!'
    } else if (!validateUsername(values.username)){
        errors.username = 'Tên đăng nhập không đúng định dạng!'
    } else if (values.username.length > 20){
        errors.username = 'Tên đăng nhập phải ít hơn 20 ký tự!'
    } else if (values.username.length < 5){
        errors.username = 'Tên đăng nhập phải nhiều hơn 5 ký tự!'
    }
    if (!values.password){
        errors.password = 'Không được để trống!'
    } else if (values.password.length < 6){
        errors.password = 'Mật khẩu phải nhiều hơn 6 ký tự!'
    } else if (values.password.length > 15){
        errors.password = 'Mật khẩu phải ít hơn 15 ký tự!'
    }
    return errors
}

const RegisterAccountForm = reduxForm({
    form:FORM_REGISTER_ACCOUNT,
    destroyOnUnmount:!1,    
    onSubmit:(values,dispatch,{onRequest}) => {
        const errors = validate(values);
        if (Object.keys(errors).length === 0){
            onRequest(values)
        } else {
            throw new SubmissionError(errors)
        }        
    }
})(({handleSubmit,change}) => (
    <form onSubmit={handleSubmit} className="regis-form">
        <Field 
            name="email" 
            label="Email" 
            component={InputField} 
            onClear={() => change('email','')}
        />
        <Field 
            name="username" 
            label="Tên đăng nhập" 
            component={InputField} 
            onClear={() => change('username','')}
        />
        <Field name="password" label="Mật khẩu" component={InputPasswordField} />
        <Button className="f-btn-orage f-btn-100 btn-h40">Đăng ký</Button>
    </form>
)) 

class RegisterAccount extends React.Component {
    state = {
        requesting:!1,
        error:''     
    }
    setErrorResponseServer(message){
        this.setState({requesting:!1,error:message})
    }
    setSuccessResponseServer(){
        this.setState({requesting:!1});
        this.props.onSuccess()
    }
    request(values){
        if (!this.state.requesting){
            const _this = this;
            this.setState({requesting:!0,error:''});
            validateRegisterAccount(values).subscribe((r) => {
                const response = r.response;
                try {
                    if (!!response.error){
                        if (response.error.code === 4 && response.error.type === 1 && !!response.error.data){
                            _this.setState({requesting:!1});
                            _this.props.onStopSubmit(response.error.data)                         
                        } else {
                            _this.setErrorResponseServer(response.error.message)
                        }                        
                    } else if (response.status === 200){
                        _this.setSuccessResponseServer()
                    } else {
                        _this.setErrorResponseServer('Đã có lỗi xảy ra, vui lòng thử lại sau!')
                    }                    
                } catch(err){
                    _this.setErrorResponseServer('Đã có lỗi xảy ra, vui lòng thử lại sau!')
                }                
            },() => _this.setErrorResponseServer('Mất kết nối tới máy chủ!'))
        }
    }   
    render(){
        const {error} = this.state;
        return (
            <div>
                <Loading isLoading={!!this.state.requesting} />                              
                <Title>Đăng ký</Title>
                <LineErrorMessage type="error" message={error} />  
                <RegisterAccountForm onRequest={this.request.bind(this)} />
                <BottomForm />
            </div>
        )
    }
}
export default connect(null,(dispatch) => ({
    onStopSubmit:(errors) => bindActionCreators(stopSubmit,dispatch)(FORM_REGISTER_ACCOUNT,errors)
}))(RegisterAccount);