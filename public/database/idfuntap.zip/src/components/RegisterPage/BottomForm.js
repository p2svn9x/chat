import React from 'react';
import {Link} from 'react-router-dom';
import {PATH_LOGIN} from '../../constants/pathname';

const BottomForm = () => {
    return (
        <div>
            <div className="line-clear line-clear1"></div>
            <h2 className="rs tit_3">Bạn đã có tài khoản</h2>
            <Link to={PATH_LOGIN} style={{marginLeft:'auto'}} className="mui-btn f-btn-100 btn-h40 btn-h40-dark">Đăng nhập ngay</Link>
        </div>
    )
}
export default BottomForm;