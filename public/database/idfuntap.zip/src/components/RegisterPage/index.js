import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {destroy} from 'redux-form';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import Steps from '../Steps';
import UpdateSuccess from '../UpdateSuccess';
import RegisterInfomation from './RegisterInfomation';
import RegisterAccount from './RegisterAccount';
import { FORM_REGISTER_ACCOUNT } from '../../constants/formid';
import { getUserInfo } from '../../actions/user';
import { syncDirection } from '../../actions/direction';

const uniqkey = Math.random().toString(36).substr(2, 6);

class RegisterPage extends React.Component {
    constructor(){
        super();
        this.step = 1;    
    }
    changestep(step){
        this.step = step;
        this.forceUpdate()
    }    
    componentWillMount(){
        this.props.onSyncDirection()
    }
    componentWillUnmount(){
        this.props.onDestroy()
    }
    render(){
        return (
            <div>               
                <div className="block-big">  
                    <div className="block-regis">
                        <TransitionGroup>
                            <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                                <Steps order={this.step}>
                                    <RegisterAccount step={1} onSuccess={() => this.changestep(2)} />
                                    <RegisterInfomation step={2} onSuccess={() => this.changestep(3)} goBack={() => this.changestep(1)} />
                                    <UpdateSuccess step={3} timer={5} onRemove={() => this.props.onGetUserInfo()} title="Bạn đã đăng ký thành công!" />
                                </Steps>
                            </CSSTransition>
                        </TransitionGroup>
                    </div>
                </div>
            </div>
        )
    }
}
export default connect(null,(dispatch) => ({
    onDestroy:() => bindActionCreators(destroy,dispatch)(FORM_REGISTER_ACCOUNT),
    onSyncDirection:bindActionCreators(syncDirection,dispatch),
    onGetUserInfo: bindActionCreators(getUserInfo,dispatch)
}))(RegisterPage);