import React from 'react';

const ErrorPage = ({title,description}) => (
    <div className="box-fullh">
        <div className="box-fullh-center">
            {title && (<div className="mui--text-display3 mui--text-center">{title}</div>)}
            {description && (<div className="mui--text-subhead mui--text-center">{description}</div>)}            
        </div>
    </div>
)

export default ErrorPage;