import React from 'react';
import { bindActionCreators,compose } from 'redux';
import {connect} from 'react-redux';
import {reduxForm,Field,SubmissionError} from 'redux-form';
import {Button} from 'muicss/react';
import {FORM_CONFIRM_PASSWORD} from '../../constants/formid';
import {InputPasswordField} from '../FormFields';
//import {request_verify_password} from '../../configs/api';
import Loading from '../Loading';
//import {logout_user} from '../../actions/user';
import {submitVerifyPassword} from '../../actions/submit';
import {setSessionPassword} from '../../actions/session';
import LineErrorMessage from '../LineErrorMessage';

const validate = values => {
    const errors = {};
    if (!values.password){
        errors.password = 'Chưa nhập mật khẩu!'
    } else if (values.password.length < 6 || values.password.length > 15){
        errors.password = 'Mật khẩu trong khoảng 6 - 15 ký tự'
    }
    return errors
}
const submit = (values,dispatch,{onSubmitForm,reset,onConfirmed,onSetSessionPassword,onSetErrorMessage}) => {
    const errors = validate(values);
    if (Object.keys(errors).length === 0){
        const request = () => new Promise((resolve,reject) => onSubmitForm(values,resolve,reject));
        return request()
            .then(() => {    
                onSetSessionPassword();         
                onConfirmed()          
            })
            .catch((error) => {
                if (error.code === 4){ 
                    reset()                  
                } 
                onSetErrorMessage(error.message)                
            })
    } else {
        throw new SubmissionError(errors)
    }    
}
const ConfirmPasswordForm = compose(
    connect(null,(dispatch) => ({             
        onSubmitForm:bindActionCreators(submitVerifyPassword,dispatch),
        onSetSessionPassword:() => bindActionCreators(setSessionPassword,dispatch)(Date.now())        
    })),
    reduxForm({
        form:FORM_CONFIRM_PASSWORD,       
        onSubmit: submit
    })
)(({handleSubmit,submitting}) => (
    <form onSubmit={handleSubmit}>
        <Loading isLoading={submitting} />
        <Field name="password" placeholder="Nhập mật khẩu" label="Mật khẩu" component={InputPasswordField} /> 
        <Button className="f-btn-orage f-btn-100">Tiếp tục</Button>
    </form>    
));

class ConfirmPassword extends React.Component {    
    state = {        
        error:''
    }
    setErrorMessage(message){
        this.setState({error:message})
    }  
    render(){    
        const {error} = this.state; 
        const {onConfirmed,show} = this.props;   
        if (show){
            return (
                <div className="box-canhan" style={{padding:0}}>  
                    <h3 className="rs tlt-dn">Xác thực mật khẩu tài khoản FunID</h3>
                    <p className="rs txt-dn">
                        Để tiếp tục, trước tiên hãy xác minh đó là bạn
                    </p>
                    <LineErrorMessage type="error" message={error} /> 
                    <ConfirmPasswordForm 
                        onConfirmed={onConfirmed} 
                        onSetErrorMessage={this.setErrorMessage.bind(this)} 
                    />                  
                </div>
            )
        }
        return null
    }
}
export default ConfirmPassword;

ConfirmPassword.defaultProps = {
    onConfirmed:() => {}
}