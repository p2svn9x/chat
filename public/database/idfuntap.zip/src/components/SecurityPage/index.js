import React from 'react';
import {connect} from 'react-redux';
import Description from '../Description';
import { isTestMode } from '../../helpers/utils';
import { 
    ButtonEmail, 
    ButtonPhone, 
    ButtonPassword, 
    ButtonTwoStep 
} from '../ButtonUpdateInfo';
import {getUserInfo} from '../../helpers/filters';

const SecurityPage = ({email,email_verified,phone,phone_verified,password,modified_password,two_step}) => {
    const inTest = isTestMode();
    return (
        <div className="box-main">
            <Description
                icon="ico-desc-bm"
                title="Hoàn thiện thông tin bảo mật"
                desc="Cài đặt thông tin đăng nhập, mật khẩu và bảo mật tài khoản"
            />
            <div className="box-info">                
                <ul className="rs lstTask">
                    <li>
                        <ButtonEmail email={email} email_verified={email_verified} />                                                  
                    </li>
                    <li>
                        <ButtonPhone phone={phone} phone_verified={phone_verified} />                            
                    </li>
                    <li>
                        <ButtonPassword password={password} modified={modified_password} />                          
                    </li>
                    {inTest && (
                        <li>
                            <ButtonTwoStep two_step={two_step} unaccess={!password || (!email_verified && !phone_verified)} />                               
                        </li>
                    )}
                </ul>               
            </div>               
        </div>
    )
    
} 
export default connect((state) => {
    const security = getUserInfo(state,'Security')('email','email_verified','phone','phone_verified','password','modified_password','two_step');
    return {
        email:security.email,
        email_verified:!!security.email && security.email_verified,
        phone:security.phone,
        phone_verified:security.phone_verified,
        password:security.password,
        modified_password:security.modified_password,
        two_step:security.two_step
    }
},null)(SecurityPage);
