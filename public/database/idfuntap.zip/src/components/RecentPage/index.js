import React from 'react';
import {Link} from 'react-router-dom';
import Description from '../Description';
import {PATH_RECENT_DEVICES,PATH_RECENT_GAMES} from '../../constants/pathname';

const RecentPage = () => {
    return (
        <div className="box-main">
            <Description
                icon="ico-desc-lg"
                title="Lịch sử đăng nhập"
                desc="Kiểm tra lịch sử đăng nhập tài khoản FunID của bạn"
            />
            <div className="box-info">                
                <ul className="rs lstTask">
                    <li>
                        <Link to={PATH_RECENT_DEVICES} className="ripple ripple1 txt-dual txt-dual--no-noti">
                            Thiết bị đã dùng gần đây
                            <span>Kiểm tra IP và thời gian các thiết bị đã truy cập vào tài khoản</span>
                        </Link>
                    </li> 
                    <li>
                        <Link to={PATH_RECENT_GAMES} className="ripple ripple1 txt-dual txt-dual--no-noti">
                            Game đã chơi gần đây
                            <span>Xem lại các game mà bạn đã chơi gần đây nhất</span>
                        </Link>
                    </li>                      
                </ul>               
            </div>
        </div>
    )
}

export default RecentPage;
