import React from 'react';

const Link = ({href,label}) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="f-txtlink">{label}</a>
)

const Footer = () => {  
    return (
        <footer id="footer">
            <p className=" mui--text-left">
                <Link href="https://corp.funtap.vn" label="Funtap" />
                <Link href="https://hotro.funtap.vn/bao-loi" label="Báo Lỗi" />
                <Link href="https://funtap.vn/dieu-khoan" label="Điều Khoản" />
                <Link href="https://corp.funtap.vn/contact" label="Liên Hệ" />            
            </p>
        </footer>
    )
} 
export default Footer;