import React from 'react';
import Button from 'muicss/lib/react/button';
import Row from 'muicss/lib/react/row';
import Col from 'muicss/lib/react/col';

class ModalConfirmation extends React.Component {
    componentWillMount(){
        document.body.style.overflow = 'hidden'
    }
    componentWillUnmount(){
        document.body.style.overflow = ''
    }    
    render(){
        const {message,onCancel,onConfirm} = this.props;
        return (
            <div className="box-modal">
                <div className="modal-inner cnt" style={{width:'320px'}}>
                    <h3 className="rs">  
                        Chú ý
                        <a className="ico-hide" onClick={() => onCancel()} />
                    </h3>
                    <div className="box-thanhcong" style={{padding:'15px 9px'}}> 
                        {message}
                        <Row className="mui-group-btn">
                            <Col xs="6">
                                <Button className="f-btn-gray" onClick={() => onCancel()}>Hủy</Button>
                            </Col>
                            <Col xs="6">
                                <Button className="f-btn-red" onClick={() => onConfirm()}>OK</Button>
                            </Col>
                        </Row>
                        
                        
                    </div>
                </div>
            </div>
        )
    }
}
export default ModalConfirmation;