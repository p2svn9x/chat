import React from 'react';
import {Redirect} from 'react-router-dom';
import { connect } from 'react-redux';
import TwoStepSetting from '../2StepSetting';
import { PATH_DASHBOARD } from '../../constants/pathname';
import NotFound from '../NotFound';
import { getUserInfo } from '../../helpers/filters';
import { isTestMode } from '../../helpers/utils';

const TwoStepSettingPage = ({status,password,emailVerified,phoneVerified}) => {    
    const inTest = isTestMode();
    if (!inTest){
        return (
            <NotFound />
        )
    }
    if (!password || (!emailVerified && !phoneVerified)){
        return (
            <Redirect to={PATH_DASHBOARD} />
        )
    }      
    return (
        <div className="box-main">
            <div className="box-canhan">
                <TwoStepSetting status={status} />
            </div>
        </div>
    )
}

export default connect((state) => {
    let userInfo = getUserInfo(state,'Security')('two_step','password','email','email_verified','phone_verified');   
    return {       
        status:userInfo.two_step,
        password:userInfo.password,
        emailVerified:!!userInfo.email && userInfo.email_verified,
        phoneVerified:userInfo.phone_verified
    }
},null)(TwoStepSettingPage);