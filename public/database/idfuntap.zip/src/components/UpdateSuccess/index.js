import React from 'react';
import {withRouter} from 'react-router';
import {Link,Redirect} from 'react-router-dom';
import {PATH_DASHBOARD} from '../../constants/pathname';

class UpdateSuccess extends React.Component {    
    componentWillMount(){
        this.initCountdown(this.props.timer || 5);
    }
    componentWillUnmount(){        
        if (this.timer) clearInterval(this.timer);
        this.props.onRemove();
    }       
    initCountdown(initTimer){   
        this.setState({timer:initTimer});    
        this.timer = setInterval(() => {
            let currentTimer;
            let prevTimer = this.state.timer;            
            currentTimer = prevTimer - 1;                      
            if (currentTimer <= 0){                
                this.setState({timer:0});                                
            } else {                           
                this.setState({timer:currentTimer})
            }
        },1000)
    }       
    render(){  
        const {timer} = this.state;   
        if (timer <= 0){  
            return <Redirect to={PATH_DASHBOARD} />
        }  
        return (
            <div className="box-canhan">
                <i className="ico-tbdone"></i>
                <p className="rs txt-done">{this.props.title}</p>
                <p className="rs txt-gray">Hệ thống sẽ tự động chuyển về trang chủ trong {timer}s</p>
                <Link className="mui-btn mui-btn-m10 f-btn-gray f-btn-100" to={PATH_DASHBOARD}>Về trang chủ </Link>
            </div>
        )
    }
}

export default withRouter(UpdateSuccess);

UpdateSuccess.defaultProps = {
    onRemove: () => {}    
}