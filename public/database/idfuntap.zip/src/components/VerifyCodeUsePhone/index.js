import React from 'react';
import {bindActionCreators} from 'redux';
//import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import VerifyCode from '../VerifyCode';
import {    
    verify_code_phone,
    request_code_phone,
    resend_code_phone
} from '../../configs/api';
//import ConfirmPassword from '../ConfirmPassword';
import {setSessionOTP} from '../../actions/session';
import {createdCodeOldPhone,removeCodeOldPhone} from '../../actions/temporary';
import {getUserInfo} from '../../helpers/filters';
import { calcResendTimer, maskPhone } from '../../helpers/utils';


const VerifyCodeUsePhone = ({
    phone,
    type,    
    createdCodeOldPhone,
    onSetSessionOTP,
    onCreatedCodeOldPhone,
    onRemoveCodeOldPhone,
    onVerified
}) => (
    <VerifyCode                            
        title="Xác thực tài khoản của bạn"
        description={
            `Hệ thống sẽ gửi mã xác thực tới số điện thoại <span>${maskPhone(phone)}</span>. 
            Nếu chưa nhận được vui lòng chờ trong giây lát.`
        }
        buttonText="Xác thực"                            
        submitAPI={(values) => request_code_phone(values,type)}
        resendAPI={resend_code_phone}
        createAPI={() => verify_code_phone(type)}
        onCodeCreated={() => onCreatedCodeOldPhone()}      
        initTimer={calcResendTimer(createdCodeOldPhone)}
        onVerified={() => {onSetSessionOTP();onRemoveCodeOldPhone();onVerified()}}  
    />
)

export default connect((state) => ({
    phone:getUserInfo(state,'Security')('phone'),
    createdCodeOldPhone:state.temporary.createdCodeOldPhone
}),(dispatch) => ({    
    onSetSessionOTP:() => bindActionCreators(setSessionOTP,dispatch)(Date.now()),
    onCreatedCodeOldPhone:() => bindActionCreators(createdCodeOldPhone,dispatch)(Date.now()),
    onRemoveCodeOldPhone:bindActionCreators(removeCodeOldPhone,dispatch)
}))(VerifyCodeUsePhone);

VerifyCodeUsePhone.defaultProps = {
    onVerified:() => {},   
    type:null
}


