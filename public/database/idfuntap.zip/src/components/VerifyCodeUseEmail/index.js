import React from 'react';
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import VerifyCode from '../VerifyCode';
import {    
    verify_code_email,
    verify_old_email,
    resendcode_set_new_email
} from '../../configs/api';
import {setSessionOTP} from '../../actions/session';
import {createdCodeOldEmail,removeCodeOldEmail} from '../../actions/temporary';
import { getUserInfo } from '../../helpers/filters';
import { calcResendTimer, maskEmail } from '../../helpers/utils';

const VerifyCodeUseEmail = ({
    email,
    type,    
    createdCodeOldEmail,
    onSetSessionOTP,
    onCreatedCodeOldEmail,
    onRemoveCodeOldEmail,
    onVerified
}) => (
    <VerifyCode                            
        title="Xác thực tài khoản của bạn"
        description={
            `Hệ thống sẽ gửi mã xác thực tới email <span>${maskEmail(email)}</span>. 
            Nếu chưa nhận được vui lòng chờ trong giây lát hoặc kiểm tra thư mục Spam`
        }
        buttonText="Xác thực"                            
        submitAPI={(values) => verify_old_email(values,type)}
        resendAPI={resendcode_set_new_email}
        createAPI={() => verify_code_email(type)}
        onCodeCreated={() => onCreatedCodeOldEmail()}      
        initTimer={calcResendTimer(createdCodeOldEmail)}
        onVerified={() => {onSetSessionOTP();onRemoveCodeOldEmail();onVerified()}} 
    />
)

export default connect((state) => ({
    email:getUserInfo(state,'Security')('email'),
    createdCodeOldEmail:state.temporary.createdCodeOldEmail
}),(dispatch) => ({    
    onSetSessionOTP:() => bindActionCreators(setSessionOTP,dispatch)(Date.now()),
    onCreatedCodeOldEmail:() => bindActionCreators(createdCodeOldEmail,dispatch)(Date.now()),
    onRemoveCodeOldEmail:bindActionCreators(removeCodeOldEmail,dispatch) 
}))(VerifyCodeUseEmail);

VerifyCodeUseEmail.defaultProps = {
    onVerified:() => {},    
    type:null
    
}