import React from 'react';
import LoadingSpinner from '../LoadingSpinner';

const Loading = ({isLoading}) => {
    if (isLoading){
        return (
            <div className="f-loading"> 
                <LoadingSpinner />
            </div>
        )
    }
    return null
}
export default Loading;