import React from 'react';
import {connect} from 'react-redux';
import SetPhonePage from '../SetPhonePage';
import ChangePhonePage from '../ChangePhonePage';
import {getUserInfo} from '../../helpers/filters';

const UpdatePhonePage = ({isPhoneVerified}) => {    
    if (isPhoneVerified){
        return (
            <div className="box-main">
                <div className="box-canhan">
                    <ChangePhonePage />
                </div>
            </div>
        )
    } else {
        return (
            <div className="box-main">
                <div className="box-canhan">
                    <SetPhonePage />
                </div>
            </div>
        )
    }
}

export default connect((state) => ({    
    isPhoneVerified:getUserInfo(state,'Security')('phone_verified')    
}),null)(UpdatePhonePage);