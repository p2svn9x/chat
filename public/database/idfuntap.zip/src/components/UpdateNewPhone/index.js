import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators, compose } from 'redux';
import {reduxForm,Field,SubmissionError} from 'redux-form';
import {InputField} from '../FormFields';
import Loading from '../Loading';
import {Button} from 'muicss/react';
import {FORM_UPDATE_PHONE} from '../../constants/formid';
import {update_new_phone} from '../../configs/api';
import {validatePhoneNumber, errorFromPhoneNumber} from '../../helpers/validate';
import {change_user_security} from '../../actions/user';
import {requestChangeSecurity} from '../../actions/request';
import { submitUpdateSecurity } from '../../actions/submit';
import {createdCodeNewPhone} from '../../actions/temporary';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors = {};
    if (!values.phone){
        errors.phone = 'Bạn chưa nhập số điện thoại!'
    } else if (!validatePhoneNumber(values.phone)){
        errors.phone = 'Số điện thoại không đúng định dạng!'
    }
    return errors
}

const UpdateNewPhoneForm = compose(
    connect(null,(dispatch) => ({        
        onRequestChangeSecurity: bindActionCreators(requestChangeSecurity,dispatch),
        onSubmitUpdatePhone:(values,resolve,reject) => bindActionCreators(submitUpdateSecurity,dispatch)(() => update_new_phone(values,'update_phone'),resolve,reject),
        changeSecurity: bindActionCreators(change_user_security,dispatch),   
        onCreatedCodeNewPhone:(phone) => bindActionCreators(createdCodeNewPhone,dispatch)(Date.now(),phone)
    })),
    reduxForm({
        form: FORM_UPDATE_PHONE,        
        onSubmit: (values,dispatch,{
            onRequestChangeSecurity,
            onNext,
            onReverify,            
            onSetErrorServer,
            onSubmitUpdatePhone,            
            changeSecurity,
            onCreatedCodeNewPhone
        }) => {
            const errors = validate(values);
            if (Object.keys(errors).length === 0){
                const requestChange = () => new Promise((resolve) => onRequestChangeSecurity(resolve));
                let err = errorFromPhoneNumber(values.phone);
                if (err){
                    onSetErrorServer(err);
                    return !1
                }
                onSetErrorServer('');
                return requestChange().then((response) => {
                    if (!!response.error){
                        onReverify()
                    } else {
                        const submitChange = () => new Promise((resolve,reject) => onSubmitUpdatePhone(values,resolve,reject));
                        return submitChange()
                        .then(() => {
                            onCreatedCodeNewPhone(values.phone);
                            changeSecurity({new_phone:values.phone});
                            onNext()
                        })
                        .catch((error) => {
                            if (error.code === 4){                            
                                throw new SubmissionError({phone:error.message})                            
                            } else if (error.code === 2){
                                onReverify()
                            } else {                            
                                onSetErrorServer(error.message)
                            }
                        })
                    }
                }) 
            } else {
                throw new SubmissionError(errors)
            }               
        }
    })
)(({handleSubmit,submitting,change}) => (
    <form onSubmit={handleSubmit}>                
        <Loading isLoading={submitting} />        
        <Field 
            name="phone" 
            type="tel"
            numberOnly={!0}
            label="Số điện thoại của bạn" 
            component={InputField} 
            onSetValue={(value) => change('phone',value)}
            onClear={() => change('phone','')}          
        />
        <Button className="f-btn-orage f-btn-100">Tiếp tục</Button>
    </form>
));

class UpdateNewPhone extends React.Component {     
    state = {    
        error:''
    }
    setErrorServer = (error) => {
        this.setState({error})
    }   
    render(){
        const {error} = this.state;
        const {onNext,onReverify} = this.props;
        return (
            <div>                
                <h3 className="rs tlt-dn">Thiết lập SĐT của bạn</h3>
                <p className="rs txt-dn">
                    Số điện thoại khôi phục của bạn được sử dụng để liên lạc với bạn trong trường hợp chúng 
                    tôi phát hiện thấy hoạt động bất thường trong tài khoản của bạn hoặc bạn vô tình bị chặn.
                </p>  
                <LineErrorMessage type="error" message={error} />                 
                <UpdateNewPhoneForm 
                    onSetErrorServer={this.setErrorServer.bind(this)}  
                    onNext={onNext}
                    onReverify={onReverify}                   
                />   
            </div>
        )
    }
}

export default UpdateNewPhone;


