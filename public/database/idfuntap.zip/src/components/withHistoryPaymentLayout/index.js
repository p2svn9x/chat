import React from 'react';
import {bindActionCreators} from 'redux';
import { connect } from 'react-redux';
import NotFound from '../NotFound';
import {initHistoryPayment,syncHistoryPayment} from '../../actions/history';
/** 
    @option: type,api
 */

export default function withHistoryPaymentLayout(options){    
    if (!options.type || !options.api){
        return <NotFound />
    }
    return function Composed(Component){
        class ComposedComponent extends React.Component {
            constructor(){
                super();
                this.scrollHandle = this.scrollHandle.bind(this)
            }
            componentWillMount(){
                this.props.onInitHistoryPayment();
                this.props.onSyncHistoryPayment()
            }
            componentDidMount(){
                window.addEventListener('scroll', this.scrollHandle);
            }
            componentWillUnmount(){        
                window.removeEventListener('scroll', this.scrollHandle);
            }
            scrollHandle(){ 
                if (
                    (window.innerHeight + window.scrollY) >= (document.body.offsetHeight - 200) && 
                    this.props.data.length > 0
                ){ 
                    this.syncHistoryHandle()
                }        
            }    
            syncHistoryHandle(){
                const {sync,onSyncHistoryPayment} = this.props;
                if (!sync){
                    onSyncHistoryPayment()
                }
            }
            render(){
                const dataProps = {
                    sync:this.props.sync,
                    error:this.props.error,
                    data:this.props.data
                }                
                return (
                    <div className="box-main">
                        <Component {...dataProps} />
                    </div>
                )
            }            
        }
        return connect((state) => {
            let payment = state.history[options.type] || {};
            return {
                sync:payment.sync || !1,
                error:payment.error || {},
                data:payment.data || [],
                lastedTimeUpdate:payment.lastedTimeUpdate || null
            }
        },(dispatch) => ({
            onInitHistoryPayment:() => bindActionCreators(initHistoryPayment,dispatch)(options.type),
            onSyncHistoryPayment:() => bindActionCreators(syncHistoryPayment,dispatch)(options.type,options.api)            
        }))(ComposedComponent);
    }    
}