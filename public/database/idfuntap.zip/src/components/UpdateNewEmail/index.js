import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators, compose } from 'redux';
import {reduxForm,Field,SubmissionError} from 'redux-form';
import {InputField} from '../FormFields';
import Loading from '../Loading';
import {Button} from 'muicss/react';
import {FORM_UPDATE_EMAIL} from '../../constants/formid';
import {update_new_email} from '../../configs/api';
import {validateEmail} from '../../helpers/validate';
import {change_user_security} from '../../actions/user';
import {requestChangeSecurity} from '../../actions/request';
import { submitUpdateSecurity } from '../../actions/submit';
import {createdCodeNewEmail} from '../../actions/temporary';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors = {};
    if (!values.email){
        errors.email = 'Bạn chưa nhập email!'
    } else if (!validateEmail(values.email)){
        errors.email = 'Email không đúng định dạng!'
    }
    return errors
}

const UpdateNewEmailForm = compose(
    connect(null,(dispatch) => ({        
        onRequestChangeSecurity: bindActionCreators(requestChangeSecurity,dispatch),
        onSubmitUpdateEmail:(values,resolve,reject) => bindActionCreators(submitUpdateSecurity,dispatch)(() => update_new_email(values,'update_email'),resolve,reject),
        changeSecurity: bindActionCreators(change_user_security,dispatch),   
        onCreatedCodeNewEmail:(email) => bindActionCreators(createdCodeNewEmail,dispatch)(Date.now(),email)
    }),null),
    reduxForm({
        form: FORM_UPDATE_EMAIL,   
        onSubmit: (values,dispatch,{
            onRequestChangeSecurity,
            onNext,
            onReverify,            
            onSetErrorServer,
            onSubmitUpdateEmail,            
            changeSecurity,
            onCreatedCodeNewEmail
        }) => {
            const errors = validate(values);
            if (Object.keys(errors).length === 0){
                const requestChange = () => new Promise((resolve) => onRequestChangeSecurity(resolve));
                onSetErrorServer('');            
                return requestChange().then((response) => {
                    if (!!response.error){
                        onReverify()
                    } else {
                        const submitChange = () => new Promise((resolve,reject) => onSubmitUpdateEmail(values,resolve,reject));
                        return submitChange()
                        .then(() => {
                            onCreatedCodeNewEmail(values.email);
                            changeSecurity({new_email:values.email});
                            onNext()
                        }).catch((error) => {
                            if (error.code === 4){                            
                                throw new SubmissionError({email:error.message})                            
                            } else if (error.code === 2){
                                onReverify()
                            } else {                           
                                onSetErrorServer(error.message)
                            }
                        })
                    }
                })
            } else {
                throw new SubmissionError(errors)
            }
                
        }
    })
)(({handleSubmit,submitting,change}) => (
    <form onSubmit={handleSubmit}>
        <Loading isLoading={submitting} />        
        <Field 
            name="email" 
            label="Địa chỉ email của bạn" 
            component={InputField} 
            onClear={() => change('email','')}          
        />
        <Button className="f-btn-orage f-btn-100">Tiếp tục</Button>
    </form>
));

class UpdateNewEmail extends React.Component {     
    state = {       
        error:''
    }
    setErrorServer = (error) => {        
        this.setState({error})
    }       
    render(){
        const {error} = this.state;       
        const {onNext,onReverify} = this.props;
        return (
            <div>
                
                <h3 className="rs tlt-dn">Thiết lập email của bạn</h3>
                <p className="rs txt-dn">
                    Email khôi phục của bạn được sử dụng để liên lạc với bạn trong trường hợp chúng 
                    tôi phát hiện thấy hoạt động bất thường trong tài khoản của bạn hoặc bạn vô tình bị chặn.
                </p>         
                <LineErrorMessage type="error" message={error} />   
                <UpdateNewEmailForm                    
                    onSetErrorServer={this.setErrorServer.bind(this)}  
                    onNext={onNext}
                    onReverify={onReverify}                                   
                />   
            </div>
        )
    }
}

export default UpdateNewEmail;


