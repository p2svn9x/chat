import React from 'react';
import moment from 'moment';
import {formatMoney} from '../../helpers/utils';
import withHistoryPaymentLayout from '../withHistoryPaymentLayout';
import {sync_history_topup} from '../../configs/api';

const HistoryTopupPage = ({sync,error,data}) => {
    if (data.length === 0){
        if (sync){
            return <Loading isLoading={!0} />
        } else if (!error.message){
            return <LineError message={error.message} />
        } else {
            return <LineError message="Bạn chưa nạp lần nào" />
        }
    } 
    {data.map((h,i) => {
        let type = '';
        switch(h.type){
            case 'applestore':
            type = 'Apple Store';
            break;
            case 'thecaonl':
            type = 'Ngân Lượng';
            break;
            case 'thecaoshs':
            type = 'Thẻ cào SHS04';
            break;
            case 'thecaoepay':
            type = 'Thẻ cào Epay';
            break;
            case 'thecaoappota':
            type = 'Thẻ cào Appota';
            break;
            case 'thecaoshsol':
            type = 'Thẻ cào SHS05';
            break;
            case 'thecaopaydirect':
            type = 'Thẻ cào Paydirect';
            break;
            case 'paydirect':
            type = 'Paydirect';
            break;
            case 'molintpay':
            type = 'MOLPoints Card';
            break;
            case 'paypal':
            type = 'MOLPoints Card';
            break;
            case 'google':
            type = 'Google';
            break;
            case 'unipay':
            type = 'Unipay';
            break;
            case 'appota':
            type = 'Appota';
            break;
            case 'thecaonlol':
            type = 'Thẻ cào Telco';
            break;
            case 'funcoin':
            type = 'Funcoin';
            break;
            case 'thecaoved':
            type = 'Thẻ Ved';
            break;
            case 'naptructiep':
            type = 'Nạp Trực Tiếp';
            break;
            case 'bugiaodich':
            type = 'Bù Giao Dịch';
            break;
            case 'banknet':
            type = 'Banknet';
            break;
            case 'mycard':
            type = 'My Card';
            break;
            case 'molthaipay':
            type = 'Molthai Pay';
            break;
            case 'molintpaypte':
            type = 'Molintpaypte';
            break;
            case 'unipaypte':
            type = 'Unipaypte';
            break;
            case 'wallet_funtap':
            type = 'Ví Funtap';
            break;
            case 'wallet_appota':
            type = 'Ví Appota';
            break;
            case 'wallet_momo':
            type = 'Ví Momo';
            break;
            case 'thecaofuntap':
            type = 'Thẻ cào Funcard';
            break;
            case 'thecaovtc':
            type = 'Thẻ cào Vcoin';
            break;
            case 'thecaofpt':
            type = 'Thẻ cào Gate';
            break;
        }                  
        return (
            <div key={i} className={`taskUser ${i === 0 ? 'first' : ''}`}>
                <div className="taskUserInner">
                    <div className="taskIcon taskIcon50 dollarIcon taskInnerLeft"></div>
                    <h3 className="rs taskName">+ {formatMoney(h.price || 0)} VND</h3>
                    <p className="rs taskText">Loại nạp: {type}</p>
                    <p className="rs taskText">Game: {h.game}</p>
                    <p className="rs taskText">Thời gian: {moment(Number(h.time)*1000).format('DD/MM/YYYY - hh:mm')}</p>
                </div>                            
            </div>
        )
    })}
}

export default withHistoryPaymentLayout({
    type:'topup',
    api:sync_history_topup
})(HistoryTopupPage);
