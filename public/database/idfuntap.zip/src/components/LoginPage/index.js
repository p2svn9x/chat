import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import { getUserInfo } from '../../actions/user';
import { PATH_LOGIN} from '../../constants/pathname';
import LoginStepOne from './LoginStepOne';
import LoginStepTwo from './LoginStepTwo';
import Steps from '../Steps';
import { 
    resetDataTemporary,
    createdCodeOldEmail,
    createdCodeOldPhone,
    mergeUserTemporary 
} from '../../actions/temporary';
import { getFuntapConfig } from '../../helpers/utils';
import {getTmpFromStorage} from '../../helpers/filters';

const uniqkey = Math.random().toString(36).substr(2, 6);

class LoginPage extends React.Component {
    constructor(){
        super();
        this.data = null;
        this.step = 1;
        this.onGetUser = this.onGetUser.bind(this);
    }   
    componentWillMount(){
        const tmp = getTmpFromStorage();
        const {onCreatedCodeOldEmail,onCreatedCodeOldPhone,onMergeUserTemporary} = this.props;        
        if (!!tmp.userId && tmp.userType === 'authen'){
            let data = {};
            let isChanged = !1;
            if (!!tmp.oldPhone && !!tmp.createdCodeOldPhone){                                         
                data = {                        
                    userId:tmp.userId,
                    phone:tmp.oldPhone,                        
                }
                isChanged = !0; 
                onMergeUserTemporary(tmp);                
                onCreatedCodeOldPhone(tmp.createdCodeOldPhone)               
            } 
            if (!!tmp.oldEmail && !!tmp.createdCodeOldEmail){                                             
                data = {
                    ...data,
                    userId:tmp.userId,
                    email:tmp.oldEmail                    
                }
                if (!isChanged){onMergeUserTemporary(tmp)} // check xem o tren merge chua
                isChanged = !0; 
                onCreatedCodeOldEmail(tmp.createdCodeOldEmail)               
            }
            if (isChanged){                
                this.data = data;
                this.changestep(2)
            }
        }
    }  
    changestep(step){
        this.step = step;
        this.forceUpdate()
    }     
    onGetUser(){
        let paramsUrl = getFuntapConfig('paramsUrl');       
        this.props.onResetDataTemporary();
        if (!!paramsUrl){
            window.location.href = `${window.location.protocol}//${window.location.hostname + PATH_LOGIN + paramsUrl}`
        } else {            
            this.props.onGetUserInfo()
        }
    }  
    render(){        
        return (
            <TransitionGroup>
                <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                    <Steps order={this.step}>
                        <LoginStepOne 
                            step={1} 
                            onChangeStep={(data) => {
                                this.data=data;
                                this.changestep(2)
                            }} 
                            onGetUser={() => this.onGetUser()}
                        />
                        <LoginStepTwo 
                            step={2} 
                            verifyData={this.data}
                            onBack={() => this.changestep(1)} 
                            onGetUser={() => this.onGetUser()}
                        />
                    </Steps>
                </CSSTransition>
            </TransitionGroup>
        )
        
    }
}
export default connect(null,(dispatch) => ({   
    onGetUserInfo:bindActionCreators(getUserInfo,dispatch),
    onResetDataTemporary:bindActionCreators(resetDataTemporary,dispatch),
    onMergeUserTemporary:bindActionCreators(mergeUserTemporary,dispatch),
    onCreatedCodeOldEmail:bindActionCreators(createdCodeOldEmail,dispatch),
    onCreatedCodeOldPhone:bindActionCreators(createdCodeOldPhone,dispatch)     
}))(LoginPage);