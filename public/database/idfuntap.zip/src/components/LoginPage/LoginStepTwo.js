import React from 'react';
import {bindActionCreators} from 'redux';
import { connect } from 'react-redux';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import {Appbar,Container} from 'muicss/react';
import VerifyCode from '../VerifyCode';
import Steps from '../Steps';
import {request_code_phone,verify_code_phone,verify_old_email,verify_code_email} from '../../configs/api';
import {resetDataTemporary,createdCodeOldEmail,createdCodeOldPhone, mergeUserTemporary} from '../../actions/temporary';
import { calcResendTimer } from '../../helpers/utils';

const uniqkey = Math.random().toString(36).substr(2, 6);

const SwitchButton = ({show,type,onClick}) => {
    if (!show){
        return null
    }
    return (
        <div>
            <div className="line-clear" style={{marginTop:'20px'}}></div>
            <h2 className="rs tit_3">Xác thực bằng cách khác</h2>
            <a onClick={onClick} className="xacthuc">
                <i className={type ===' email' ? 'ico-sm-email' : 'ico-sm-mobile'}></i>
                {type === 'email' ? 'Email' : 'Số điện thoại'}
            </a>
        </div>
    )
}

const VerifyUsePhone = connect((state) => ({
    bid:state.browser.browserId,
    createdCodeOldPhone:state.temporary.createdCodeOldPhone
}),(dispatch) => ({
    onCreatedCodeOldPhone:() => bindActionCreators(createdCodeOldPhone,dispatch)(Date.now())  
}))(({
    bid,
    phone,
    userId,
    onGetUser,
    isChangeMethod,
    onChangeMethod,
    onResetDataTemporary,
    onMergeUserTemporary,
    createdCodeOldPhone,
    onCreatedCodeOldPhone
}) => (
    <div>
        <VerifyCode                           
            title="Xác thực tài khoản của bạn"
            description={`
                Hệ thống đã gửi mã xác thực tới số điện thoại <span>${phone}</span>. 
                Nếu chưa nhận được vui lòng chờ trong giây lát.`
            }
            buttonText="Xác thực"                            
            submitAPI={(values) => request_code_phone(values,'authen',userId,bid)}                    
            createAPI={() => verify_code_phone('authen',userId)}
            onCodeCreated={() => {onMergeUserTemporary({oldPhone:phone,userId,userType:'authen'});onCreatedCodeOldPhone()}}
            initTimer={calcResendTimer(createdCodeOldPhone)}
            onVerified={() => {onResetDataTemporary();onGetUser()}}                 
        />       
        <SwitchButton show={isChangeMethod} type="email" onClick={() => onChangeMethod()} />        
    </div>
))   

const VerifyUseEmail = connect((state) => ({
    bid:state.browser.browserId,
    createdCodeOldEmail:state.temporary.createdCodeOldEmail
}),(dispatch) => ({
    onCreatedCodeOldEmail:() => bindActionCreators(createdCodeOldEmail,dispatch)(Date.now())    
}))(({
    bid,
    email,
    userId,
    onGetUser,
    isChangeMethod,
    onChangeMethod,
    createdCodeOldEmail,
    onCreatedCodeOldEmail,
    onResetDataTemporary,
    onMergeUserTemporary
}) => (
    <div>
        <VerifyCode                           
            title="Xác thực tài khoản của bạn"
            description={`
                Hệ thống sẽ gửi mã xác thực tới email <span>${email}</span>. 
                Nếu chưa nhận được vui lòng chờ trong giây lát hoặc kiểm tra thư mục Spam`
            }
            buttonText="Xác thực"                            
            submitAPI={(values) => verify_old_email(values,'authen',userId,bid)}                    
            createAPI={() => verify_code_email('authen',userId)}
            onCodeCreated={() => {onMergeUserTemporary({oldEmail:email,userId,userType:'authen'});onCreatedCodeOldEmail()}}
            initTimer={calcResendTimer(createdCodeOldEmail)}
            onVerified={() => {onResetDataTemporary();onGetUser()}}                 
        />
        <SwitchButton show={isChangeMethod} type="phone" onClick={() => onChangeMethod()} />
    </div>
))

class VerifyStepTwoInner extends React.Component {
    constructor(props){
        super(props);
        this.step = 1;
        this.verifyData = props.verifyData || {};
    }
    componentWillMount(){
        const {phone} = this.verifyData;
        if (!!phone){
            this.step = 1
        } else {
            this.step = 2
        }  
    }    
    changestep = (step) => {
        this.step = step;
        this.forceUpdate()
    }
    render(){
        const {
            onGetUser,
            onResetDataTemporary,
            onMergeUserTemporary
        } = this.props;
        const {verifyData} = this;       
        return (
            <div>
                <style dangerouslySetInnerHTML={{__html:`.header-first{display:none}`}} />
                <TransitionGroup>
                    <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                        <Steps order={this.step}>
                            <VerifyUsePhone 
                                step={1}                                
                                phone={verifyData.phone}                         
                                userId={verifyData.userId} 
                                onGetUser={onGetUser} 
                                onResetDataTemporary={onResetDataTemporary}
                                onMergeUserTemporary={onMergeUserTemporary}
                                isChangeMethod={!!verifyData.email}
                                onChangeMethod={() => this.changestep(2)}                        
                            />
                            <VerifyUseEmail 
                                step={2}                                
                                email={verifyData.email} 
                                userId={verifyData.userId} 
                                onGetUser={onGetUser}                                 
                                onResetDataTemporary={onResetDataTemporary}
                                onMergeUserTemporary={onMergeUserTemporary}
                                isChangeMethod={!!verifyData.phone}
                                onChangeMethod={() => this.changestep(1)}                                         
                            />
                        </Steps>
                    </CSSTransition>
                </TransitionGroup>
            </div>
        )
    }
}

const LoginStepTwo = ({
    onBack,
    onResetDataTemporary,
    onGetUser,
    onMergeUserTemporary,
    verifyData
}) => {
    if (!verifyData || !verifyData.userId){
        return null
    } 
    return (
        <div>                    
            <header id="header" className="header-shadow">
                <Appbar className="mui--appbar-line-height">
                    <Container fluid={!0}>
                    <a onClick={() => { 
                        onResetDataTemporary();
                        onBack()         
                    }} className="sidedrawer-toggle f-ico-back f-ico-arr-back spr click-animation" />
                        <div className="mui--text-title f-txtheader">
                            Xác minh 2 bước
                        </div>
                    </Container>
                </Appbar>                        
            </header>
            <div className="mui--appbar-height"></div>
            <div className="box-main">                    
                <div className="box-canhan">
                    <VerifyStepTwoInner 
                        onGetUser={onGetUser} 
                        onResetDataTemporary={onResetDataTemporary}
                        onMergeUserTemporary={onMergeUserTemporary}
                        verifyData={verifyData}                                 
                    />
                </div>
            </div>
        </div>
    )
} 

export default connect(null,(dispatch) => ({
    onResetDataTemporary: bindActionCreators(resetDataTemporary,dispatch),
    onMergeUserTemporary:bindActionCreators(mergeUserTemporary,dispatch)
}))(LoginStepTwo);