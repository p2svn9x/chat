import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {reduxForm,Field,change,untouch,SubmissionError} from 'redux-form';
import {Link} from 'react-router-dom';
import {Button} from 'muicss/react';
import FacebookLogin from 'react-facebook-login';
import Loading from '../Loading';
import {InputField,InputPasswordField} from '../FormFields';
import { FB_APPID, FB_APP_VERSION, FB_APP_LOCALE } from '../../configs/facebook';
import {FORM_LOGIN} from '../../constants/formid';
import {PATH_REGISTER, PATH_FORGOT_PASSWORD} from '../../constants/pathname';
import {detectLoginType} from '../../helpers/validate';
import { submitFormLogin } from '../../actions/submit';
import { requestLoginFacebook } from '../../actions/request';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors = {};      
    if (!values.email){
        errors.email = 'Chưa nhập Email/Tên đăng nhập/SĐT'
    } else if (!detectLoginType(values.email)){
        errors.email = 'Nhập sai Email/Tên đăng nhập/SĐT'
    }     
    if (!values.password){
        errors.password = 'Chưa nhập mật khẩu'
    } else if (values.password.length < 6){
        errors.password = 'Độ dài mật khẩu ít nhất 6 ký tự'
    } else if (values.password.length > 15){
        errors.password = 'Độ dài mật khẩu nhiều nhất 15 ký tự'
    }
    return errors
} 

const LoginForm = reduxForm({
    form:FORM_LOGIN,        
    onSubmit:(values,dispatch,{onSubmitForm}) => {
        const errors = validate(values);               
        if (Object.keys(errors).length === 0){            
            onSubmitForm(values)            
        } else {
            throw new SubmissionError(errors)  
        }    
               
    }    
})(({handleSubmit,change}) => (
    <form className="regis-form2" onSubmit={handleSubmit}>
        <Field 
            name="email" 
            label="Email/Tên đăng nhập/SĐT" 
            component={InputField}        
            regex="\s" 
            onSetValue={(value) => change('email',value)}
            onClear={() => change('email','')}           
        />
        <Field 
            name="password" 
            label="Mật khẩu" 
            component={InputPasswordField} 
        />        
        <Button className="f-btn-orage f-btn-100 btn-h40">Đăng nhập</Button>
    </form>
));

class LoginStepOne extends React.Component {
    constructor(){
        super();
        this.state = {
            loading:!1,
            error:''           
        }
    }
    onSubmitForm = (values) => {
        this.setState({loading:!0,error:''})
        this.props.onLogin(values,this.responseHandle.bind(this))
    }
    handleFacebookResponse = (response) => {        
        if (!!response.accessToken){
            this.setState({loading:!0,error:''});
            this.props.onLoginUseFacebook(response.accessToken,this.responseHandle.bind(this))
        } else {
            this.setState({loading:!1,error:'Truy cập từ Facebook bị từ chối!'})
        }
    }
    responseHandle = (response) => {
        if (!!response.error){  
            this.setState({loading:!1,error:response.error.message})            
            this.props.resetPassword();
            this.props.clearErrorPassword()
        } else {            
            this.setState({loading:!1})
            if (response.message === '2-STEP-VERIFICATION'){                
                this.props.onChangeStep(response.data)
            } else {
                this.props.onGetUser()
            }
        }
    }
    render(){
        const {loading,error} = this.state;         
        return (
            <div className="block-big">
                <Loading isLoading={loading} />                
                <div className="block-regis"> 
                    <h2 className="rs regis-title">Đăng nhập</h2>                    
                    <LineErrorMessage type="error" message={error} />                                      
                    <LoginForm onSubmitForm={this.onSubmitForm.bind(this)} />                    
                    <FacebookLogin 
                        appId={FB_APPID}
                        version={FB_APP_VERSION}
                        language={FB_APP_LOCALE} 
                        xfbml={!0}
                        isMobile={!1}
                        cssClass="mui-btn f-btn-100 btn-h40 btn-h40-fb" 
                        textButton="Đăng nhập bằng Facebook"
                        scope="public_profile,email"
                        callback={this.handleFacebookResponse.bind(this)}
                    /> 
                    <div className="block-dk-bot">
                        <Link className="regis-new" to={PATH_REGISTER}>Đăng ký mới</Link>   
                        <Link className="quen-mk" to={PATH_FORGOT_PASSWORD}>Quên mật khẩu?</Link>
                    </div>
                </div>
            </div>
        )
    }
}

export default connect(null,(dispatch) => ({    
    onLogin:bindActionCreators(submitFormLogin,dispatch),    
    onLoginUseFacebook:bindActionCreators(requestLoginFacebook,dispatch),
    resetPassword:() => bindActionCreators(change,dispatch)(FORM_LOGIN,'password',''),
    clearErrorPassword:() => bindActionCreators(untouch,dispatch)(FORM_LOGIN,'password')
}))(LoginStepOne);

LoginStepOne.defaultProps = {
    onChangeStep: () => {}
}