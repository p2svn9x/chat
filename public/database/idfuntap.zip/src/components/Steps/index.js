import React from 'react';
const matchProps = (order,step) => {    
    if (typeof step !== 'string' && typeof step !== 'number') return !1;
    if (typeof order !== 'string' && typeof order !== 'number') return !1;
    if (Number(step) === Number(order)){
        return !0
    }
    return !1
}

const Steps = ({order,children}) => {     
    let child,match;
    React.Children.forEach(children,element => {       
        if (!match && React.isValidElement(element)){            
            match = matchProps(order,element.props.step)
            child = element
        }              
    })      
    return match ? React.cloneElement(child) : null
} 
export default Steps;