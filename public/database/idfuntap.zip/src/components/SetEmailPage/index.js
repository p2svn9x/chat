import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {CSSTransition,TransitionGroup} from 'react-transition-group';
import Steps from '../Steps';
import CreateNewEmail from '../CreateNewEmail';
import SetNewEmail from '../SetNewEmail';
import VerifyCodeNewEmail from '../VerifyCodeNewEmail';
import UpdateSuccess from '../UpdateSuccess';
import {change_user_security,claimReward} from '../../actions/user';
import { getUserInfo } from '../../helpers/filters';
import VerifyCodeUsePhone from '../VerifyCodeUsePhone';
import ConfirmPassword from '../ConfirmPassword';
import {requestSetNewEmail} from '../../actions/request';
//import VerifySetNewEmail from '../VerifySetNewEmail';

class SetEmailPage extends React.Component {   
    constructor(){
        super();      
        this.emailTmp = null;
        this.handleRequestSet = this.handleRequestSet.bind(this)
    }  
    componentWillMount(){
        if (this.props.createdCodeNewEmail && this.props.newEmail){
            this.step = 5
        } else if (this.props.createdCodeOldPhone) {
            this.step = 4
        } else {
            this.handleType()
        }
    }       
    changestep(step){        
        this.step = step;                
        this.forceUpdate()
    }
    handleType(){
        if (this.emailTmp){
            this.changestep(2)
        } else if (this.props.email){
            this.changestep(1)
        } else {
            this.changestep(2)
        }        
    }
    handleRequestSet = (response) => {
        this.handleResponse(response)
    }
    handleSubmitSet = (callback) => {
        this.props.onRequestSetEmail((response) => {
            this.handleResponse(response,callback)            
        })
    }
    handleResponse(response,callback){
        if (!!response.error){
            if (response.error.code === 1){
                this.changestep(3)
            } else {
                this.changestep(4)
            }
        } else {  
            if (typeof callback === 'function'){
                callback()
            } else {                
                this.handleType()
            }  
        }
    }
    render(){
       const {
           newEmail,
           changeSercurity,
           onRequestSetEmail,
           onClaimReward        
       } = this.props;
       
        return (
            <div>                   
                <TransitionGroup>
                    <CSSTransition classNames="fade" key={`set-${this.step}`} timeout={300}>
                        <Steps order={this.step || 1}>
                            <SetNewEmail 
                                step={1}
                                onChangeType={() => this.changestep(2)}
                                onSubmit={this.handleSubmitSet.bind(this)}
                                onSuccess={() => this.changestep(5)}
                                onError={() => this.changestep(4)}                                                       
                            />
                            <CreateNewEmail 
                                step={2}     
                                emailTmp={this.emailTmp}   
                                onSetEmailTmp={(email) => this.emailTmp = email}  
                                onSubmit={this.handleSubmitSet.bind(this)}                     
                                onSuccess={() => this.changestep(5)}
                                onReverify={() => this.changestep(4)}
                            />  
                            <ConfirmPassword 
                                step={3} 
                                show={!0} 
                                onConfirmed={() => onRequestSetEmail(this.handleRequestSet)} 
                            />
                            <VerifyCodeUsePhone
                                step={4}
                                onVerified={() => this.handleType()}
                             />                          
                            <VerifyCodeNewEmail 
                                step={5}
                                newEmail={newEmail}
                                onVerified={() => this.changestep(6)}
                                onReverify={() => this.changestep(4)}
                            />
                            <UpdateSuccess 
                                step={6} 
                                title="Xác thực địa chỉ email thành công" 
                                timer={5} 
                                onRemove={() => {
                                    changeSercurity({new_email:'',email:newEmail,email_verified:!0})                                   
                                    onClaimReward()
                                }} 
                            />                               
                        </Steps>
                    </CSSTransition>
                </TransitionGroup>     
            </div>              
        )
        
    }
}

export default connect((state) => {
    const securityInfo = getUserInfo(state,'Security')('email','new_email') || {};    
    return {
        email:securityInfo.email || null,
        newEmail:securityInfo.new_email || null,
        createdCodeNewEmail:state.temporary.createdCodeNewEmail,
        createdCodeOldPhone:state.temporary.createdCodeOldPhone
    }
},(dispatch) => ({
    changeSercurity:bindActionCreators(change_user_security,dispatch),
    onRequestSetEmail: bindActionCreators(requestSetNewEmail,dispatch),
    onClaimReward:() => bindActionCreators(claimReward,dispatch)('security_info'),
}))(SetEmailPage);
