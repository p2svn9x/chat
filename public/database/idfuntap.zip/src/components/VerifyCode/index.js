import React from 'react';
import {compose} from 'redux';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {InputField,InputCheckboxField} from '../FormFields';
import {reduxForm,Field,stopSubmit,SubmissionError} from 'redux-form';
import Button from 'muicss/lib/react/button';
import {FORM_VERIFY_CODE_CREATE} from '../../constants/formid';
import Loading from '../Loading';
import {createVerifyCode} from '../../actions/request';
import {submitFormVerifyCode} from '../../actions/submit';
import ConfirmPassword from '../ConfirmPassword';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors = {};
    if (!values || !values.codePin){
        errors.codePin = 'Chưa nhập mã xác thực!'
    } else if (values.codePin.length < 4){
        errors.codePin = 'Mã xác thực quá ngắn!'
    } else if (values.codePin.length > 6){
        errors.codePin = 'Mã xác thực quá dài!'
    }
    return errors
}

const Buttona = ({onClick,label,className,...props}) => (
    <a style={{textTransform:'initial'}} className={`mui-btn mui-btn-m10 f-btn-100 f-btn-gray ${className ? className : ''}`} {...props} onClick={onClick}>{label}</a>
)

const ResendButton = ({isCreated,timer,onCreate,onResend}) => {   
    if (!isCreated && !!onCreate){
        return (
            <Buttona onClick={onCreate} label="NHẬN MÃ XÁC THỰC" />            
        )
    }
    if (!!onResend){
        return (
            <Buttona 
                disabled={timer > 0 ? !0 : !1} 
                className={timer > 0 ? 'f-btn-disable f-text-gray' : ''} 
                onClick={onResend} 
                label={`GỬI LẠI MÃ ${timer > 0 ? `(${timer}s)` : ''}`} 
            />
        )
    }
    return null
}

class VerifyCode extends React.Component {
    constructor(props){
        super(props);
        this.created = !1;
        this.state = {
            timer:'',
            loading:!1,
            confirmPassword:!1,
            message:{}            
        }        
        this.handleResponse = this.handleResponse.bind(this)      
    }   
    componentWillMount(){
        const {initTimer,createAPI} = this.props;        
        if (initTimer){
            this.created = !0;
            this.initCountdown(initTimer)
        } else if (!!createAPI){
            this.onCreate()
        } 
    }   
    componentWillUnmount(){
        if (this.timer) clearInterval(this.timer)
    }
    handleResponse = (response) => { 
        if (!!response.error){
            if (response.error.code === 1){
                this.setState({loading:!1,confirmPassword:!0});
                return;
            }
            if (response.error.code === 2){
                this.setState({loading:!1});
                this.props.onReverify()
                return;
            }
            this.setState({
                loading:!1,
                message:{
                    type:'error',
                    message:response.error.message
                }
            })
        } else {
            this.created = !0;
            this.setState({
                loading:!1,
                message:{
                    type:'success',
                    message:response.message
                }
            })
            this.initCountdown(60);
            this.props.onCodeCreated()
        }
    }
    onCreate = () => {
        const {createAPI,onCreateVerifyCode} = this.props;
        if (!this.created && !!createAPI){
            this.setState({loading:!0,message:{}});                        
            onCreateVerifyCode(createAPI,this.handleResponse)
        }
    }
    onResend = () => {
        const {resendAPI,onCreateVerifyCode} = this.props;
        if (this.created && !!resendAPI){
            this.setState({loading:!0,message:{}});
            onCreateVerifyCode(resendAPI,this.handleResponse)
        }
    }
    onSubmitForm = (values) => {       
        const {submitAPI,onSubmitVerifyCode,onVerified,onStopSubmit} = this.props;
        const errors = validate(values); 
        if (Object.keys(errors).length === 0){
            if (!this.state.loading && !!submitAPI){
                const _this = this;
                this.setState({loading:!0,message:{}});            
                onSubmitVerifyCode(values,submitAPI,(response) => {
                    if (!!response.error){
                        if (response.error.code === 2){
                            _this.props.onReverify()
                        }
                        if (response.error.code === 4){
                            _this.setState({loading:!1});
                            onStopSubmit(response.error.message)
                        } else {
                            _this.setState({loading:!1,message:{type:'error',message:response.error.message}})
                        }                   
                    } else {
                        onVerified()
                    }
                })
            }
        } else {
           throw new SubmissionError(errors) 
        }      
    }
    initCountdown(initTimer){   
        this.setState({timer:initTimer});    
        this.timer = setInterval(() => {
            let currentTimer;
            let prevTimer = this.state.timer;            
            currentTimer = prevTimer - 1;                      
            if (currentTimer <= 0){                
                this.setState({timer:0});
                clearInterval(this.timer);
            } else {                           
                this.setState({timer:currentTimer})
            }
        },1000)
    }
    render(){
        const {title,submitting,handleSubmit,change,description,buttonText,trustedField,createAPI,resendAPI} = this.props;
        const {timer,loading,message,confirmPassword} = this.state;        
        return (
            <div>
                <ConfirmPassword show={confirmPassword} onConfirmed={() => this.setState({confirmPassword:!1})} />
                <form onSubmit={handleSubmit(this.onSubmitForm.bind(this))} style={{display:confirmPassword ? 'none': 'block'}}>    
                    <Loading isLoading={loading || submitting} />   
                    <h3 className="rs tlt-dn">{title}</h3>
                    <p className="rs txt-dn" dangerouslySetInnerHTML={{__html:description}} />
                    <LineErrorMessage type={message.type} message={message.message} />
                    <Field 
                        type="tel"
                        name="codePin" 
                        label="Nhập mã xác thực" 
                        numberOnly={!0}
                        component={InputField} 
                        onClear={() => change('codePin','')}
                        onSetValue={(value) => change('codePin',value)}
                    />
                    {trustedField && (<Field 
                        name="trusted" id="squaredFour" label="Không hỏi lại trên thiết bị này" component={InputCheckboxField} />
                    )}
                    <Button className="f-btn-orage f-btn-100">{buttonText}</Button>     
                    <ResendButton 
                        isCreated={this.created} 
                        timer={timer} 
                        onCreate={createAPI ? this.onCreate.bind(this) : null} 
                        onResend={resendAPI ? this.onResend.bind(this) : null} 
                    />           
                </form>
            </div>
        )
    }
}

export default compose(
    connect(null,(dispatch,props) => ({
        onCreateVerifyCode:(api,callback) => bindActionCreators(createVerifyCode,dispatch)(!props.createAPI ? 'SET' : '',api,callback),       
        onSubmitVerifyCode:bindActionCreators(submitFormVerifyCode,dispatch),
        onStopSubmit:(message) => bindActionCreators(stopSubmit,dispatch)(FORM_VERIFY_CODE_CREATE,{codePin:message})
    })),
    reduxForm({
        form:FORM_VERIFY_CODE_CREATE,
        initialValues:{codePin:''}         
    })    
)(VerifyCode);

VerifyCode.defaultProps = {    
    onVerifyCodeCreated: () => {},
    onVerified:() => {},
    onReverify:() => {}
}
