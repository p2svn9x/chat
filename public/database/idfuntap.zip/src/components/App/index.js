import React from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';
import {Route,Switch,withRouter} from 'react-router';
import DashboardPage from '../DashboardPage';
import PersonalPage from '../PersonalPage';
import SecurityPage from '../SecurityPage';
import NotFound from '../NotFound';
import LoadingSpinner from '../LoadingSpinner';
import Header from '../Header';
import Footer from '../Footer';
import {
  PATH_DASHBOARD,
  PATH_PERSONAL_INFORMATION, 
  PATH_SECURITY_INFORMATION, 
  PATH_UPDATE_EMAIL, 
  PATH_LOGIN,
  PATH_UPDATE_PHONE,
  PATH_UPDATE_PASSWORD,
  PATH_TWO_STEP_VERIFICATION,
  PATH_REGISTER,
  PATH_FORGOT_PASSWORD, 
  PATH_RECENT,
  PATH_RECENT_DEVICES,
  PATH_RECENT_GAMES,
  PATH_HISTORY_USE_FUNCOIN   
} from '../../constants/pathname';
import Loadable from 'react-loadable';
import {IndexRoute,AuthRoute,GuestRoute} from '../TransitionRoute';


const loaderDefault = (loader) => Loadable({
  loading: () => (
    <div className="box-main loading">
      <LoadingSpinner />
    </div>
  ),
  loader
})

const loaderJumbotron = (loader) => Loadable({
  loading: () => (
    <div className="block-big">
      <div className="block-regis loading">
          <LoadingSpinner />       
      </div>
    </div>
  ),
  loader
})

class App extends React.Component {  
  componentWillMount(){         
      this.props.history.listen(() => {              
          window.scrollTo(0,0);
      })
      this.createBaseHistory()           
  }  
  createBaseHistory(){    
    const {pathname} = this.props.location;
    const {history} = this.props;
    //push den page request
    if (pathname !== '/'){ 
      history.push('/');
      try {history.push(pathname)} catch(err){}      
    }   
  }
  render(){     
    return (
      <div style={{position:'relative',minHeight:'100vh',width:'100%',paddingBottom:'48px'}}>          
          <Header />   
          <div id="content-wrapper">  
            <Switch location={this.props.location}>
              <IndexRoute path="/" exact />
              <GuestRoute path={PATH_LOGIN} exact component={loaderJumbotron(() => import('../LoginPage'))} />              
              <GuestRoute path={PATH_REGISTER} exact component={loaderJumbotron(() => import('../RegisterPage'))} />
              <GuestRoute path={PATH_FORGOT_PASSWORD} exact component={loaderDefault(() => import('../ForgotPasswordPage'))} />
              <AuthRoute path={PATH_DASHBOARD} exact component={DashboardPage} /> 
              <AuthRoute path={PATH_PERSONAL_INFORMATION} exact component={PersonalPage} />  
              <AuthRoute path={PATH_SECURITY_INFORMATION} exact component={SecurityPage} />        
              <AuthRoute path={PATH_UPDATE_EMAIL} exact component={loaderDefault(() => import('../UpdateEmailPage'))} /> 
              <AuthRoute path={PATH_UPDATE_PHONE} exact component={loaderDefault(() => import('../UpdatePhonePage'))} />     
              <AuthRoute path={PATH_UPDATE_PASSWORD} exact component={loaderDefault(() => import('../UpdatePasswordPage'))} />
              <AuthRoute path={PATH_TWO_STEP_VERIFICATION} exact component={loaderDefault(() => import('../2StepSettingPage'))} /> 
              <AuthRoute path={PATH_RECENT} exact component={loaderDefault(() => import('../RecentPage'))} />
              <AuthRoute path={PATH_RECENT_DEVICES} exact component={loaderDefault(() => import('../RecentDevicesPage'))} />
              <AuthRoute path={PATH_RECENT_GAMES} exact component={loaderDefault(() => import('../RecentGamesPage'))} />
              <AuthRoute path={PATH_HISTORY_USE_FUNCOIN} exact component={loaderDefault(() => import('../HistoryUseFuncoinPage'))} />              
              <Route exact component={NotFound} />
            </Switch>  
          </div>  
          <Footer />    
      </div>
    )
  }
}

export default compose(
  withRouter,
  connect((state) => ({
    sync:state.userInfo.sync
  }),null)
)(App);
