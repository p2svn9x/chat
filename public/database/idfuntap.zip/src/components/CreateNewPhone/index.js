import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {reduxForm,Field,stopSubmit,SubmissionError} from 'redux-form';
import Button from 'muicss/lib/react/button';
import {InputField} from '../FormFields';
import {FORM_SET_NEW_PHONE} from '../../constants/formid';
import {validatePhoneNumber, errorFromPhoneNumber} from '../../helpers/validate';
import {set_new_phone} from '../../configs/api';
import {change_user_security} from '../../actions/user';
import {createdCodeNewPhone} from '../../actions/temporary';
import {createCodeSetSecurity} from '../../actions/request';
import Loading from '../Loading';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors={};
    if (!values.phone){
        errors.phone = 'Chưa điền số điện thoại mới!'
    } else if (!validatePhoneNumber(values.phone)){
        errors.phone = 'Số điện thoại không đúng định dạng!'
    }    
    return errors
}

const CreateNewPhoneForm = reduxForm({
    form:FORM_SET_NEW_PHONE,    
    onSubmit: (values,dispatch,{onSubmitForm}) => {
        const errors = validate(values);
        if (Object.keys(errors).length === 0){
            onSubmitForm(values)
        } else {
            throw new SubmissionError(errors)
        }        
    }
})(({handleSubmit,change}) => (
    <form onSubmit={handleSubmit}>        
        <Field 
            name="phone" 
            type="tel"
            label="Số điện thoại" 
            component={InputField} 
            numberOnly={!0}
            onSetValue={(value) => change('phone',value)}
            onClear={() => change('phone','')}
        />        
        <Button className="f-btn-orage f-btn-100">Cập nhật</Button> 
    </form>
));

class CreateNewPhone extends React.Component {
    constructor(){
        super();
        this.state = {
            loading:!1,
            error:'' 
        }        
    }  
    componentDidMount(){
        if (this.props.phoneTmp){
            this.handleSubmit({phone:this.props.phoneTmp})
        }
    }
    handleResponse = (response,values) => {            
        const {onSuccess,onReverify,changeSecurity,onStopSubmit,onCreatedCodeNewPhone} = this.props;  
        if (!!response.error){
            if (response.error.code === 2){
                this.setState({loading:!1});
                onReverify()
            } else if (response.error.code === 4){
                this.setState({loading:!1});
                onStopSubmit(response.error.message)
            } else {
                this.setState({loading:!1,error:response.error.message})
            }
        } else {           
            changeSecurity({new_phone:values.phone});
            onCreatedCodeNewPhone(values.phone);
            onSuccess()
        }
    }
    handleSubmit = (values) => {
        const {onSubmit,onCreateCodeNewPhone,onSetPhoneTmp} = this.props;
        const _this = this;
        if (!this.state.loading){
            onSetPhoneTmp(values.phone);
            this.setState({loading:!0,error:''});
            onSubmit(() => {     
                if (values.phone){
                    let err = errorFromPhoneNumber(values.phone);
                    if(err){
                        _this.setState({loading:!1,error:err})
                        return !1
                    }
                }           
                onCreateCodeNewPhone(values,(response) => this.handleResponse.call(this,response,values))
            })
        }        
    }
    render(){
        const {loading,error} = this.state;
        const {phoneTmp} = this.props;
        return (
            <div>           
                <Loading isLoading={loading} />               
                <h3 className="rs tlt-dn">Thiết lập SĐT mới của bạn</h3>
                <p className="rs txt-dn">
                    SĐT này có thể được sử dụng để đăng nhập và lấy lại mật khẩu. 
                    Hệ thống sẽ gửi mã xác thực vào SĐT của bạn. Vui lòng chờ trong giây lát để nhận mã xác thực
                </p>
                <LineErrorMessage type="error" message={error} />               
                <CreateNewPhoneForm            
                    initialValues={{phone:phoneTmp || ''}}              
                    onSubmitForm={this.handleSubmit.bind(this)}
                />
            </div>               
        )
    }
}

export default connect(null,(dispatch) => ({
    changeSecurity: bindActionCreators(change_user_security,dispatch),
    onCreatedCodeNewPhone:(phone) => bindActionCreators(createdCodeNewPhone,dispatch)(Date.now(),phone),
    onCreateCodeNewPhone:(values,callback) => bindActionCreators(createCodeSetSecurity,dispatch)(() => set_new_phone(values),callback),
    onStopSubmit:(message) => bindActionCreators(stopSubmit,dispatch)(FORM_SET_NEW_PHONE,{phone:message})    
}))(CreateNewPhone);

CreateNewPhone.defaultProps = {
    onReverify:() => {},
    onSetPhoneTmp:() => {}
}