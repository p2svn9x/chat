import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {destroy,submit} from 'redux-form';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import ConfirmPassword from '../ConfirmPassword';
import ChangePersonal from './ChangePersonal';
import UpdateSuccess from '../UpdateSuccess';
import Steps from '../Steps';
import {FORM_UPDATE_PERSONAL} from '../../constants/formid';

const uniqkey = Math.random().toString(36).substr(2, 6);

class PersonalPage extends React.Component {   
    constructor(){
        super();
        this.step = 2;
    }
    changestep(step){
        this.step = step;
        this.forceUpdate()
    }   
    componentWillUnmount(){
        this.props.onDestroyForm()
    }
    render(){  
        const {onSubmitForm} = this.props;             
        return (
            <div className="box-main">  
                <div className="box-canhan">
                <TransitionGroup>
                    <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                        <Steps order={this.step}>
                            <ConfirmPassword 
                                step={1}
                                show={!0} 
                                onConfirmed={() => {
                                    this.changestep(2);
                                    onSubmitForm()
                                }}
                            />                
                            <ChangePersonal
                                step={2}
                                onReverify={() => this.changestep(1)}
                                onChanged={() => this.changestep(3)}
                            /> 
                            <UpdateSuccess 
                                step={3} 
                                timer={5} 
                                title="Thay đổi thông tin cá nhân thành công!"                                                            
                            />   
                        </Steps>    
                    </CSSTransition>   
                </TransitionGroup>  
                </div>                       
            </div>
        )
    }
}
 
export default connect(null,(dispatch) => ({
    onDestroyForm:() => bindActionCreators(destroy,dispatch)(FORM_UPDATE_PERSONAL),
    onSubmitForm:() => bindActionCreators(submit,dispatch)(FORM_UPDATE_PERSONAL)
}))(PersonalPage);