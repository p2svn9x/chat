import React from 'react';
import moment from 'moment';
import {compose, bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {reduxForm,Field,formValueSelector,SubmissionError} from 'redux-form';
import {Button,Row,Col} from 'muicss/react';
import Description from '../Description';
import {
    InputField,
    InputDateField,
    SelectGender,
    SelectDistrict,
    SelectProvince
} from '../FormFields';
import {FORM_UPDATE_PERSONAL} from '../../constants/formid';
import {
    validatePeopleId,
    validateAddress,
    validateFullname,
    validateDatetime, 
    validateProvince
} from '../../helpers/validate';
import { submitFormPersonal } from '../../actions/submit';
import Loading from '../Loading';
import {change_user_profile,claimReward} from '../../actions/user';
import LineErrorMessage from '../LineErrorMessage';
import {prefixProvince} from '../../helpers/utils';
import { syncDirection } from '../../actions/direction';

const selector = formValueSelector(FORM_UPDATE_PERSONAL)

const validate = values => { 
    const errors = {};
    if (!values.fullname){
        errors.fullname = 'Không được để trống!'
    } else if (values.fullname.length < 3){
        errors.fullname = 'Họ và tên quá ngắn!'
    } else if (!validateFullname(values.fullname)) {
        errors.fullname = 'Họ và tên không đúng định dạng!'
    } 
    if (!values.birthday){
        errors.birthday = 'Chưa chọn ngày tháng năm sinh!'
    } else if (!validateDatetime(values.birthday.valueOf())){
        errors.birthday = 'Ngày tháng năm sinh không hợp lệ!'
    }
    if (!values.gender){
        errors.gender = 'Chưa chọn giới tính!'
    } else if (!values.gender.match(/(Nam|Nữ|Không Xác Định)$/gi)){
        errors.gender = 'Giới tính không có trong mục chọn!'
    }
    if (!values.province){
        errors.province = 'Chưa chọn tỉnh/thành phố!'
    } else if (!validateProvince(values.province)){
        errors.province = 'Tỉnh/thành phố không có trong danh sách!'
    }
    if (!values.district){
        errors.district = 'Chưa chọn quận/huyện!'
    }
    if (!values.address){
        errors.address = 'Chưa điền địa chỉ Phường/Xã/Đường!'
    } else if (!validateAddress(values.address)){
        errors.address = 'Địa chỉ không đúng định dạng!'
    }
    if (!values.peopleId){
        errors.peopleId = 'Chưa điền CMND/CCCD/Hộ chiếu'
    } else if (!validatePeopleId(values.peopleId)){
        errors.peopleId = 'CMND/CCCD/Hộ chiếu chưa đúng định dạng'
    }
    if (!values.peopleId){
        errors.peopleId = 'Chưa điền CMND/CCCD/Hộ chiếu'
    } else if (!validatePeopleId(values.peopleId)){
        errors.peopleId = 'CMND/CCCD/Hộ chiếu chưa đúng định dạng'
    }
    if (!values.peopleId_place_get){
        errors.peopleId_place_get = 'Chưa chọn nơi cấp!'
    } else if (!validateProvince(values.peopleId_place_get)){
        errors.peopleId_place_get = 'Tỉnh/thành phố không có trong danh sách!'
    }
    if (!values.peopleId_date_get){
        errors.peopleId_date_get = 'Chưa chọn ngày cấp!'
    } else if (!validateDatetime(values.peopleId_date_get)){
        errors.peopleId_date_get = 'Ngày cấp không hợp lệ!'
    }
    return errors
}

const submit = (values,dispatch,{onSubmitForm,onChangeProfile,onClaimReward,onReverify,onSetErrorResponse,onChanged,pristine}) => {   
    const errors = validate(values);
    if (Object.keys(errors).length === 0){
        if (!pristine){  
            let data = Object.assign({},values);
            data.fullname = data.fullname.trim();
            data.address = data.address.trim();
            data.birthday = moment(data.birthday,'DD/MM/YYYY').format('YYYY-MM-DD');
            data.peopleId_date_get = moment(data.peopleId_date_get,'DD/MM/YYYY').format('YYYY-MM-DD'); 
            data.province = prefixProvince(values.province,!1);
            data.peopleId_place_get = prefixProvince(values.peopleId_place_get,!1);
            const request = () => new Promise((resolve,reject) => onSubmitForm(data,resolve,reject));
            onSetErrorResponse('');
            return request()
            .then(() => {
                data.province = prefixProvince(values.province,!0);
                data.peopleId_place_get = prefixProvince(values.peopleId_place_get,!0);
                data.birthday = moment(data.birthday,'YYYY-MM-DD').format('DD/MM/YYYY');
                data.peopleId_date_get = moment(data.peopleId_date_get,'YYYY-MM-DD').format('DD/MM/YYYY');            
                onChangeProfile(data);
                onClaimReward();
                onChanged()
            })
            .catch((error) => {
                if (error.code === 1){
                    onReverify()
                } else {
                    onSetErrorResponse(error.message)
                }            
            })
        }       
    } else {
        throw new SubmissionError(errors)
    }    
} 

const FormPersonal = compose(
    connect((state) => {
        const profile = state.userInfo.Profile || {};         
        return {
            initialValues:{
                fullname:profile.fullname || '',
                birthday:profile.birthday || '',
                profile:profile.birthday || '',
                gender:profile.gender || '',
                province:prefixProvince(profile.province,!0) || '',
                district:profile.district || '',
                address:profile.address || '',
                peopleId:profile.peopleId || '',
                peopleId_place_get:profile.peopleId_place_get || '',
                peopleId_date_get:prefixProvince(profile.peopleId_date_get,!0) || ''
            },
            provinceName:selector(state,'province')
        }
    },(dispatch) => ({
        onSubmitForm:bindActionCreators(submitFormPersonal,dispatch),
        onChangeProfile: bindActionCreators(change_user_profile,dispatch),
        onClaimReward:() => bindActionCreators(claimReward,dispatch)('profile_info')
    })),
    reduxForm({
        form:FORM_UPDATE_PERSONAL,  
        onSubmit:submit,
        destroyOnUnmount:!1     
    }) 
)(({handleSubmit,provinceName,change,pristine,submitting}) => (
    <div>          
        <Loading isLoading={submitting} />
        <form onSubmit={handleSubmit}>
            <Field 
                name="fullname" 
                label="Họ và tên" 
                component={InputField} 
                onClear={() => change('fullname','')}
            />
            <Field                
                label="Ngày sinh" 
                name="birthday"
                onSetValue={(values) => change('birthday',values)}
                component={InputDateField} 
                //onSetValue={(values) => change('birthday',values)}
            />
            <Field 
                name="gender" 
                label="Giới tính" 
                component={SelectGender} 
            />
            <Row>
                <Col xs="6">
                    <Field 
                        name="province" 
                        onResetToField={() => change('district','')}                     
                        label="Tỉnh/TP" 
                        component={SelectProvince} 
                    />
                </Col>                    
                <Col xs="6">
                    <Field 
                        name="district"                        
                        label="Quận/Huyện" 
                        component={SelectDistrict} 
                        provinceName={provinceName}
                    />
                </Col>
            </Row>
            <Field 
                name="address" 
                label="Phường, Xã, Đường" 
                component={InputField} 
                onClear={() => change('address','')}
            />
            <Field 
                name="peopleId" 
                label="CMND/CCCD/Hộ chiếu" 
                component={InputField} 
                onClear={() => change('peopleId','')}
            />
            <Field 
                name="peopleId_place_get" 
                label="Nơi cấp" 
                component={SelectProvince} 
            />
            <Field                 
                label="Ngày cấp" 
                name="peopleId_date_get"
                onSetValue={(values) => change('peopleId_date_get',values)}
                component={InputDateField} 
                //onSetValue={(values) => change('birthday',values)}
            />            
            <Button className={`f-btn-100 ${pristine ? 'f-btn-gray mui--is-disabled' : 'f-btn-orage'}`}>Thay đổi</Button>        
        </form>
    </div>
));


class ChangePersonal extends React.Component {
    state = {
        error:''
    }
    componentWillMount(){
        this.props.onSyncDirection()
    }
    setErrorResponse = (error) => {
        window.scrollTo(0,0);
        this.setState({error})
    }
    render(){
        const {error} = this.state;
        const {onReverify,onChanged} = this.props;
        return (
            <div>    
                <div style={{margin:'-16px -16px 16px'}}>          
                    <Description
                        icon="ico-desc-cn"
                        title="Hoàn thiện thông tin cá nhân"
                        desc="Cập nhật thông tin cá nhân đầy đủ, kịp thời giúp bảo vệ tài khoản và được hỗ trợ nhanh chóng"
                    />
                </div>  
                <LineErrorMessage type="error" message={error} />
                <FormPersonal                         
                    onReverify={onReverify}
                    onChanged={onChanged}
                    onSetErrorResponse={this.setErrorResponse.bind(this)}                   
                />
            </div>
        )
    }
}

export default connect(null,(dispatch) => ({
    onSyncDirection:bindActionCreators(syncDirection,dispatch),
}))(ChangePersonal);

ChangePersonal.defaultProps = {
    onReverify: () => {},
    onChanged: () => {}
}