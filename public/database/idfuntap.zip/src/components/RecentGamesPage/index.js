import React from 'react';
import { bindActionCreators } from 'redux';
import moment from 'moment';
import { connect } from 'react-redux';
import Loading from '../Loading';
import {getGamesPlayed} from '../../actions/games';
import 'moment/locale/vi';

const ErrorLine = ({message}) => (
    <div style={{padding:'15px',color:'red'}}>{message}</div>
)

const GamesPlayed = ({sync,error,games}) => {
    if (sync){
        return <Loading isLoading={!0} />
    }
    if (!!error.message){
        return <ErrorLine message={error.message} />
    }
    if (games.length === 0){
        return <ErrorLine message="Bạn chưa chơi games nào trong 30 ngày gần đây" />
    }
    return (
        <React.Fragment>
            {games.map((g,i) => (
                <div className="userTask" key={i}>
                    <ul className="rs lstDevice">
                        <li>
                            <div className="txt-dual list-game-recently">
                                <i className="ico-game"><img src={g.url} alt="" /></i>
                                <span className="name-device">{g.game}</span>
                                <span>IP: {g.ip}</span>
                                <span className="log-time">{moment(g.time * 1000).fromNow()}</span>
                            </div>
                        </li>
                    </ul>
                </div>
            ))}            
        </React.Fragment>
    )
}

class RecentGamesPage extends React.Component {
    componentWillMount(){
        this.props.onGetGames() 
    }    
    render(){
        const {sync,error,games} = this.props;
        return (
            <div className="box-main">                
                <h2 className="rs tit-xoatincay">
                    Các game đã chơi trên tài khoản của bạn trong 30 ngày qua hoặc đang đăng nhập.
                </h2>
                <GamesPlayed sync={sync} error={error} games={games} />
            </div>
        )
    }
}

export default connect((state) => ({
    sync:state.games.sync,
    error: state.games.error,
    games:state.games.data    
}),(dispatch) => ({
    onGetGames: bindActionCreators(getGamesPlayed,dispatch)    
}))(RecentGamesPage);