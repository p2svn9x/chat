import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {reduxForm,Field,stopSubmit,SubmissionError} from 'redux-form';
import Button from 'muicss/lib/react/button';
import {InputField} from '../FormFields';
import {FORM_SET_NEW_EMAIL} from '../../constants/formid';
import {validateEmail} from '../../helpers/validate';
import {set_new_email} from '../../configs/api';
import {change_user_security} from '../../actions/user';
import {createdCodeNewEmail} from '../../actions/temporary';
import {createCodeSetSecurity} from '../../actions/request';
import Loading from '../Loading';
import LineErrorMessage from '../LineErrorMessage';

const validate = (values) => {
    const errors = {};
    if (!values.email){
        errors.email = 'Chưa điền email mới!'
    } else if (!validateEmail(values.email)){
        errors.email = 'Email mới không đúng định dạng!'
    }    
    return errors
}

const CreateNewEmailForm = reduxForm({
    form:FORM_SET_NEW_EMAIL,    
    onSubmit: (values,dispatch,{onSubmitForm}) => {
        const errors = validate(values);
        if (Object.keys(errors).length === 0){
            onSubmitForm(values)
        } else {
            throw new SubmissionError(errors)
        }        
    }
})(({handleSubmit,change}) => (
    <form onSubmit={handleSubmit}>        
        <Field 
            name="email" 
            label="Email mới" 
            component={InputField} 
            onClear={() => change('email','')}
        />        
        <Button className="f-btn-orage f-btn-100">Cập nhật</Button> 
    </form>
));

class CreateNewEmail extends React.Component {
    constructor(){
        super();
        this.state = {
            loading:!1,
            error:'',           
        }        
    }  
    componentDidMount(){
        if (this.props.emailTmp){
            this.handleSubmit({email:this.props.emailTmp})
        }
    }
    handleResponse = (response,values) => {            
        const {onSuccess,onReverify,changeSecurity,onStopSubmit,onCreatedCodeNewEmail} = this.props;  
        if (!!response.error){
            if (response.error.code === 2){
                this.setState({loading:!1});              
                onReverify()
            } else if (response.error.code === 4){
                this.setState({loading:!1});
                onStopSubmit(response.error.message)
            } else {               
                this.setState({loading:!1,error:response.error.message})
            }
        } else {           
            changeSecurity({new_email:values.email});
            onCreatedCodeNewEmail(values.email);
            onSuccess()
        }
    }
    handleSubmit = (values) => {
        const {onSubmit,onCreateCodeNewEmail,onSetEmailTmp} = this.props;
        if (!this.state.loading){
            onSetEmailTmp(values.email);
            this.setState({loading:!0,error:''});
            onSubmit(() => {                
                onCreateCodeNewEmail(values,(response) => this.handleResponse.call(this,response,values))
            })
        }        
    }
    render(){        
        const {loading,error} = this.state;
        const {emailTmp} = this.props;             
        return (
            <div>           
                <Loading isLoading={loading} />               
                <h3 className="rs tlt-dn">Thiết lập email mới của bạn</h3>
                <p className="rs txt-dn">
                    Email này có thể được sử dụng để đăng nhập và lấy lại mật khẩu. Chúng tôi sẽ liên hệ với bạn qua email này trong trường hợp cần liên hệ.
                </p>
                <LineErrorMessage type="error" message={error} />
                <CreateNewEmailForm 
                    initialValues={{email:emailTmp || ''}}                                             
                    onSubmitForm={this.handleSubmit.bind(this)}
                />
            </div>               
        )
    }
}

export default connect(null,(dispatch) => ({
    changeSecurity: bindActionCreators(change_user_security,dispatch),
    onCreatedCodeNewEmail:(email) => bindActionCreators(createdCodeNewEmail,dispatch)(Date.now(),email),
    onCreateCodeNewEmail:(values,callback) => bindActionCreators(createCodeSetSecurity,dispatch)(() => set_new_email(values),callback),
    onStopSubmit:(message) => bindActionCreators(stopSubmit,dispatch)(FORM_SET_NEW_EMAIL,{email:message})    
}))(CreateNewEmail);

CreateNewEmail.defaultProps = {
    onReverify:() => {},
    onSetEmailTmp:() => {}
}