import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {reduxForm,Field,SubmissionError} from 'redux-form';
import {Button} from 'muicss/react';
import {InputPasswordField} from '../FormFields';
import {FORM_UPDATE_PASSWORD} from '../../constants/formid';
import passwordStr from '../../helpers/passwordStr';
import {InputCheckboxField} from '../FormFields';
import Loading from '../Loading';
import { submitUpdatePassword } from '../../actions/submit';
import { requestChangeSecurity } from '../../actions/request';
import LineErrorMessage from '../LineErrorMessage';
import { isTestMode } from '../../helpers/utils';

const validate = (values) => {
    const errors = {};
    if (!values.password){
        errors.password = 'Chưa nhập mật khẩu mới!'
    } else if (values.password.length < 6 || values.password.length > 15){
        errors.password = 'Độ dài mật khẩu trong khoảng 6 - 15 ký tự'
    }
    if (!values.temppassword){
        errors.temppassword = 'Chưa xác nhận mật khẩu mới!'
    } else if (values.password !== values.temppassword){
        errors.temppassword = 'Mật khẩu không trùng khớp!'
    }
    return errors
}

const PasswordStrength = ({input:{value}}) => {
    var type = passwordStr(value);
    if (type === '1'){
       return <strong className="mk-bmcap1">Yếu</strong>
    } else if (type === '2'){
        return <strong className="mk-bmcap2">Trung bình</strong>
    } else if (type === '3'){
        return <strong className="mk-bmcap3">Mạnh</strong>
    } else {
        return null
    }   
}
const SetPasswordForm = reduxForm({
        form:FORM_UPDATE_PASSWORD,               
        onSubmit: (values,dispatch,{forceButton,onSubmitForm}) => {
            const errors = validate(values);
            if (Object.keys(errors).length === 0){
                if (forceButton) {
                    // truong hop vao form xac thuc 2 lop
                    let data = Object.assign({},values);        
                    if (!data.forceLogout){
                        data.forceLogout = 0
                    } else {
                        data.forceLogout = 1
                    } 
                    return onSubmitForm(data)                
                }
                return onSubmitForm(values)
            } else {
                throw new SubmissionError(errors)
            }
        }
})(({handleSubmit,forceButton}) => (
    <form onSubmit={handleSubmit}>   
        <p className="rs txt-dn">Độ mạnh mật khẩu:   
            <Field name="password" component={PasswordStrength} />
        </p>
        <Field name="password" label="Mật khẩu mới" component={InputPasswordField} />
        <Field name="temppassword" label="Nhập lại mật khẩu mới" component={InputPasswordField} />
        {forceButton && (
            <Field 
                name="forceLogout" 
                id="squaredFour" 
                label="Đăng xuất khỏi các thiết bị đang sử dụng" 
                component={InputCheckboxField} 
            />
        )}        
        <Button className="f-btn-orage f-btn-100">Đặt mật khẩu</Button>
    </form>
))
class SetPassword extends React.Component {
    constructor(){
        super();        
        this.state = {
            loading:!1,
            error:''
        }   
        this.responseHandle = this.responseHandle.bind(this);
    }   
    submitHandle = (data) => {
        const _this = this;
        const {onReverify,onSubmitForm,submitAPI} = this.props;
        this.setState({loading:!0,error:''});        
        this.props.onRequestChangeSecurity((response) => {
            if (!!response.error){
                onReverify()
            } else {
                onSubmitForm(() => submitAPI(data),_this.responseHandle)
            }
        });        
    }    
    responseHandle = (response) => {        
        if (!!response.error){             
            this.setState({loading:!1,error:response.error.message})                     
        } else {
            this.setState({loading:!1});
            this.props.onSuccess()
        }
    }
    render(){
        const {loading,error} = this.state;
        const inTest = isTestMode();
        return (
            <div>      
                <Loading isLoading={loading} />         
                <h3 className="rs tlt-dn">Thiết lập mật khẩu</h3>
                <p className="rs txt-dn1">
                    Mật khẩu có độ dài tối thiểu 6 ký tự và nên bao gồm chữ cái, chữ số, ký tự đặc biệt. <br/> 
                    <b>Khuyến cáo</b>: không cung cấp mật khẩu tới bất kỳ ai.
                </p>        
                <LineErrorMessage type="error" message={error} />
                <SetPasswordForm 
                    onSubmitForm={this.submitHandle.bind(this)} 
                    forceButton={inTest && this.props.type !== 'FORGOT'}
                />                                                 
            </div>
        )
    }
}
export default connect(null,(dispatch) => ({
    onRequestChangeSecurity:bindActionCreators(requestChangeSecurity,dispatch),
    onSubmitForm:bindActionCreators(submitUpdatePassword,dispatch)   
}))(SetPassword);

SetPassword.defaultProps = {
    type:'',  
    onReverify:() => {},
    onSuccess:() => {}
}