import React from 'react';
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import VerifyCode from '../VerifyCode';
import {    
    verify_set_new_phone,    
    resend_code_phone
} from '../../configs/api';
import {setSessionOTP} from '../../actions/session';
import {createdCodeNewPhone,removeCodeNewPhone} from '../../actions/temporary';
import { calcResendTimer, maskPhone } from '../../helpers/utils';
const VerifyCodeNewPhone = ({
    type,
    onVerified,
    onReverify,
    onSetSessionOTP,
    onCreatedCodeNewPhone,
    onRemoveCodeNewPhone,
    createdCodeNewPhone,
    newPhone
}) => ( 
    <VerifyCode                          
        title="Xác thực tài khoản của bạn"
        description={
            `Hệ thống đã gửi mã tới số điện thoại mới <span>${maskPhone(newPhone)}</span> 
            Nếu chưa nhận được vui lòng chờ trong giây lát.`
        }
        buttonText="Hoàn tất"
        submitAPI={(values) => verify_set_new_phone(values,type)}
        resendAPI={() => resend_code_phone(type)}       
        onCodeCreated={() => onCreatedCodeNewPhone(newPhone)}        
        initTimer={calcResendTimer(createdCodeNewPhone) || 60}
        onVerified={() => {onSetSessionOTP();onRemoveCodeNewPhone();onVerified()}}   
        onReverify={() => onReverify()}    
    />              
);   


export default connect((state) => ({   
    createdCodeNewPhone:state.temporary.createdCodeNewPhone
}),(dispatch) => ({
    onSetSessionOTP:() => bindActionCreators(setSessionOTP,dispatch)(Date.now()),
    onCreatedCodeNewPhone:(phone) => bindActionCreators(createdCodeNewPhone,dispatch)(Date.now(),phone),
    onRemoveCodeNewPhone:bindActionCreators(removeCodeNewPhone,dispatch)
}))(VerifyCodeNewPhone);

VerifyCodeNewPhone.defaultProps = {
    type:'',
    newPhone:'',
    onVerified:() => {},
    onReverify:() => {}
}