import React from 'react';
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import Input from 'muicss/lib/react/input';
import {verify_new_email} from '../../configs/api';
import {createdCodeNewEmail} from '../../actions/temporary';
import {change_user_security} from '../../actions/user';
import Loading from '../Loading';
import { createCodeSetSecurity } from '../../actions/request';
import { getUserInfo } from '../../helpers/filters';
import LineErrorMessage from '../LineErrorMessage';
import { maskEmail } from '../../helpers/utils';

class SetNewEmail extends React.Component {
    constructor(){
        super();           
        this.state = {
            loading:!1,
            error:''
        }
    }   
    handleResponse = (response) => {     
        const {onSuccess,onError,changeSecurity,email,onCreatedCodeNewEmail} = this.props;   
        if (!!response.error){
            if (response.error.code === 2){
                onError()
            } else {
                this.setState({loading:!1,error:response.error.message})
            }
        } else {
            changeSecurity({new_email:email});
            onCreatedCodeNewEmail(email);
            onSuccess()
        }
    }
    handleSubmit = () => {
        const {onSubmit,onCreateCodeNewEmail} = this.props;
        if (!this.state.loading){
            this.setState({loading:!0,error:''});
            onSubmit(() => {                
                onCreateCodeNewEmail(this.handleResponse.bind(this))
            })
        }        
    }   
    render(){
        const {email,onChangeType} = this.props;
        const {loading,error} = this.state;        
        return ( 
            <div>               
                <Loading isLoading={loading} />
                <h3 className="rs tlt-dn">Thiết lập email của bạn</h3>
                <p className="rs txt-dn">
                    Email khôi phục của bạn được sử dụng để liên lạc với bạn trong trường 
                    hợp chúng tôi phát hiện thấy hoạt động bất thường trong tài khoản của 
                    bạn hoặc bạn vô tình bị chặn.
                </p>
                <LineErrorMessage type="error" message={error} />
                <Input value={maskEmail(email)} label="Địa chỉ email của bạn" disabled={!0} />
                <a 
                    className="mui-btn f-btn-orage f-btn-100" 
                    style={{cursor:'pointer'}} 
                    onClick={this.handleSubmit}
                >Xác thực</a>
                <a 
                    className="mui-btn mui-btn-m10 f-btn-gray f-btn-100" 
                    onClick={onChangeType} 
                    style={{cursor:'pointer'}}
                >Thay đổi email</a>
            </div> 
        )
    }
}
export default connect((state) => ({
    email:getUserInfo(state,'Security')('email')   
}),(dispatch) => ({
    changeSecurity: bindActionCreators(change_user_security,dispatch),   
    onCreatedCodeNewEmail:(email) => bindActionCreators(createdCodeNewEmail,dispatch)(Date.now(),email),
    onCreateCodeNewEmail:(callback) => bindActionCreators(createCodeSetSecurity,dispatch)(verify_new_email,callback)
}))(SetNewEmail);