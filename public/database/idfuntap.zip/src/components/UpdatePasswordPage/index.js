import React from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import {PATH_UPDATE_EMAIL,PATH_UPDATE_PHONE} from '../../constants/pathname';
import CreateNewPassword from '../CreateNewPassword';
import { getUserInfo } from '../../helpers/filters';

const UpdatePasswordPage = ({phoneVerified,emailVerified}) => {
    if (!phoneVerified && !emailVerified){
        return (
            <div className="box-main">
            <div className="box-canhan">
                <h3 className="rs tlt-dn">Thiết lập Email/Số điện thoại</h3>
                <p className="rs txt-dn">
                    Bạn chưa thiết lập Email/Số điện thoại. 
                    Vui lòng thiết lập Email/Số điện thoại trước khi thiết lập mật khẩu. 
                    Hệ thống sẽ gửi mã xác thực vào Email/Số điện thoại của bạn
                </p>

                <Link to={PATH_UPDATE_EMAIL} className="mui-btn f-btn-orage f-btn-100 ">THIẾT LẬP EMAIL</Link>
                <Link to={PATH_UPDATE_PHONE} className="mui-btn f-btn-orage f-btn-100 f-mg8 ">THIẾT LẬP SĐT</Link>
            </div>
            </div>
        )
    } else {
        return (
            <div className="box-main">
                <div className="box-canhan">
                    <CreateNewPassword />
                </div>
            </div>
        )
    }
    
}
export default connect((state) => {
    let userInfo = getUserInfo(state,'Security')('phone_verified','email_verified','email');
    return {
        phoneVerified:userInfo.phone_verified,
        emailVerified:userInfo.email_verified && !!userInfo.email
    }
},null)(UpdatePasswordPage);