import React from 'react';
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import {TransitionGroup,CSSTransition} from 'react-transition-group';
import Steps from '../Steps';
import VerifyOTPSetNewPassword from '../VerifyOTPSetNewPassword';
import SetPassword from '../SetPassword';
import UpdateSuccess from '../UpdateSuccess';
import { change_user_security,claimReward } from '../../actions/user';
import ConfirmPassword from '../ConfirmPassword';
import {requestUpdatePassword} from '../../actions/request';
import { update_password } from '../../configs/api';

const uniqkey = Math.random().toString(36).substr(2, 6);

class CreateNewPassword extends React.Component {
    constructor(){
        super();        
        this.step = 1;
    }      
    componentWillMount(){
        const _this = this;
        this.props.onRequestUpdatePassword((response) => {            
            if (!response.error){
                _this.changestep(2)
            } 
        })       
    }
    changestep(step){
        this.step = step;       
        this.forceUpdate()
    }
    render(){       
        const {onClaimReward,onChangeSecurity} = this.props;
        return (                           
            <TransitionGroup>
                <CSSTransition key={`${uniqkey}-${this.step}`} classNames="fade" timeout={300}>
                    <Steps order={this.step}>
                        <ConfirmPassword 
                            step={1} 
                            show={!0}
                            onConfirmed={() => this.changestep(2)} 
                        />
                        <VerifyOTPSetNewPassword 
                            step={2} 
                            onVerified={() => this.changestep(3)} 
                        />
                        <SetPassword 
                            step={3} 
                            submitAPI={(values) => update_password(values)}   
                            onReverify={() => this.changestep(1)}                         
                            onSuccess={() => this.changestep(4)} 
                        />
                        <UpdateSuccess 
                            step={4} 
                            title="Thiết lập mật khẩu thành công" 
                            timer={5} 
                            onRemove={() => {
                                onChangeSecurity({password:!0,modified_password: Math.floor((Date.now())/1000)});
                                onClaimReward()
                            }} 
                        />
                    </Steps>
                </CSSTransition>
            </TransitionGroup>
        )
    }
} 
export default connect(null,(dispatch) => ({
    onRequestUpdatePassword:bindActionCreators(requestUpdatePassword,dispatch),
    onChangeSecurity: bindActionCreators(change_user_security,dispatch),
    onClaimReward:() => bindActionCreators(claimReward,dispatch)('security_info'),
}))(CreateNewPassword);