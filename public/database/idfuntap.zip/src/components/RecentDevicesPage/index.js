import React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import {Collapse} from 'react-collapse';
import Notification from '../Notification';
import Loading from '../Loading';
import moment from 'moment';
import {getRecentDevices,removeTrustedDevice} from '../../actions/devices';
import 'moment/locale/vi';


 
class ButtonTrusted extends React.Component {
    state = {
        modal:!1        
    }
    componentDidUpdate(){
        if (this.state.modal){
            document.body.style.overflow = 'hidden'
        } else {
            document.body.style.overflow = ''
        }
    }
    render(){
        const {show,onRemoveTrusted} = this.props;
        const {modal} = this.state;
        return (
            <div>
                {modal && (
                    <div className="pop-baomat">
                        <div className="box-tat-baomat">
                            <h2 className="rs">Thông báo</h2>
                            <p className="rs caption">
                                Xóa tin cậy thiết bị sẽ yêu cầu xác thực tài khoản vào những lần đăng nhập tiếp sau.
                            </p>
                            <p className="rs ct-bm">
                                <a style={{cursor:'pointer'}} onClick={() => this.setState({modal:!1})}>HỦY</a>
                                <a style={{cursor:'pointer'}} className="btn-tat-bm" onClick={() =>{this.setState({modal:!1});onRemoveTrusted()}}>XÓA TIN CẬY</a>
                            </p>
                        </div>
                    </div>
                )}               
                <Collapse isOpened={show}>
                    <p className="device-infor">                                    
                        <span className="quyen">Quyền truy cập tài khoản</span>
                        <a style={{cursor:'pointer'}} onClick={() => this.setState({modal:!0})} className="btn-xoatincay">XÓA TIN CẬY</a>
                    </p>
                </Collapse>
            </div>
        )
    }
}

const Product = ({product,actived,onToggle,onRemoveTrusted}) => {
    let device_icon = '';
    if (product.browser){
        let browser = product.browser;
        if (!!browser.match(/Chrome/ig)){
            device_icon = 'ico-chrome'
        } else if (!!browser.match(/Firefox/ig)){
            device_icon = 'ico-firefox'
        } else if (!!browser.match(/Opera/ig)){
            device_icon = 'ico-opera'
        } else if (!!browser.match(/Safari/ig)){
            device_icon = 'ico-safari'
        } else if (!!browser.match(/UC/ig)){
            device_icon = 'ico-uc'
        } else {
            device_icon = 'ico-browser'
        }
    } else {
        let device = product.device;
        if (device){
                if (!!device.match(/Tablet|Ipad|Tab/gi)){
                //tablet
                device_icon = 'ico-tablet ico-mobile-user'
            } else if (!!device.match(/Samsung|Iphone|Oppo|Nokia|Huawei|Sony|Vivo|Xiaomi|Htc|Motorola/gi)){
                // phone
                device_icon = 'ico-phone ico-mobile-user'
            }
        } else {
            device_icon = 'ico-device-default ico-mobile-user'
        }                                    
    }
    return (
        <li onClick={onToggle}>
            <div className={`txt-dual ${actived ? 'active' : ''} ${!product.trusted ? 'hidden-arr' :''}`}>
                <i className={`ico-device ${device_icon}`}></i>
                <span className="name-device">{product.browser || product.device}</span>
                <span>IP: <b>{product.ip}</b></span>
                <span className={(actived || !product.trusted) ? 'log-time' : 'log-time active'}>
                    {moment(Number(product.time)*1000).fromNow()}
                    {product.trusted && window.development === 'testing' && (
                        <span className="fa-tincay block">Đã tin cậy</span>
                    )}
                </span>
                {window.development === 'testing' && product.trusted && (
                <ButtonTrusted 
                    show={actived} 
                    onRemoveTrusted={onRemoveTrusted} />
                )}
            </div>
        </li>
    )
}   

class Devices extends React.Component {
    state = {
        active:'',
        loading:!1,
        notification:{}
    }
    handleResponse = (response) => {
        if (!!response.error){
            this.setState({loading:!1,notification:{type:'error',message:response.error.message}})
        } else {
            this.setState({loading:!1,notification:{type:'success',message:response.message}})
        }
    }
    render(){
        const {active,loading,notification} = this.state;
        const {sync,error,devices,onRemoveTrusted} = this.props;
        if (sync){
            return <Loading isLoading={!0} />
        }
        if (!!error.message){
            return <div style={{color:'red',padding:'15px'}}>{error.message}</div>
        }
        if (devices.length === 0){
            return (
                <div style={{color:'red',padding:'15px'}}>
                    Không có thiết bị nào truy cập trong khoảng thời gian này!
                </div>
            )
        }
        return (
            <div>
                <Loading isLoading={loading} />
                {!!notification.message && (
                    <Notification 
                        notification={notification}
                        remove={() => this.setState({notification:{}})}
                    />
                )}
                <ul className="rs lstDevice">
                    {devices.map((product,i) => 
                        <Product 
                            key={`product-${i}`}
                            product={product}
                            actived={active === i}  
                            onToggle={() => {
                                if (product.trusted){ 
                                    active === i ? this.setState({active:''}) : this.setState({active:i}) 
                                }
                            }} 
                            onRemoveTrusted={() => {
                                this.setState({loading:!0});
                                onRemoveTrusted(product.device_id,this.handleResponse.bind(this))
                            }}
                        />
                    )} 
                </ul>
            </div>
        )
    }
} 
class RecentDevicesPage extends React.Component {       
    componentWillMount(){       
        this.props.onGetDevices()        
    }
    
    render(){
        const {sync,error,devices,onRemoveTrusted} = this.props;
        return (
            <div className="box-main">
                    <h2 className="rs tit-xoatincay">
                        Các thiết bị đã hoạt động trên tài khoản của bạn trong 30 ngày qua hoặc đang đăng nhập.
                    </h2>                    
                    <Devices 
                        sync={sync} 
                        error={error}
                        devices={devices} 
                        onRemoveTrusted={onRemoveTrusted}
                        
                    />                   
            </div>
        )
    }
}

export default connect((state) => ({
    sync:state.devices.sync,     
    error:state.devices.error,
    devices:state.devices.data        
}),(dispatch) => ({
    onGetDevices: bindActionCreators(getRecentDevices,dispatch),
    onRemoveTrusted:bindActionCreators(removeTrustedDevice,dispatch)
}))(RecentDevicesPage);



// changeTrustedHandle(deviceid){
//     if (!this.requesting && deviceid){
//         const _this = this;
//         this.requesting = !0;
//         this.setState({loading:!0});
//         remove_trusted_device('true',deviceid).subscribe((r) => {
//             const response = r.response;                
//             if (typeof response === 'object'){
//                 if (response.error){
//                     if (response.error.code === 0 && response.error.type === 0){
//                         _this.props.onLogout()
//                     } else {
//                         _this.requesting = !1;
//                         _this.setServerNotification('error',response.error.message)
//                     }                                             
//                 } else if (response.status === 200){
//                     _this.requesting = !1;
//                     _this.props.onRemoveTrustedDevice(deviceid);
//                     _this.setServerNotification('success','Thay đổi thành công!')                        
//                 } else {
//                     _this.requesting = !1;
//                     _this.setServerNotification('error','Lỗi không xác định!')                        
//                 }
//             } else {
//                 _this.requesting = !1;
//                 _this.setServerNotification('error','Lỗi không xác định!')                   
//             }                
//         },() => {              
//             _this.requesting = !1;
//             _this.setServerNotification('error','Mất kết nối tới máy chủ!')                
//         })
//     } else {
//         this.setServerNotification('error','Lỗi không xác định!')
//     }
    
// }