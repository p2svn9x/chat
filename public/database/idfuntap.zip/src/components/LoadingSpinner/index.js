import React from 'react';

const LoadingSpinner = () => (
    <div className="preloading">
      <div className="lds-ring"><div></div><div></div><div></div><div></div></div>
    </div>
)

export default LoadingSpinner;