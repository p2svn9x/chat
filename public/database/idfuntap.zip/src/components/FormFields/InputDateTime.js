import React from 'react';
import moment from 'moment';
import {Option,Select,Col,Row} from 'muicss/react';
import {disableBodyScroll,enableBodyScroll} from 'body-scroll-lock';

const SelectDateTime = ({options,name,value,label,onChange}) => (
    <Col xs="4" md="4">
        <Select onChange={onChange} value={value} label={value ? label : ''} placeholder={!value ? label : ''}>
            {!!options && options.map((opt) => (
                <Option key={`${name}-${opt.value}`} label={opt.label} value={opt.value} />
            ))}
        </Select>
    </Col>
)

function prefixNumberToDate(date){
    if (typeof date !== 'string'){
        date = `${date || ''}`;
    }
    if (date && date.length === 1){
        return `0${date}`
    }
    return date
}

class ModalDateTime extends React.Component {  
    componentWillReceiveProps(nextProps){
        if (nextProps.show !== this.props.show){
            if (nextProps.show){
                document.body.classList.add('modal-scroll-lock');
                disableBodyScroll(document.body)
            } else {
                document.body.classList.remove('modal-scroll-lock');
                enableBodyScroll(document.body)
            }
        }
    }      
    createDays(month,year){
        let daysInMonth = moment(`${month}-${year}`,'MM-YYYY').daysInMonth();    
        if (isNaN(daysInMonth)) daysInMonth = 30;
        let days = [];
        let start = 1;    
        while (start <= daysInMonth){
            let value = prefixNumberToDate(start);
            days.push({value,label:value});
            start++
        }   
        return days
    }
    createMonths(){
        let months = [];
        let start = 1;
        let end = 12;
        while (start <= end){
            let value = prefixNumberToDate(start);
            months.push({value,label:value});
            start++
        }
        return months
    }
    createYears(){
        let years = [];
        let startYears = 1940;
        let endYears = (new Date().getFullYear());
        while (startYears <= endYears){
            years.push({value:startYears,label:startYears});
            startYears++
        }   
        return years
    }
    render(){        
        const {show,values,label,onSetValues,onClose} = this.props;       
        if (show){        
            return (
                <div style={{position:'fixed',left:'0',right:'0',top:'0',bottom:'0',zIndex:'100'}}>
                    <div style={{position:'fixed',background:'#000',opacity:'0.5',left:'0',right:'0',top:'0',bottom:'0',zIndex:'30'}} onClick={onClose}></div>
                    <div className="searchable-modal">
                        <div className="header-searchable">{label}<a className="close" onClick={onClose}>×</a></div>                    
                        <div className="body-searchable">
                            <Row> 
                                <SelectDateTime
                                    name="day"
                                    onChange={(e) => onSetValues({day:e.target.value})}
                                    value={values.day}
                                    label="Ngày"
                                    options={this.createDays(values.month,values.year)}
                                />
                                <SelectDateTime
                                    name="month"
                                    onChange={(e) => onSetValues({month:e.target.value})}
                                    value={values.month}
                                    label="Tháng"
                                    options={this.createMonths()}
                                />
                                <SelectDateTime
                                    name="year"
                                    onChange={(e) => onSetValues({year:e.target.value})}
                                    value={values.year}
                                    label="Năm"
                                    options={this.createYears()}
                                />                                
                            </Row> 
                        </div>
                    </div>
                </div>
            )
        }
        return null
    } 
    
    
}

class InputDateTime extends React.Component {
    state = {
        modal:!1,
        data:{
            day:'',
            month:'',
            year:''
        }
    }
    componentWillMount(){
        this.initValue(this.props.value)
    }
    componentWillReceiveProps(nextProps){
        if (nextProps.value !== this.props.value){
            this.initValue(nextProps.value)
        }        
    }
    initValue(value){
        let initData = this.parseDateToObject(value);
        this.onSetValues(initData)
    }
    parseDateToObject(value){
        const {dateFormat} = this.props;
        const mm = moment(value,dateFormat);
        if (!isNaN(mm.valueOf())){
            return {
                day:`${prefixNumberToDate(mm.get('date'))}`,
                month:`${prefixNumberToDate(mm.get('month')+ 1)}`,
                year:`${mm.get('year') || ''}`
            }            
        } 
        return {
            day:'',
            month:'',
            year:''
        }   
    }
    parseDateToString(data){
        const {dateFormat} = this.props;        
        const mm = moment(`${data.day}/${data.month}/${data.year}`,'DD/MM/YYYY');
        if (!isNaN(mm.valueOf())){
            return mm.format(dateFormat)
        }
        return ''
    }
    onSetValues = (values) => {
        this.setState({
            data:{
                ...this.state.data,
                ...values
            }
        })
    }
    onClose(){
        const {data} = this.state;
        if (data.day || data.month || data.year){
            let newData = Object.assign({},data);
            if(!newData.day) newData.day = '01'; 
            if(!newData.month) newData.month = '01';
            if(!newData.year) newData.year = (new Date()).getFullYear();
            this.onSetValues(newData);
            this.props.onChange(this.parseDateToString(newData))
        }
        this.setState({modal:!1})
    }   
    render(){        
        if (this.props.renderInput){
            const {label,placeholder,initProps,value} = this.props;
            const {data,modal} = this.state; 
            const renderInputProps = {
                ...initProps,
                label,
                placeholder,                
                value,
                onClick:() => {this.setState({modal:!0})}
            }
            return (
                <div className="input-date">
                    {this.props.renderInput(renderInputProps)}
                    <ModalDateTime                        
                        show={modal} 
                        label={label}    
                        values={data}
                        onSetValues={this.onSetValues.bind(this)}
                        onClose={() => this.onClose()}
                    />
                </div>
            )
        }
        return null
    }
}

InputDateTime.defaultProps = {
    initProps:{},
    value:'',
    label:'Label',
    dateFormat:'DD/MM/YYYY',
    onChange:() => {}
}

export default InputDateTime;