 
import React from 'react';
import {Input} from 'muicss/react';
import InputDateTime from './InputDateTime';

export default class InputDateField extends React.Component {
    state={changed:!1}
    componentWillUpdate(nextProps){
        if (nextProps.meta.submitFailed && !this.state.changed){
            this.setChanged()
        }
        if (!nextProps.meta.touched && (nextProps.meta.touched !== this.props.meta.touched)){
            this.setState({changed:!1})
        }
    }   
    setChanged(){
        this.setState({changed:!0})
    }
    render(){
        const {input,label,placeholder,onSetValue} = this.props;
        const {error} = this.props.meta;
        const {changed} = this.state;        
        return (           
            <InputDateTime 
                label={label}
                initProps={{error,changed}}
                placeholder={label || placeholder}
                value={input.value || ''}                
                dateFormat="DD/MM/YYYY"                
                onChange={(value) => {
                    this.setChanged();
                    onSetValue(value)
                }}             
                renderInput={({value,onClick,label,placeholder,error,changed}) => (
                    <div className="input-date">
                        <div className="tt-row">  
                            <Input 
                                value={value}
                                readOnly={!0}
                                onClick={onClick}                                
                                label={value ? label : ''} 
                                placeholder={!value ? (placeholder || label) : ''} 
                            />
                            <p className="rs txt-err">{changed && error ? error : '\u00A0'}</p>
                        </div>
                    </div>
                )}
            />
        )
    }
}

InputDateField.defaultProps = {
    disabled:!1,
    onSetValue: () => {}
}