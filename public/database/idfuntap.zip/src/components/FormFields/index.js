import React from 'react';
//import moment from 'moment';
import {Input,Select,Option} from 'muicss/react';
//import DateTime from 'react-datetime';
import SelectDistrict from './SelectDistrict';
import SelectProvince from './SelectProvince';
import InputDateField from './InputDateField';
//import '../../assets/css/react-datetime.css';
import {formatMoney} from '../../helpers/utils';
import 'moment/locale/vi';
import { isTouchDevice } from '../../helpers/utils';

export {
    SelectDistrict,
    SelectProvince,
    InputDateField
};
export const InputCheckboxField = ({input,label}) => (
    <div className="squaredFour">
        <input type="checkbox" {...input} id="squaredFour" />
        <label htmlFor="squaredFour">{label}</label>
    </div>
)
export class InputField extends React.Component {
    state={changed:!1}
    componentWillUpdate(nextProps){
        if (nextProps.meta.submitFailed && !this.state.changed){
            this.setChanged()
        }
        if (!nextProps.meta.touched && (nextProps.meta.touched !== this.props.meta.touched)){
            this.setState({changed:!1})
        }
    }
    setChanged(){
        this.setState({changed:!0})
    }
    onClear(){           
        this.refs.input.controlEl.focus();     
        this.props.onClear(); 
    }
    render(){        
        const {changed} = this.state;
        const {
            input:{name,value,onFocus,onBlur,onChange},
            type,
            disabled,
            numberOnly,
            placeholder,
            label,            
            onSetValue,
            regex,
            meta:{error,active}
        } = this.props;    
        const isTouch = isTouchDevice();   
        return (
            <div className="tt-row">                  
                <Input 
                    ref="input"
                    name={name}
                    value={value}
                    onBlur={onBlur}
                    onFocus={onFocus}
                    disabled={disabled} 
                    type={type || 'text'}                     
                    label={active || value ? label : ''}       
                    placeholder={!active ? (placeholder || label): ''}   
                    onChange={(e) => {
                        if (!changed) this.setChanged(); 
                        let value = e.target.value;
                        if (e.keyCode === 13){
                            e.target.blur();
                            return !1
                        } 
                        if (regex){                          
                            let reg = new RegExp(regex,'g');                           
                            value = value.replace(reg,'');                          
                            onSetValue(value)
                        } else if (numberOnly){                            
                            if (!!value){
                                value = value.replace(/\D+/g,'')
                            }
                            onSetValue(value)
                        } else {
                            onChange(e)
                        }                        
                    }}
                />
                {active && value && (
                    <a className="icon-clear spr" 
                        onTouchEnd={() => isTouch ? this.onClear() : ''}
                        onMouseDown={() => !isTouch ? this.onClear() : ''}
                        style={{display: 'inline'}} 
                    />                    
                )}
                <p className="rs txt-err" style={{marginTop:'-10px'}}>{changed && error ? error : '\u00A0'}</p>
            </div>
        )
    }
}
InputField.defaultProps = {
    onClear:() => {},
    onSetValue:() => {},
    numberOnly:!1,
    disabled:!1
}

export class InputMoneyField extends React.Component {
    state={changed:!1}
    componentWillUpdate(nextProps){
        if (nextProps.meta.submitFailed && !this.state.changed){
            this.setChanged()
        }
        if (!nextProps.meta.touched && (nextProps.meta.touched !== this.props.meta.touched)){
            this.setState({changed:!1})
        }
    }
    setChanged(){
        this.setState({changed:!0})
    }
    onClear(){
        this.props.onClear();
        this.refs.input.controlEl.focus()
    }
    render(){        
        const {changed} = this.state;
        const {
            input:{name,value,onFocus,onBlur},            
            disabled,            
            placeholder,
            label,           
            onSetValue,
            meta:{error,active}
        } = this.props; 
        const isTouch = isTouchDevice();      
        return (
            <div className="tt-row">        
                <Input 
                    ref="input"
                    name={name}
                    value={value}
                    onBlur={onBlur}
                    onFocus={onFocus}
                    disabled={disabled} 
                    type="tel"                     
                    label={active || value ? label : ''}       
                    placeholder={!active ? (placeholder || label): ''}   
                    onChange={(e) => { 
                        if (!changed) this.setChanged();   
                        if (e.keyCode === 13){
                            e.target.blur();
                            return !1
                        };                    
                        let value = e.target.value;                        
                        if (!!value){
                            value = value.replace(/\D+/g,'');
                            value = formatMoney(value);
                        }
                        onSetValue(value)                                              
                    }}
                />
                {active && value && (
                    <a className="icon-clear spr" 
                        onTouchEnd={ () => isTouch ? this.onClear() : ''} 
                        onMouseDown={() => !isTouch ? this.onClear() : ''} 
                        style={{display: 'inline'}}>
                    </a>
                )}
                <p className="rs txt-err" style={{marginTop:'-10px'}}>{changed && error ? error : '\u00A0'}</p>
            </div>
        )
    }
}
InputMoneyField.defaultProps = {
    disabled:!1,
    onClear:() => {},
    onSetValue:() => {}    
}
 
export class InputPasswordField extends React.Component {
    
    state={
        changed:!1,
        showPassword:!1
    }    
    componentWillUpdate(nextProps){
        if (nextProps.meta.submitFailed && !this.state.changed){
            this.setChanged()
        }
        if (!nextProps.meta.touched && (nextProps.meta.touched !== this.props.meta.touched)){
            this.setState({changed:!1})
        }
    }
    setChanged(){
        this.setState({changed:!0})
    }
    
    render(){        
        const {changed,showPassword} = this.state;
        const {
            input,            
            disabled,            
            placeholder,
            label,   
            meta:{error,active}
        } = this.props;       
        return (
            <div className="tt-row">        
                <Input 
                    ref="input"
                    {...input}                   
                    disabled={disabled} 
                    type={showPassword ? 'text' : 'password'}                     
                    label={active || input.value ? label : ''}       
                    placeholder={!active ? (placeholder || label): ''}  
                    onKeyUp={(e) => {
                        if (!changed) this.setChanged(); 
                        if (e.keyCode === 13) e.target.blur()
                    }}                     
                />
                <a 
                    style={{cursor:'pointer'}}                      
                    onClick={() => {
                        this.setState({showPassword:!showPassword})
                        this.refs.input.controlEl.focus()
                        
                    }} 
                    className={showPassword ? "icon-shp active" : "icon-shp"} 
                />
                <p className="rs txt-err" style={{marginTop:'-10px'}}>{changed && error ? error : '\u00A0'}</p>
            </div>
        )
    }
}
InputPasswordField.defaultProps = {
    disabled:!1
}

export class SelectGender extends React.Component {
    state={
        changed:!1        
    }
    componentWillUpdate(nextProps){
        if (nextProps.meta.submitFailed && !this.state.changed){
            this.setChanged()
        }
        if (!nextProps.meta.touched && (nextProps.meta.touched !== this.props.meta.touched)){
            this.setState({changed:!1})
        }
    }
    setChanged(){
        this.setState({changed:!0})
    }
    render(){
        const {changed} = this.state;
        const {
            input:{name,value,onFocus,onBlur,onChange},            
            disabled,            
            placeholder,
            label,   
            meta:{error}
        } = this.props; 
        return (
            <div className="tt-row">
                <Select  
                    name={name}
                    value={value}
                    onFocus={onFocus}
                    onBlur={onBlur}
                    onChange={(e) => {if(!changed){this.setChanged()} onChange(e)}}
                    disabled={disabled} 
                    label={value ? label : ''} 
                    placeholder={placeholder || label}
                >
                    <Option value="Không Xác Định" label="Không xác định" />
                    <Option value="Nam" label="Nam" />
                    <Option value="Nữ" label="Nữ" />
                </Select>
                <p className="rs txt-err" style={{marginTop:'-10px'}}>{changed && error ? error : '\u00A0'}</p>
            </div>
        )
    }
}
