import React from 'react';
import {connect} from 'react-redux';
import {Select,Option} from 'muicss/react';

class SelectDistrict extends React.Component {
    state={
        changed:!1        
    }
    componentWillUpdate(nextProps){
        if (nextProps.meta.submitFailed && !this.state.changed){
            this.setChanged()
        }
        if (!nextProps.meta.touched && (nextProps.meta.touched !== this.props.meta.touched)){
            this.setState({changed:!1})
        }
    }
    setChanged(){
        this.setState({changed:!0})
    }
    render(){
        const {
            input:{name,value,onFocus,onBlur,onChange},            
            disabled,            
            placeholder,
            label,      
            options,
            meta:{error}
        } = this.props; 
        const {changed} = this.state;
        return (
            <div className="tt-row">
                <Select 
                    name={name}
                    value={value}
                    disabled={disabled}
                    onFocus={onFocus}
                    onBlur={onBlur}
                    onChange={(e) => {
                        if (!changed){
                            this.setChanged()
                        }   
                        onChange(e)
                    }}
                    label={value ? label : ''} 
                    placeholder={placeholder || label}
                >
                    {options.map((district) => (
                        <Option key={district.district_id} value={district.district_name} label={district.district_name} />
                    ))}            
                </Select>
                <p className="rs txt-err" style={{marginTop:'-10px'}}>{changed && error ? error : '\u00A0'}</p>
            </div>
        )
    }
}
export default connect((state,props) => {
    let options= [];
    const data = state.direction.data;    
    if (!!props.provinceName){
        const idx = data.findIndex((province) => props.provinceName === province.province_name);
        if (idx >= 0){
            options = data[idx].districts || []
        }
    }    
    return {
        options
    }
},null)(SelectDistrict);

SelectDistrict.defaultProps = {
    disabled:!1,
    provinceName:''
       
}