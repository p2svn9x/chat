import React from 'react';
import {connect} from 'react-redux';
import Select from 'muicss/lib/react/select';
import Option from 'muicss/lib/react/option';

class SelectProvince extends React.Component {
    state={
        changed:!1        
    }
    componentWillUpdate(nextProps){
        if (nextProps.meta.submitFailed && !this.state.changed){
            this.setChanged()
        }
        if (!nextProps.meta.touched && (nextProps.meta.touched !== this.props.meta.touched)){
            this.setState({changed:!1})
        }
    }
    setChanged(){
        this.setState({changed:!0})
    }
    render(){
        const {
            input:{name,value,onFocus,onBlur,onChange},            
            disabled,            
            placeholder,
            label,            
            options,
            onResetToField,            
            meta:{error}
        } = this.props; 
        const {changed} = this.state;
        return (
            <div className="tt-row">
                <Select 
                    name={name}
                    value={value}
                    disabled={disabled}
                    onFocus={onFocus}
                    onBlur={onBlur}
                    onChange={(e) => {
                        if (!changed){
                            this.setChanged()
                        }                        
                        onResetToField();
                        onChange(e)
                    }}
                    label={value ? label : ''} 
                    placeholder={placeholder || label}
                >
                    {options.map((province) => (
                        <Option 
                            key={`province-${province.provinceId}`} 
                            value={province.provinceName} 
                            label={province.provinceName} 
                        />
                    ))}           
                </Select>
                <p className="rs txt-err" style={{marginTop:'-10px'}}>{changed && error ? error : '\u00A0'}</p>
            </div>
        )
    }
}
SelectProvince.defaultProps = {
    disabled:!1,
    onResetToField:() => {}    
}
export default connect((state) => {
    const data = state.direction.data;
    const options = data.map((province) => ({
        provinceName:province.province_name,
        provinceId:province.province_id
    }))
    return {
        options
    }
},null)(SelectProvince);