import React from 'react';
import {connect} from 'react-redux';
import SetEmailPage from '../SetEmailPage';
import ChangeEmailPage from '../ChangeEmailPage';
import {getUserInfo} from '../../helpers/filters';

const UpdateEmailPage = ({isEmailVerified}) => {
    if (isEmailVerified){
        return (
            <div className="box-main">
                <div className="box-canhan">
                    <ChangeEmailPage />
                </div>
            </div>
        )
    } else {
        return (
            <div className="box-main">
                <div className="box-canhan">
                    <SetEmailPage />
                </div>
            </div>
        )
    }
}

export default connect((state) => {
    const userInfo = getUserInfo(state,'Security')('email_verified','email');
    return {
        isEmailVerified:!!userInfo.email_verified && !!userInfo.email
    }
})(UpdateEmailPage);