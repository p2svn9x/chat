import React from 'react';
import {withRouter} from 'react-router';

class Debugger extends React.Component {
    state = {location:''};
    componentWillMount(){
        this.props.history.listen((location) => {
            this.setState({location:JSON.stringify(location)})
        })
    }
    render(){
        return (
            <div style={{position:'fixed',bottom:0,left:0,width:'100%',zIndex:'9999',backgroundColor:'#fff',lineHeight:'1,3'}}>
                {this.state.location}
            </div>
        )
    }
}

export default withRouter(Debugger);