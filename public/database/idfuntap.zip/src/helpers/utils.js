//import { BROWSER_MODE } from "../constants/browserType";

export function isTouchDevice(){
    var prefixes = ' -webkit- -moz- -o- -ms- '.split(' ');
    var mq = function(query) {
      return window.matchMedia(query).matches;
    }  
    if (('ontouchstart' in window) || (window.DocumentTouch)) {
      return true;
    }  
    // include the 'heartz' as a way to have a non matching MQ to help terminate the join
    // https://git.io/vznFH
    var query = ['(', prefixes.join('touch-enabled),('), 'heartz', ')'].join('');
    return mq(query);
}

export function calcResendTimer(time){
  if (!time) return null;
  if (typeof time === 'string') time = Number(time);
  if (typeof time !== 'number' || isNaN(time)) return null; 
  let timer = Math.floor( (Number(time) + 60000 - Date.now()) /1000 )
  if (timer <= 0) return null;
  return timer
}

export function formatMoney(n,currency){
  if (typeof n === 'string') n = parseFloat(n);
  if (typeof currency !== 'string') currency = '';
  if (typeof n === 'number'){
      return n.toFixed(0).replace(/./g, function(c, i, a) {
          return i > 0 && c !== "," && (a.length - i) % 3 === 0 ? "." + c : c;
      }) + currency;
  }
  return 'NaN'
}

export function matchPath(pathname,patchCompare){
  if (pathname === patchCompare || pathname === `${patchCompare}/`){
      return !0
  }
  return !1
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
export function isTestMode(){
  if (window.Funtap.development === 'testing'){
    return !0
  }
  return !1
}

export function getFuntapConfig(property){
  if (!!window.Funtap && !!window.Funtap[property]){
      return window.Funtap[property]
  }
  return null
}

export function maskEmail(email){
  if (!email || typeof email !=='string') return email;
  let emailParse = email.split('@');
  if (emailParse.length !== 2){
    return email
  }
  let emailHide = '';
  let emailName = emailParse[0];
  let emailDomain = emailParse[1];
  if (emailName.length < 3){
    emailHide = ('*').repeat(emailName.length)
  } else {    
    emailHide = emailName.substr(0,3) + ('*').repeat(Math.min(emailName.length - 3,4))
  }
  emailHide += '@';
  if (emailDomain.length < 5){
    emailHide += emailDomain
  } else {
    let idx = emailDomain.length - 5;
    emailHide += ('*').repeat(Math.min(idx,4));
    emailHide += emailDomain.substr(idx)
  }  
  return emailHide
}

export function maskPhone(phone){
  if (!phone || typeof phone !=='string' || phone.length < 8) return phone;
  let phoneHide = '';  
  phoneHide = phone.substr(0,3);
  phoneHide += ('*').repeat(phone.length - 6);
  phoneHide += phone.substr(phone.length - 3); 
  return phoneHide
}

export function prefixProvince(province,revert){
  let _province = province;    
    if (!!_province && !!_province.match(/Hồ Chí Minh/ig)){
        if (!!revert){
            _province = 'Hồ Chí Minh'
        } else {
            _province = 'TP.Hồ Chí Minh'
        }
    }
    return _province
}