import {decryptBlowfish} from './cryption';

export function getUserInfo(state,fields){
    const fieldsInfo = state.userInfo[fields] || {};  
    if (typeof fields !== 'string'){
        console.error('Fields is Required')
        return null
    }  
    return function(){
        const lng = arguments.length;       
        if (lng === 0){
            return fieldsInfo
        }
        if (lng === 1){
            let property = arguments[0];
            return fieldsInfo[property]
        }
        if (lng > 1){
            let data = {};
            for (let i=0;i<lng;i++){
               let property = arguments[i];           
                if (fieldsInfo[property] === false){
                    data[property] = false
                } else {
                    data[property] = fieldsInfo[property] || null
                }
            }
            return data
        }
    }
}

export function getTmpFromStorage(secretKey){
    let tmp = {};
    try {
        if (!!window.localStorage){             
            let tmpStorage = localStorage.getItem('TMP');           
            if (!!tmpStorage){
                tmp = decryptBlowfish(tmpStorage,secretKey,'json');                     
                if (!tmp){
                    tmp = {};
                    localStorage.removeItem('TMP');
                } 
            }            
        }
    } catch(err){} 
    return tmp    
}
export function getSessionFromStorage(secretKey){
    let session = {};
    try {
        if (!!window.localStorage){             
            let sessionStorage = localStorage.getItem('SESSION');                
            if (!!sessionStorage){
                session = decryptBlowfish(sessionStorage,secretKey,'json'); 
                if (!session){
                    session = {};
                    localStorage.removeItem('SESSION');
                } 
            }          
        }
    } catch(err){} 
    return session    
}