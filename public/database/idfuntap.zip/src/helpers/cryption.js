import {Blowfish} from 'javascript-blowfish';
//import {AES,SHA256,mode,pad,enc} from 'crypto-js';
const bf = (secretKey) => new Blowfish(secretKey || 'dontchangethiswordsdontchangethiswords');
export const encryptBlowfish = (t,secretKey) => {
    const bfs = bf(secretKey);
    let encrypted = bfs.base64Encode(bfs.encrypt(t));
    return encrypted;
}
export const decryptBlowfish = (t,secretKey,format) => {
    if (typeof t !== 'string') return !1;
    try {
        const bfs = bf(secretKey);
        let decrypted = bfs.decrypt(bfs.base64Decode(t));
        decrypted = bfs.trimZeros(decrypted);       
        if (format === 'json'){            
            decrypted = JSON.parse(decrypted);
        } 
        return decrypted
    } catch(err) {
        console.error(err);        
        return !1
    }
}
// var ciphertext = AES.encrypt('my message', 'secret key 123').toString();
// var bytes  = AES.decrypt(ciphertext, 'secret key 123');
// var originalText = bytes.toString(enc.Utf8);
// console.log(originalText); // 'my message'

//const skey = (SHA256('1015e5c5a39a243396e9b0625356a200').toString()).substr(11,41);

// export const encryptAES = (t) => {
//     if (typeof t !== 'string') return !1; 
//     var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
//     try {       
//         return AES.encrypt(t,skey).toString()
//     } catch(err){
//         n < 3 ? encryptAES(t, n + 1) : (console.error("Error encodeAES " + n),null)
//     }    
// }
// export const decryptAES = (e) => {
//     if (typeof e !== 'string') return !1;
//     var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;      
//     try {
//         return AES.decrypt(e,skey).toString(enc.Utf8)    
//     } catch(err){
//         n < 3 ? decryptAES(e, n + 1) : (console.error("Error decodeAES " + n),null)
//     }    
// }


// export const encryptAES = (t) => {
//     if (typeof t !== 'string') return !1; 
//     var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
//     try {       
//         return AES.encrypt(t,skey,{
//             iv: enc.Hex.parse("00000000000000000000000000000000"),
//             mode: mode.CBC,
//             padding: pad.Pkcs7
//         }).toString()
//     } catch(err){
//         n < 3 ? encryptAES(t, n + 1) : (console.error("Error encodeAES " + n),null)
//     }    
// }
// export const decryptAES = (e) => {
//     //  e = enc.Base64.parse(e).toString();
//     //  console.log(e);
//     var json = JSON.parse(enc.Utf8.stringify(enc.Base64.parse(e)));
//     console.log(json);
//     //var salt = enc.Hex.parse(json.salt);
//     var iv = enc.Hex.parse(json.iv);
//     var encrypted = json.ciphertext;// no need to base64 decode.
   
//     //var encryptMethodLength = (this.encryptMethodLength/4);// example: AES number is 256 / 4 = 64
  

//     var decrypted = AES.decrypt(encrypted, skey, {'mode': mode.CBC, 'iv': iv});

//     return decrypted.toString(enc.Utf8);
// }

// export const decryptAES = (e) => {
//     if (typeof e !== 'string') return !1;
//     var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;      
//     try {
//         return AES.decrypt(e,skey,{
//             iv:enc.Hex.parse("00000000000000000000000000000000"),
//             mode:mode.CBC,
//             padding: pad.Pkcs7
//         }).toString(enc.Utf8)    
//     } catch(err){
//         n < 3 ? decryptAES(e, n + 1) : (console.error("Error decodeAES " + n),null)
//     }    
// }