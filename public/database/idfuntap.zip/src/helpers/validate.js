import moment from 'moment';

//validate Username ^(([a-zA-Z])+([a-zA-Z0-9])){6,15}+$
export const validateUsername = (username) => {
    if (!username) return !1;
    let regex = /^[a-zA-Z0-9]+([_.]?[a-zA-Z0-9])*$/g;
    return regex.test(username)
}
export const validatePeopleId = (peopleId) => {
    if (peopleId.length === 8){
        // Ho chieu
        let regex = new RegExp("^([A-Z]{1})+([0-9]{7})$");
        return regex.test(peopleId)
    } else if (peopleId.length === 9){
        //CMND
        let regex = new RegExp("^([0-3]{1})+([0-9]{8})$");
        return regex.test(peopleId)
    } else if (peopleId.length === 12){
        //CCCD
        let regex = new RegExp("^(0)+(([0-9]){2})+([0-3]{1})+([0-9]{2})+([0-9]{6})$");
        return regex.test(peopleId)
    }  
    return !1    
}
export const validateEmail = (email) => {
    var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regex.test(email)
}
export const validatePhoneNumber = (phone) => {
    let regex = /^(01[2689]|0[98753])[0-9]{8}$/g;
    return regex.test(phone)    
}
export const isNumber = (str) => {
    var pattern = /^\d+$/;
    return pattern.test(str);  // returns a boolean
}
export const validateAddress = (address) => {
    if (!address) return !1;
    let regex = /^[a-zA-Z0-9\-\/]{1,8}(?: [a-zA-Z0-9,\-\/]+){0,15}$/gm;
    address = convertTextToLatin(address);    
    address = address.replace(/\s+$/gm,'');
    return regex.test(address)   
}
export const validateProvince = (province) => {
    var regex = /(An Giang|Bà Rịa - Vũng Tàu|Bình Dương|Bình Phước|Bình Thuận|Bình Định|Bạc Liêu|Bắc Giang|Bắc Kạn|Bắc Ninh|Bến Tre|Cao Bằng|Cà Mau|Cần Thơ|Gia Lai|H(òa|oà) Bình|Hà Giang|Hà Nam|Hà Nội|Hà Tĩnh|Hưng Yên|Hải Dương|Hải Phòng|Hậu Giang|Hồ Chí Minh|Khánh Hòa|Kiên Giang|Kon Tum|Lai Châu|Long An|Lào Cai|Lâm Đồng|Lạng Sơn|Nam Định|Nghệ An|Ninh Bình|Ninh Thuận|Phú Thọ|Phú Yên|Quảng Bình|Quảng Nam|Quảng Ngãi|Quảng Ninh|Quảng Trị|Sóc Trăng|Sơn La|Thanh Hóa|Thái Bình|Thái Nguyên|Thừa Thiên Huế|Tiền Giang|Trà Vinh|Tuyên Quang|Tây Ninh|Vĩnh Long|Vĩnh Phúc|Yên Bái|Điện Biên|Đà Nẵng|Đắk Lắk|Đắk Nông|Đồng Nai|Đồng Tháp)$/gi;
    return regex.test(province)
}
export const convertTextToLatin = (str) => {
    if (!str) return ''; 
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/gi, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/gi, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/gi, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/gi, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/gi, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/gi, "y");
    str = str.replace(/đ/gi, "d");
    // Some system encode vietnamese combining accent as individual utf-8 characters
    str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ""); // Huyền sắc hỏi ngã nặng 
    str = str.replace(/\u02C6|\u0306|\u031B/g, ""); // Â, Ê, Ă, Ơ, Ư  
    return str
}
export function convertNewPhoneNumber(phone){    
    if (!!phone.match(/^(012(0|6|8))/gi)){
        // Mobi
        return phone.replace((/^(012)/gi),'07')
    } else if (!!phone.match(/^(0121)/gi)){
        // Mobi
        return phone.replace((/^(0121)/gi),'079')
    } else if (!!phone.match(/^(0122)/gi)) {
        // Mobi
        return phone.replace((/^(0122)/gi),'077')
    } else if (!!phone.match(/^(012(3|4|5))/gi)){
        // Vina
        return phone.replace((/^(012)/gi),'08')
    } else if (!!phone.match(/^(0127)/gi)){
        // Vina
        return phone.replace((/^(0127)/gi),'081')
    } else if (!!phone.match(/^(0129)/gi)) {
        // Vina
        return phone.replace((/^(0129)/gi),'082')
    } else if (!!phone.match(/^(016[2-9])/gi)){
        // Viettel
        return phone.replace((/^(016)/gi),'03')     
    } else if (!!phone.match(/^(018(6|8)|0199)/gi)){
        //Vietnamobile & Gmobile
        return phone.replace((/^(018|019)/gi),'05') 
    } else {
        return phone
    }
}   
export const validateFullname = (fullname) => {
    if (!fullname) return !1; 
    let regex = /^[a-zA-Z]{2,8}(?: [a-zA-Z]+){0,10}$/gm;
    fullname = convertTextToLatin(fullname);   
    fullname = fullname.replace(/\s+$/gm,'');
    return regex.test(fullname)
}
export const validateDatetime = (datetime) => {
    if (datetime){
        let dt = moment(datetime,'DD/MM/YYYY').valueOf();
        if (isNaN( dt ) || ( dt >= Date.now() ) ){
            return !1
        } 
        return !0
    }
    return !1   
}
export const validateUsernameLogin = (username) => {
    let _username = convertTextToLatin(username);
    return validateUsername(_username)
}
export function detectLoginType(str){
    if (validatePhoneNumber(str)){
        //type sdt
        return 'phone'
    } else if (validateUsernameLogin(str)){
        //type username
        return 'username'
    } else if (validateEmail(str)) {
        //type email
        return 'email'
    } else {
        return !1
    }
}
export function errorFromPhoneNumber(phone){
    if (!!phone && phone.length === 11){
        let newPhone = convertNewPhoneNumber(phone);
        return `Theo quy định mới, số điện thoại của quý khách đã được đổi thành <b>${newPhone}</b>. Vui lòng đăng nhập theo số <b>${newPhone}</b>.`
    }
    return !1
}