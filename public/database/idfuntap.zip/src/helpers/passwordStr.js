var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
export default function passwordStr(password){
    if (!password || typeof password !== 'string') return '';
    if (password.match(strongRegex)){
        return '3'
    } else if (password.match(mediumRegex)){
        return '2'
    } else {
        return '1'
    }
}