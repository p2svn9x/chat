import {
    PATH_DASHBOARD,
    PATH_PERSONAL_INFORMATION,     
    PATH_SECURITY_INFORMATION,
    PATH_UPDATE_EMAIL,
    PATH_LOGIN,
    PATH_UPDATE_PHONE,
    PATH_UPDATE_PASSWORD,
    PATH_TWO_STEP_VERIFICATION,
    PATH_REGISTER,
    PATH_FORGOT_PASSWORD,
    PATH_RECENT_DEVICES,
    // PATH_CREATE_DIRECT_PAYMENT,
    // PATH_DIRECT_PAYMENT,
    PATH_RECENT_GAMES,
    PATH_HISTORY_USE_FUNCOIN,
    //PATH_HISTORY_TOPUP,
    PATH_RECENT
} from '../constants/pathname';
export default function set_title(pathname){
    if (pathname.indexOf(PATH_DASHBOARD) === 0){
        if (pathname.indexOf(PATH_PERSONAL_INFORMATION) === 0){
            return 'Thông tin cá nhân'
        } else if (pathname.indexOf(PATH_SECURITY_INFORMATION) === 0){
            return 'Thông tin bảo mật'
        } else if (pathname.indexOf(PATH_UPDATE_EMAIL) === 0){
            return 'Email bảo mật'
        } else if (pathname.indexOf(PATH_UPDATE_PHONE) === 0){
            return 'Số điện thoại bảo mật'
        } else if (pathname.indexOf(PATH_TWO_STEP_VERIFICATION) === 0){
            return 'Bảo mật 2 bước'
        } else if (pathname.indexOf(PATH_UPDATE_PASSWORD) === 0){
            return 'Mật khẩu'
        } else if (pathname.indexOf(PATH_RECENT_DEVICES) === 0){
            return 'Thiết bị đã dùng gần đây'
        } else 
        // if (pathname.indexOf(PATH_CREATE_DIRECT_PAYMENT) === 0){
        //     return 'Gửi yêu cầu'
        // } else if (pathname.indexOf(PATH_DIRECT_PAYMENT) === 0){
        //     return 'Thanh toán trực tiếp'
        // } else 
        if (pathname.indexOf(PATH_RECENT_GAMES) === 0){
            return 'Game đã chơi gần đây'
        } else if (pathname.indexOf(PATH_HISTORY_USE_FUNCOIN) === 0){
            return 'Funcoin'
        } else 
        // if (pathname.indexOf(PATH_HISTORY_TOPUP) === 0) {
        //     return 'Lịch sử nạp'
        // } else 
        if (pathname.indexOf(PATH_RECENT) === 0) {
            return 'Lịch sử đăng nhập'
        } else if (pathname === PATH_DASHBOARD || pathname === `${PATH_DASHBOARD}/`){
            return 'Dashboard'
        } 
        return '404'
    } else if (pathname.indexOf(PATH_LOGIN) === 0){
        return 'Đăng nhập'
    } else if (pathname.indexOf(PATH_REGISTER) === 0){
        return 'Đăng ký'
    } else if (pathname.indexOf(PATH_FORGOT_PASSWORD) === 0){
        return 'Quên mật khẩu'
    } else {
        return '404'
    }              
}