import {
    SET_BROWSER_ID   
} from '../constants/browserType';

const initState = {   
    browserId:null    
}

export default function browser(state=initState,action={}){
    switch(action.type){
        case SET_BROWSER_ID:
        return {
            ...state,
            browserId:action.payload.id
        }        
        default: return state
    }
}