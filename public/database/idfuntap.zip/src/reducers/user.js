import {
  USER_LOGGED,
  CHANGE_USER_PROFILE,
  CHANGE_USER_SECURITY,
  CHANGE_USER_PAYMENT,
  CHANGE_USER_REWARD,
  CHANGE_USER_ACCOUNT,
  GET_USER_INFO,
  GET_USER_CANCELLED,
  USER_LOGOUT,
  CLEAR_USER_INFO, 
  CHANGE_USER_FUNCOIN
} from '../constants/userType';

const initialState = {
    sync:!1
};

export default function userInfo(state=initialState,action={}){
    switch(action.type){        
        case GET_USER_INFO: 
        return {
          ...state,
          sync:!0         
        }
        case GET_USER_CANCELLED:
        return {
          ...state,
          sync:!1          
        }
        case USER_LOGGED:       
        return {
          ...state,
          sync:!1,          
          ...action.payload
        }
        case CHANGE_USER_ACCOUNT:
        return change_account(state,action.data)
        case CHANGE_USER_FUNCOIN:
        return change_funcoin(state,action.data)
        case CHANGE_USER_REWARD:
        return change_reward(state,action.data)
        case CHANGE_USER_PAYMENT:
        return change_payment(state,action.data)
        case CHANGE_USER_PROFILE:
        return change_profile(state,action.data)       
        case CHANGE_USER_SECURITY:
        return change_security(state,action.data)
        case USER_LOGOUT:
        return {
          ...state,
          sync:!0
        }
        case CLEAR_USER_INFO:
        return initialState
        default: return state
    }
}
function change_account(state,data){
  return {
    ...state,
    Account:{
      ...state.Account,
      ...data
    }
  }
}
function change_funcoin(state,data){
  return {
    ...state,
    Funcoin:{
      ...state.Funcoin,
      ...data
    }
  }
}
function change_reward(state,data){
  return {
    ...state,
    Reward:{
      ...state.Reward,
      ...data
    }
  }
}
function change_payment(state,data){
  return {
    ...state,
    Payment:{
      ...state.Payment,
      ...data
    }
  }
}
function change_security(state,data){
  return {
    ...state,
    Security:{
      ...state.Security,
      ...data
    }
  }
}
function change_profile(state,data){
  return {
    ...state,
    Profile:{
      ...state.Profile,
      ...data
    }
  }
}