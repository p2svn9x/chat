import {
    GET_RECENT_DEVICES,
    GET_DEVICES_CANCELLED,
    GET_ERROR_DEVICES,
    MERGE_DATA_DEVICES,        
    RESET_DATA_DEVICES
} from '../constants/devicesType';
const initState = {
    sync:!1,    
    error:{},
    data:[],
    lastedTimeUpdate:null
}
export default function devices(state=initState,action={}){
    switch(action.type){
        case GET_RECENT_DEVICES:
        return {
            ...state,
            sync:!0,
            error:{}
        }
        case GET_DEVICES_CANCELLED:
        return {
            ...state,
            sync:!1
        }
        case GET_ERROR_DEVICES:
        return {
            ...initState,            
            error:action.error
        }        
        case MERGE_DATA_DEVICES:        
        return {
            ...state,
            sync:!1,            
            data:action.payload,
            lastedTimeUpdate:Date.now()
        }
        case RESET_DATA_DEVICES:
        return initState
        default: return state
    }
}