import {
    SYNC_DIRECTION,
    SYNC_ERROR_DIRECTION,
    MERGE_DATA_DIRECTION
} from '../constants/directionType';
const initialState = {
    sync:!1,
    error:{},
    data:[]
};
export default function direction(state=initialState,action={}){
    switch (action.type) {
        case SYNC_DIRECTION:
        return {
            ...state,
            sync:!0,
            error:{}
        }
        case SYNC_ERROR_DIRECTION:
        return {
            ...state,
            sync:!1,
            error:action.error
        }
        case MERGE_DATA_DIRECTION:
        return {
            ...state,
            sync:!1,           
            data:action.data
        }        
        default: return state        
    }
}