import {
    CREATED_CODE_NEW_PHONE,
    CREATED_CODE_OLD_PHONE,
    CREATED_CODE_NEW_EMAIL,
    CREATED_CODE_OLD_EMAIL,    
    REMOVE_CODE_NEW_PHONE,
    REMOVE_CODE_OLD_PHONE,
    REMOVE_CODE_NEW_EMAIL,
    REMOVE_CODE_OLD_EMAIL,
    MERGE_DATA_TEMPORARY,
    MEGRE_USER_TEMPORARY,
    RESET_DATA_TEMPORARY
} from '../constants/temporaryType';
const initState = {
    // createdCodeNewEmail:null,
    // createdCodeOldEmail:null,
    // createdCodeNewPhone:null,
    // createdCodeOldPhone:null,
    // newEmail:null,
    // newPhone:null,
    userId:null,
    oldPhone:null,
    oldEmail:null
};

export default function temporary(state=initState,action={}){
    switch(action.type){
        case CREATED_CODE_NEW_PHONE:
        return {
            ...state,
            createdCodeNewPhone:action.payload.time,
            newPhone:action.payload.phone
        }
        case REMOVE_CODE_NEW_PHONE:
        return {
            ...state,
            createdCodeNewPhone:null,
            newPhone:null            
        }
        case CREATED_CODE_OLD_PHONE:
        return {
            ...state,
            createdCodeOldPhone:action.payload.time
        }
        case REMOVE_CODE_OLD_PHONE:
        return {
            ...state,
            createdCodeOldPhone:null
        }
        case CREATED_CODE_NEW_EMAIL:
        return {
            ...state,
            createdCodeNewEmail:action.payload.time,
            newEmail:action.payload.email
        }
        case REMOVE_CODE_NEW_EMAIL:
        return {
            ...state,
            createdCodeNewEmail:null,
            newEmail:null          
        }
        case CREATED_CODE_OLD_EMAIL:
        return {
            ...state,
            createdCodeOldEmail:action.payload.time
        } 
        case REMOVE_CODE_OLD_EMAIL:
        return {
            ...state,
            createdCodeOldEmail:null
        }
        case MEGRE_USER_TEMPORARY:
        return {
            ...state,
            ...action.payload.data           
        }
        case MERGE_DATA_TEMPORARY:
        return action.payload.data
        case RESET_DATA_TEMPORARY:
        return initState
        default: return state
    }
}