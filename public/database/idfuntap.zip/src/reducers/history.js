import {
    INIT_HISTORY_PAYMENT,
    GET_HISTORY_PAYMENT,
    SYNC_HISTORY_PAYMENT,
    SYNC_ERROR_HISTORY,
    SYNC_HISTORY_CANCELLED,
    MERGE_DATA_HISTORY,
    RESET_DATA_HISTORY   
} from '../constants/historyType';
const initState = {
    // funcoin:{
    //     sync:!1,        
    //     page:0,
    //     data:[],
    //     lastedTimeUpdate:null
    // },
    // topup:{
    //     sync:!1,        
    //     page:0,
    //     data:[],
    //     lastedTimeUpdate:null
    // }
}
export default function history(state=initState,action={}){
    switch(action.type){
        case INIT_HISTORY_PAYMENT:
        return init(state,action.meta.type)        
        case GET_HISTORY_PAYMENT:
        return {
            ...state,
            ...change(state,action.meta.type,{sync:!0,error:{}})          
        }
        case SYNC_HISTORY_PAYMENT:
        return {
            ...state,
            ...change(state,action.meta.type,{
                sync:!0,
                error:{},
                data:action.payload.page === 1 ? [] : state[action.meta.type].data
            })          
        }
        case SYNC_ERROR_HISTORY:
        return {
            ...state,
            ...change(state,action.meta.type,{sync:!1,error:action.error}) 
        }
        case SYNC_HISTORY_CANCELLED:         
        return {
            ...state,
            ...change(state,action.meta.type,{sync:!1})           
        } 
        case MERGE_DATA_HISTORY:
        return {
            ...state,
            ...change(state,action.meta.type,{
                sync:!1,
                page:action.payload.page,
                data:action.payload.data,
                lastedTimeUpdate:Date.now()
            })            
        }
        
        case RESET_DATA_HISTORY:
        return initState
        default: return state
    }
}
function init(state,type){
    if (!state[type]){
        return {
            ...state,
            [type]:{
                sync:!1,        
                page:0,
                data:[],
                lastedTimeUpdate:null
            }
        }
    }
    return state
}
function change(state,type,data){
    return {        
        [type]:{
            ...state[type],
            ...data
        }
    }
}