import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form';
import userInfo from './user';
import direction from './direction';
import session from './session';
import devices from './devices';
import games from './games';
import history from './history';
import temporary from './temporary';
import browser from './browser';

export default combineReducers({    
    userInfo,   
    direction,
    session,   
    devices,    
    games,
    history,
    temporary,
    browser,
    form: formReducer    
});