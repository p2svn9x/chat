import {
    SET_SESSION_PASSWORD,
    REMOVE_SESSION_PASSWORD,
    SET_SESSION_OTP,
    REMOVE_SESSION_OTP,
    RESET_DATA_SESSION    
} from '../constants/sessionType';

const intialState = { 
    lastVerifiedPassword:null,
    lastVerifiedOTP:null
};
export default function session(state=intialState,action={}){
    switch(action.type){
        case SET_SESSION_PASSWORD:
        return {
            ...state,
            lastVerifiedPassword:action.payload
        }        
        case REMOVE_SESSION_PASSWORD:       
        return {
            ...state,
            lastVerifiedPassword:null
        }
        case SET_SESSION_OTP:
        return {
            ...state,
            lastVerifiedOTP:action.payload
        }
        case REMOVE_SESSION_OTP:
        return {
            ...state,
            lastVerifiedOTP:null
        }
        case RESET_DATA_SESSION:
        return intialState
        default: return state
    }
}