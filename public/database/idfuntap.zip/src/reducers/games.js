import {
    GET_GAMES_PLAYED,
    GET_ERROR_GAMES,
    GET_GAMES_CANCELLED,
    MERGE_DATA_GAMES,        
    RESET_DATA_GAMES
} from '../constants/gamesType';
const initState = {
    sync:!1,    
    error:{},
    data:[],
    lastedTimeUpdate:null
}
export default function games(state=initState,action={}){
    switch(action.type){
        case GET_GAMES_PLAYED:
        return {
            ...state,
            sync:!0,
            error:{}
        }
        case GET_GAMES_CANCELLED:
        return {
            ...state,
            sync:!1
        }
        case GET_ERROR_GAMES:
        return {
            ...initState,            
            error:action.error
        }        
        case MERGE_DATA_GAMES:        
        return {
            ...state,
            sync:!1,            
            data:action.payload,
            lastedTimeUpdate:Date.now()
        }
        case RESET_DATA_GAMES:
        return initState
        default: return state
    }
}