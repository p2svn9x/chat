import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';
import {createStore,applyMiddleware } from 'redux';
import {Provider} from 'react-redux';
import { createEpicMiddleware } from 'redux-observable';
import {BrowserRouter} from 'react-router-dom';
import queryString from 'query-string';
import rootReducer from './reducers';
import rootEpic from './epic';
import {getUserInfo} from './actions/user';
//import {syncDirection} from './actions/direction';
import {createBrowserId} from './actions/browser';
import { getFuntapConfig } from './helpers/utils';
//import logger from 'redux-logger';
import './assets/css/mui.min.css';
import './assets/css/style.css';
import './assets/css/cricle-percent.css';
import './assets/css/style.custom.css';


const epicMiddleware = createEpicMiddleware(rootEpic);
const store = createStore(rootReducer,applyMiddleware(epicMiddleware));

// store.subscribe(() => console.log(store.getState()))
window.Funtap = {
    development:'',   
    code:'', 
    paramsUrl:''
};

function dispatchGetUserInfo(token){
    // check user_logged
    if (!!window.user_logged || !!token){          
        store.dispatch(getUserInfo(token))
    }
    return !1
}
function initConfigFuntap(){
    const paramsUrl = queryString.parse(window.location.search) || {};  
    if (!!paramsUrl.user_logged){
        window.Funtap.code = paramsUrl.user_logged;
    } else {
        window.Funtap.paramsUrl = window.location.search
    }
    if (
        paramsUrl.development === 'testing' || 
        window.location.hostname.indexOf('dev') === 0 || 
        window.location.hostname.indexOf('localhost') === 0 ||
        window.location.hostname.indexOf('192') === 0
    ){      
        window.Funtap.development = 'testing';     
    }
}
initConfigFuntap();
store.dispatch(createBrowserId());
if (window.location.hostname.indexOf('localhost') === 0){
    window.user_logged = !0;    
    dispatchGetUserInfo();
} else {
    const code = getFuntapConfig('code');    
    if (code){             
        dispatchGetUserInfo(code);
        window.Funtap.code = '';    
    } else {       
        dispatchGetUserInfo()   
    }
}

ReactDOM.render(
    <BrowserRouter>
    <Provider store={store}><App /></Provider>
    </BrowserRouter>, document.getElementById('root')
);
