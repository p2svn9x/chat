export const FB_APPID = '1654783294738666';
export const FB_APP_VERSION = '2.8';
export const FB_APP_LOCALE = 'vi_VN';