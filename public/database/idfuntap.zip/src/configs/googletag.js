export default function google_tag(title,pathname){
    window.dataLayer = window.dataLayer || [];
    if (title.indexOf('| Funtap') < 0) title += ' | Funtap';
    function gtag(){               
        window.dataLayer.push(arguments)
     }
    gtag('js', new Date());
    gtag('config', 'UA-67897836-66', {
        'page_title' : title,
        'page_path': pathname
    });
}