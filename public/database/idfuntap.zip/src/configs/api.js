//import queryString from 'query-string';
import {ajax} from 'rxjs/observable/dom/ajax';
import {encryptBlowfish} from '../helpers/cryption';

function createParamsUrl(obj){
    const params = Object.keys(obj).reduce((param, key) => {
        if (!!obj[key]){
            param += `&${key}=${obj[key]}`
        }        
        return param
    }, '');   
    if (!!params){
        return `?${params.charAt(0) === '&' ? params.substr(1) : params}`
    }
    return ''
} 
function createFormData(obj){
    if (typeof obj !== 'object') return null;
    return Object.keys(obj).reduce((formData, key) => {
        formData.append(key, obj[key]);
        return formData;
    }, new FormData());
}

//var api_domain = 'https://hotro.funtap.vn';

export const logout = () => 
    ajax({
        method:'GET',  
        url:'/platform/idApi/logout',
        responseType:'json',
        crossDomain:!0 
    })

export const sync_country_add = () =>   
    ajax({
        url:`${window.location.hostname.indexOf('localhost') === 0 ? 'https://funcard.vn' : ''}/FuncardOrderApi/getAllProvinceAndDistrict.json`,
        method:'GET',       
        responseType:'json',
        crossDomain:!0  
    });
export const request_change_profile = (values) =>         
    ajax({
        url:`/platform/ApiFuntapId/updateInfo`,
        method:'POST',  
        body:createFormData(values),     
        responseType:'json',
        crossDomain:!0  
    })
   
export const request_verify_password = (values) => {
    let data = Object.assign({},values);
    data.password = encryptBlowfish(values.password);
    data = createFormData(data);
    return ajax({
        url:`/platform/ApiFuntapId/verifyPass`,
        method:'POST',  
        body:data,     
        responseType:'json',
        crossDomain:!0  
    })
}   
export const set_new_email = (values,type) =>        
    ajax({
        url:`/platform/ApiFuntapId/addNewEmail${createParamsUrl({type})}`,
        method:'POST',  
        body:createFormData(values),     
        responseType:'json',
        crossDomain:!0  
    })
 
export const resendcode_set_new_email = (type,userId) =>     
     ajax({
        url:`/platform/ApiFuntapId/resendEmailAgain${createParamsUrl({type,userId})}`,
        method:'GET', 
        responseType:'json',
        crossDomain:!0  
    })
   
    
export const verify_set_new_email = (values,type) =>      
    ajax({
        url:`/platform/ApiFuntapId/typeCode${createParamsUrl({type})}`,
        method:'POST', 
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0  
    })
   
    
export const login = (values,deviceId) => {    
    let data = Object.assign({},values);
    data.password = encryptBlowfish(values.password);
    data = createFormData(data);
    return ajax({
        url:`/platform/ApiFuntapId/login${createParamsUrl({nyxtvi:deviceId})}`,
        method:'POST',  
        body:data,     
        responseType:'json',
        crossDomain:!0  
    })
} 
export const get_userinfo = (user_logged) =>    
    ajax({
        url:`/platform/ApiFuntapId/userInfo${createParamsUrl({user_logged})}`,
        method:'GET', 
        responseType:'json',
        crossDomain:!0  
    })

export const verify_new_email = () => 
    ajax({
        url:`/platform/ApiFuntapId/verifyEmail`,
        method:'GET', 
        responseType:'json',
        crossDomain:!0  
    })
export const verify_code_phone = (type,userId) =>    
    ajax({
        url:`/platform/ApiFuntapId/getCodeByPhone${createParamsUrl({type,userId})}`,
        method:'GET', 
        responseType:'json',
        crossDomain:!0  
    })

    
export const request_code_phone = (values,type,userId,deviceId) =>    
    ajax({
        url:`/platform/ApiFuntapId/typeCodePhone${createParamsUrl({type,userId,nyxtvi:deviceId})}`,
        method:'POST', 
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0  
    })

export const resend_code_phone = (type,userId) =>      
    ajax({
        url:`/platform/ApiFuntapId/resendSmsAgain${createParamsUrl({type,userId})}`,
        method:'GET',        
        responseType:'json',
        crossDomain:!0  
    })
   
    
export const verify_code_email = (type,userId) =>     
    ajax({
        url:`/platform/ApiFuntapId/getCodeByEmail${createParamsUrl({type,userId})}`,
        method:'GET', 
        responseType:'json',
        crossDomain:!0  
    })

    
export const verify_old_email = (values,type,userId,deviceId) => 
    ajax({
        url:`/platform/ApiFuntapId/typeCodeEmail${createParamsUrl({type,userId,nyxtvi:deviceId})}`,
        method:'POST', 
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0  
    })

export const update_new_email = (values,type) =>     
    ajax({
        url:`/platform/ApiFuntapId/typeEmailToVerify${createParamsUrl({type})}`,
        method:'POST', 
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0  
    })

export const set_new_phone = (values) =>   
    ajax({
        url:`/platform/ApiFuntapId/addNewPhone`,
        method:'POST',  
        body:createFormData(values),     
        responseType:'json',
        crossDomain:!0  
    })

export const verify_set_new_phone = (values,type) =>        
    ajax({
        url:`/platform/ApiFuntapId/phoneVerifyCode${createParamsUrl({type})}`,
        method:'POST', 
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0  
    })
     
export const verify_new_phone = () =>         
    ajax({
        url:`/platform/ApiFuntapId/verifyPhone`,
        method:'GET',
        responseType:'json',
        crossDomain:!0  
    })
    
export const update_new_phone = (values,type) =>       
    ajax({
        url:`/platform/ApiFuntapId/typePhoneToVerify${createParamsUrl({type})}`,
        method:'POST', 
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0  
    })
    
export const update_password = (values,type,userId) => {       
        let data = Object.assign({},values);
        data.password = encryptBlowfish(values.password);
        data.temppassword = encryptBlowfish(values.temppassword);
        data = createFormData(data);        
        return ajax({
            url:`/platform/ApiFuntapId/typeNewPass${createParamsUrl({type,userId})}`,
            method:'POST', 
            body:data,
            responseType:'json',
            crossDomain:!0  
        })
    }
export const toggle_two_step = (type) => (
    ajax({
        url:`/platform/ApiFuntapId/toggleTwoStep?type=${type}`,
        method:'GET',         
        responseType:'json',
        crossDomain:!0  
    })
)

export const login_facebook = (access_token,deviceId) =>     
    ajax({
        url:`/platform/ApiFuntapId/loginFacebook${createParamsUrl({access_token,nyxtvi:deviceId})}`,
        method:'GET',
        responseType:'json',
        crossDomain:!0
    })


export const type_forgot_password = (values) =>    
    ajax({
        url:`/platform/ApiFuntapId/typeForgotPass`,
        method:'POST',
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0
    })


export const verify_method_security = (values,userId) =>    
    ajax({
        url:`/platform/ApiFuntapId/verifyUsername${createParamsUrl({userId})}`,
        method:'POST',
        body:createFormData(values),
        responseType:'json',
        crossDomain:!0
    })


export const validateRegisterAccount = (values) => {
    var data = Object.assign({},values);
        data.password = encryptBlowfish(values.password);        
        data = createFormData(data); 
    return ajax({
        url:`/platform/ApiFuntapId/validateRegister`,
        method:'POST',
        body:data,
        responseType:'json',
        crossDomain:!0
    })    
}

export const registerAccount = (values) => {
    var data = Object.assign({},values);
        data.password = encryptBlowfish(values.password);        
        data = createFormData(data); 
    return ajax({
        url:`/platform/idApi/register`,
        method:'POST',
        body:data,
        responseType:'json',
        crossDomain:!0
    })
}

export const sync_recent_devices = () => (
    ajax({
        url:`/platform/ApiFuntapId/userDevice`,
        method:'GET',       
        responseType:'json',
        crossDomain:!0
    })
)
export const remove_trusted_device = (status,deviceId) =>     
    ajax({
        url:`/platform/ApiFuntapId/userDevice${createParamsUrl({status,nyxtvi:deviceId})}`,
        method:'GET',       
        responseType:'json',
        crossDomain:!0
    })

export const sync_recent_games = () => (
    ajax({
        url:`/platform/ApiFuntapId/userGame`,
        method:'GET',       
        responseType:'json',
        crossDomain:!0
    })
)
export const sync_history_funcoin = (page) =>     
    ajax({
        url:`/platform/ApiFuntapId/historyFunpoints${createParamsUrl({page})}`,
        method:'GET',       
        responseType:'json',
        crossDomain:!0
    })


export const connect_facebook = (access_token) =>     
    ajax({
        url:`/platform/ApiFuntapId/connectFacebook${createParamsUrl({access_token})}`,
        method:'GET',       
        responseType:'json',
        crossDomain:!0
    })


export const sync_history_topup = (page) =>    
    ajax({
        url:`/platform/ApiFuntapId/historyPayments${createParamsUrl({page})}`,
        method:'GET',       
        responseType:'json',
        crossDomain:!0
    })
