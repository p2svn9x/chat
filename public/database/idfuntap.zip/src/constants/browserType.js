export const CREATE_BROWSER_ID = 'BROWSER/CREATE_ID';
export const SET_BROWSER_ID = 'BROWSER/SET_ID';


