import 'rxjs';
import { of } from 'rxjs/observable/of';
import {getEventsPurchase} from '../snippets/api';
//import empty from '../actions/empty';
import { syncErrorPurchase,mergePurchaseEvents,syncCancelPurchase } from '../actions/purchase';
import { userLogout } from '../actions/user';
import {SYNC_PURCHASE_EVENTS,SYNC_CANCEL_PURCHASE} from '../constants/purchaseType';

export const syncPurchaseByGameEpic = (action$,store$) => 
    action$.ofType(SYNC_PURCHASE_EVENTS).mergeMap((action) => {
        const {gameId} = action.payload;
        const data = store$.getState().purchase.data;
        const purchaseEvents = data[gameId];
        if (!purchaseEvents || (!!purchaseEvents.error && purchaseEvents.error.code === 501) ){
            return getEventsPurchase(gameId).map((r) => {
                let newData = Object.assign({},data);
                const response = r.response;
                if (response.code === 1){  
                    const events = response.data.events;
                    if (Array.isArray(events)){
                        newData[gameId] = response.data;
                    } else {
                        newData[gameId] = {events:{error:'Không có sự kiện nào'}};
                    }  
                    return mergePurchaseEvents(newData)
                } else if (response.code === 0 && response.message === 'OAuthException'){
                    return userLogout()
                } else {                    
                    newData[gameId] = {
                        error:{code:501,message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'}
                    }
                    return mergePurchaseEvents(newData)
                }
            })
            .takeUntil(action$.ofType(SYNC_PURCHASE_EVENTS,SYNC_CANCEL_PURCHASE))
            .catch(() => of(syncErrorPurchase({message:'Mất kết nối tới máy chủ, hãy thử lại sau giây lát!'})))
        } else {
            return of(syncCancelPurchase())
        }        
    })