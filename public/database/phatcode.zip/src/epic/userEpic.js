import 'rxjs';
//import { concat } from 'rxjs/observable/concat';
import { of } from 'rxjs/observable/of';
import empty from '../actions/empty';

import { 
    USER_LOGGED,
    USER_LOGOUT,
    SYNC_USER_WALLET,
    MINUS_THOC_USER, 
    MINUS_FUNCOIN_USER 
} from "../constants/userType";
import { syncWallet, userLogout, mergeDataUser } from '../actions/user';
import {getWalletAPI, redirectLogoutAPI} from '../snippets/api';

export const userLoggedEpic = action$ => (
    action$.ofType(USER_LOGGED).mapTo(syncWallet()) 
)
export const userLogoutEpic = action$ => (
    action$.ofType(USER_LOGOUT).map(() => {
        window.location.href = redirectLogoutAPI()
        return empty()
    })
)
export const syncWalletEpic = (action$,store$) => 
    action$.ofType(SYNC_USER_WALLET).mergeMap(() =>
        getWalletAPI()
        .map((r) => {
            const response = r.response; 
            try {
                if (!!response.error){
                    if (response.code === 0){
                        return userLogout()
                    }
                    return empty()
                } else if (response.code === 1 && !!response.data) {
                    const data = store$.getState().userInfo;
                    const newData = {
                        ...data,
                        money:response.data.payment_wallet,
                        funcoin:response.data.funcoin_wallet                        
                    }
                    return mergeDataUser(newData)
                } else {                    
                    return empty()
                }
            } catch(err){
                return empty()
            } 
        })        
        .takeUntil(action$.ofType(SYNC_USER_WALLET))
        .catch(() => of(empty()))
    )

export const minusThocEpic = (action$,store$) =>
    action$.ofType(MINUS_THOC_USER).mergeMap((action) => {
        const data = store$.getState().userInfo;
        const thoc = action.thoc;
        const newData = {
            ...data,
            money:Math.max(0,Number(data.money) - Number(thoc))
        }
        return of(mergeDataUser(newData))
    })
export const minusFuncoinEpic = (action$,store$) =>
    action$.ofType(MINUS_FUNCOIN_USER).mergeMap((action) => {
        const data = store$.getState().userInfo;
        const fc = action.funcoin;        
        const newData = {
            ...data,
            funcoin:Math.max(0,Number(data.funcoin) - Number(fc))
        }
        return of(mergeDataUser(newData))
    })
