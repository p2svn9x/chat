import 'rxjs';
import { of } from 'rxjs/observable/of';
import { SYNC_ACCOUNT_GAME, SYNC_CANCEL_ACCOUNT, SYNC_CHARACTERS_GAME } from '../constants/accountsType';
import { getServerAPI,getCharactersAPI } from '../snippets/api';
import { userLogout } from '../actions/user';
import { syncErrorAccount,mergeDataAccount } from '../actions/accounts';

export const syncAccountGameEpic = (action$,store$) => (
    action$.ofType(SYNC_ACCOUNT_GAME).mergeMap(action => {
        const accounts = store$.getState().accounts.data;
        const {gameId} = action.payload;
        return getServerAPI(gameId)
        .map((r) => {
            const response = r.response;
            let newAccount = Object.assign({},accounts);
            try {
                if (response.code === 1){
                    let lists = response.data.lists;
                    
                    if (!lists || Array.isArray(lists) || Object.keys(lists).length === 0){
                        newAccount[gameId] = {
                            error:{message:'Bạn chưa có tài khoản trong game này!'}
                        }
                    } else {
                        newAccount[gameId] = lists;
                    }
                    return mergeDataAccount(newAccount)
                } else if (response.code === 0){
                    if (response.message === 'OAuthException'){
                        return userLogout()
                    } else {                        
                        newAccount[gameId] = {
                            error:{message:response.message}
                        }
                        return mergeDataAccount(newAccount)
                    }                
                } else {
                    return syncErrorAccount({message:'Đã có lỗi xảy ra, vui lòng thử lại sau giây lát!'})
                }
            } catch(err){
                return syncErrorAccount({message:'Đã có lỗi xảy ra, vui lòng thử lại sau giây lát!!'})
            }            
        })
        .takeUntil(action$.ofType(SYNC_ACCOUNT_GAME,SYNC_CANCEL_ACCOUNT))
        .catch(() => of(syncErrorAccount({code:501,message:'Mất kết nối tới máy chủ!'})))        
    })
)

export const syncCharactersGameEpic = (action$,store$) => (
    action$.ofType(SYNC_CHARACTERS_GAME).do((action) => {        
        const accounts = store$.getState().accounts.data;
        const newAccount = Object.assign({},accounts);
        const {gameId,areaId} = action.payload; 
        newAccount[gameId][areaId].character = null;
        return of(mergeDataAccount(newAccount))
    }).mergeMap((action) => {        
        const accounts = store$.getState().accounts.data;
        const newAccount = Object.assign({},accounts);
        const {gameId,areaId} = action.payload; 
        return getCharactersAPI(gameId,areaId)
        .map((r) => {
            const response = r.response;
            if (!!response.error){
                if (response.error.code === 0 && response.error.type === 0){
                    return userLogout()
                } else if (response.error.code === 5 && response.error.type === 2){
                    newAccount[gameId][areaId].character = {error:{message:'Không tìm thấy nhân vật nào!'}}
                    return mergeDataAccount(newAccount)
                } else {
                    newAccount[gameId][areaId].character = {error:response.error}
                    return mergeDataAccount(newAccount)
                }
            } else if (response.status === 200){
                let {data} = response;                
                if (!data || Array.isArray(data) || Object.keys(data).length === 0){
                    newAccount[gameId][areaId].character = {error:{message:'Không tìm thấy nhân vật nào!'}}
                } else {
                    newAccount[gameId][areaId].character = data;
                }
                return mergeDataAccount(newAccount)
            } else {
                newAccount[gameId][areaId].character = {error:{code:501,message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'}}
                return mergeDataAccount(newAccount)
            }
        })
        .takeUntil(action$.ofType(SYNC_ACCOUNT_GAME,SYNC_CHARACTERS_GAME))
        .catch(() => {            
            newAccount[gameId][areaId].character = {
                error:{code:501,message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'}
            }
            return of(mergeDataAccount(newAccount))
        })        
    })
)