import 'rxjs';
import { of } from 'rxjs/observable/of';
import {getEvents} from '../snippets/api';
//import empty from '../actions/empty';
import { syncEventError,mergeDataEvents,cancelSyncEvents, syncEventsByGame } from '../actions/events';
import { userLogout } from '../actions/user';
import {SYNC_EVENTS,CANCEL_SYNC_EVENTS} from '../constants/eventsType';

export const syncEventsByGameEpic = (action$,store$) => 
    action$.ofType(SYNC_EVENTS).mergeMap((action) => {
        const {gameId} = action.payload;
        const {resync} = action.meta;
        const data = store$.getState().events.data; 
        const gameEvents = data[gameId];    
        if (resync){
            let newData = Object.assign({},data);
            if (!!newData[gameId]){
                delete newData[gameId]
            }
            return of(
                mergeDataEvents(newData),
                syncEventsByGame(gameId)
            )
        }     
        if (!gameEvents || (!!gameEvents.error && gameEvents.error.code === 501)){         
            return getEvents(gameId).map((r) => {
                let newData = Object.assign({},data);
                const response = r.response;
                if (response.code === 1){                    
                    newData[gameId] = response.data;                    
                    return mergeDataEvents(newData)
                } else if (response.code === 0 && response.message === 'OAuthException'){
                    return userLogout()
                } else {                    
                    newData[gameId] = {
                        error:{code:501,message:'Đã có lỗi xảy ra, vui lòng thử lại sau!'}
                    }
                    return mergeDataEvents(newData)
                }
            })
            .takeUntil(action$.ofType(SYNC_EVENTS,CANCEL_SYNC_EVENTS))
            .catch(() => of(syncEventError({message:'Mất kết nối tới máy chủ, hãy thử lại sau giây lát!'})))
        } else {
            return of(cancelSyncEvents())
        }        
    })
