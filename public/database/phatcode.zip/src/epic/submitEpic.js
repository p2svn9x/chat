import 'rxjs';
import { of } from 'rxjs/observable/of';
import {submitGC,submitConnectFB} from '../snippets/api'; 
import { SUBMIT_CONNECT_FACEBOOK, SUBMIT_GIFTCODE, SUBMIT_CANCEL } from '../constants/submitType';
import empty from '../actions/empty';
import {userLogout} from '../actions/user';

export const submitConnectFbEpic = (action$,store$) =>
    action$.ofType(SUBMIT_CONNECT_FACEBOOK).mergeMap((action) => {
        let submitFromParamsUrl = !1;
        let {cuser,gameId} = action.payload;
        const {callback} = action.meta;
        const gameEvents = store$.getState().events.data[gameId];  
        if (cuser.indexOf('CNPARAMS') === 0){ 
            submitFromParamsUrl = !0;           
            cuser = cuser.replace('CNPARAMS','')
        }        
        if ((!!gameEvents && !gameEvents.sender_id) || submitFromParamsUrl){            
            return submitConnectFB({cuser,game_id:gameId})
            .map((r) => {
                const response = r.response;                
                try {
                    if (response.code === 1){
                        callback({message:'Nối thành công!'})
                    } else if (response.code === 0 && response.message === 'OAuthException'){
                        callback({error:'Hết phiên đăng nhập!'})
                        return userLogout()
                    } else {
                        callback({error:response.message})
                    }
                    return empty()
                } catch(err){
                    callback({error:'Đã có lỗi xảy ra!'})
                    return empty()
                }
            })
            .catch(() => {             
                callback({error:'Mất kết nối tới máy chủ!'});
                return of(empty())
            })
            .takeUntil(action$.ofType(SUBMIT_CONNECT_FACEBOOK,SUBMIT_CANCEL))
        } else {
            callback({error:'Đã có lỗi xảy ra!!'})
            return of(empty())
        }        
    })

export const submitGiftcodeEpic = action$ => 
    action$.ofType(SUBMIT_GIFTCODE).mergeMap((action) => {
        const {payload} = action;
        const {callback} = action.meta;
        return submitGC(payload)
        .map((r) => {
            const response = r.response;
            try {
                if (response.code === 1 && !!response.data){
                    if (response.data.code === 200){
                        callback({message:'Nhận giftcode thành công!'})
                    } else {
                        callback({error:response.data.message,code:1})
                    }                    
                } else if (response.code === 0 && response.message === 'OAuthException'){
                    callback({error:'Hết phiên đăng nhập'});
                    return userLogout()
                } else {
                    callback({error:response.data ? response.data.message : (response.message || 'Đã có lỗi xảy ra!')})
                }
                return empty()
            } catch(err){
                callback({error:'Đã có lỗi xảy ra!!'})
                return empty()
            }            
        })
        .catch(() => {
            callback({error:'Mất kết nối tới máy chủ!'})
            return of(empty())
        })
        .takeUntil(action$.ofType(SUBMIT_GIFTCODE,SUBMIT_CANCEL))
    })