import 'rxjs';
import { of } from 'rxjs/observable/of';
import {getGiftcode,getPurchaseGiftcode} from '../snippets/api'; 
import { GET_GIFTCODE_EVENT, GET_GIFTCODE_PURCHASE } from '../constants/giftcodeType';
import { mergeDataEvents } from '../actions/events';
import { mergePurchaseEvents } from '../actions/purchase';
import empty from '../actions/empty';
import {userLogout} from '../actions/user';

function mergeDataGameEvents(data,eventId,mergeData){
    let newDataEvents = Object.assign({},data);                           
    let idx = newDataEvents.events.findIndex((event) => event.id === eventId);  
    if (idx >= 0){
        newDataEvents.events[idx] = {
            ...newDataEvents.events[idx],
            ...mergeData
        }
    } 
    return newDataEvents
}

export const getGiftcodeEventEpic = (action$,store$) => 
    action$.ofType(GET_GIFTCODE_EVENT).mergeMap((action) => {
        const {eventId,gameId} = action.payload;
        let {callback} = action.meta; 
        if (!gameId){
            callback({error:'Đã có lỗi xảy ra!'})
            return of(empty())
        }
        const data = store$.getState().events.data;
        const gameEvents = data[gameId];        
        if (!!gameEvents && !!gameEvents.sender_id){
            return getGiftcode(eventId,gameEvents.sender_id).map((r) => {
                const response = r.response;
                try {
                    if (response.code === 1){
                        let newData = Object.assign({},data);
                        if (!!response.data.giftcode){                                                          
                            newData[gameId] = mergeDataGameEvents(gameEvents,eventId,{giftcode:response.data.giftcode,status:2})
                        } else {                                                       
                            newData[gameId] = mergeDataGameEvents(gameEvents,eventId,{message:response.message,status:3})
                        }
                        return mergeDataEvents(newData)
                    } else if (response.code === 0 && response.message === 'OAuthException'){
                        callback({error:'Hết phiên đăng nhập'});
                        return userLogout()
                    } else {
                        callback({error:response.message})
                        return empty()
                    }
                } catch(err){
                    callback({error:'Đã có lỗi xảy ra!'})
                    return empty()
                }                
            })            
            .catch(() => {
                callback({error:'Mất kết nối tới máy chủ!'})
                return of(empty())
            })
        } else {
            callback({error:'Đã có lỗi xảy ra!!!'})
            return of(empty())
        }
    })

export const getGiftcodePurchaseEpic = (action$,store$) => 
    action$.ofType(GET_GIFTCODE_PURCHASE).mergeMap((action) => {
        const {eventId,gameId} = action.payload;
        let {callback} = action.meta; 
        if (!gameId || !eventId){
            callback({error:'Đã có lỗi xảy ra!'})
            return of(empty())
        }
        const data = store$.getState().purchase.data;
        const gameEvents = data[gameId];
        if (!!gameEvents){
            return getPurchaseGiftcode(eventId).map((r) => {
                const response = r.response;
                try {
                    if (response.code === 1){
                        let newData = Object.assign({},data);
                        if (!!response.data.giftcode){      
                            callback({message:'success'});                                                    
                            newData[gameId] = mergeDataGameEvents(gameEvents,eventId,{giftcode:response.data.giftcode,status:2})
                            return mergePurchaseEvents(newData)
                        } else {                                                       
                            newData[gameId] = mergeDataGameEvents(gameEvents,eventId,{message:response.message,status:3});
                            return mergePurchaseEvents(newData)
                        }                        
                    } else if (response.code === 0 && response.message === 'OAuthException'){
                        callback({error:'Hết phiên đăng nhập'});
                        return userLogout()
                    } else {
                        callback({error:response.message})
                        return empty()
                    }
                } catch(err){
                    callback({error:'Đã có lỗi xảy ra!'})
                    return empty()
                }                
            })            
            .catch(() => {
                callback({error:'Mất kết nối tới máy chủ!'})
                return of(empty())
            })
        } else {
            callback({error:'Đã có lỗi xảy ra!!!'})
            return of(empty())
        }
    })