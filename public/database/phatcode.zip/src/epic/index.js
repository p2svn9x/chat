import { combineEpics } from 'redux-observable';
import {
    userLoggedEpic,
    userLogoutEpic,
    syncWalletEpic,
    minusThocEpic,
    minusFuncoinEpic
} from './userEpic';
import {syncEventsByGameEpic} from './eventsEpic';
import {syncPurchaseByGameEpic} from './purchaseEpic';
import {getGiftcodeEventEpic,getGiftcodePurchaseEpic} from './requestEpic';
import {submitConnectFbEpic,submitGiftcodeEpic} from './submitEpic';
import {syncAccountGameEpic,syncCharactersGameEpic} from './accountsEpic';
const rootEpic = combineEpics(
    userLoggedEpic,
    userLogoutEpic,
    syncWalletEpic,
    minusThocEpic,
    minusFuncoinEpic,
    syncEventsByGameEpic,
    syncPurchaseByGameEpic,
    getGiftcodeEventEpic,
    getGiftcodePurchaseEpic,
    syncAccountGameEpic,
    syncCharactersGameEpic,
    submitConnectFbEpic,
    submitGiftcodeEpic
);
export default rootEpic;