export const HOME_TITLE = 'Nhận & đổi giftcode';
export const GUIDE_TITLE = 'Hướng dẫn nhập code';
export const GAME_TITLE = 'GAME_TITLE';
export const SUBMIT_CODE_TITLE = 'Chọn thông tin nhân vật';