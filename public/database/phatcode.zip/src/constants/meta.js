export const homePageMeta = {
    title:'Nhận & Đổi Giftcode | Funtap',
    description:'Nhận Giftcode - Funtap'
}
export const selectAccountGamePage = {
    title:'Chọn thông tin nhân vật | Funtap',
    description:'Nhận Giftcode - Funtap'
}
export const successPageMeta = {
    title:'Đổi giftcode thành công | Funtap',
    description:'Đổi giftcode thành công'
}
export const notFoundPageMeta = {
    title:'404 | Funtap',
    description:'404'
}
export const createMetaPage = (title,description) => ({
    title:`${title} | Funtap`,
    description:description || title
})