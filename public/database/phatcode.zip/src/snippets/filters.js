import queryString from 'query-string';

export function getCuserFromParamsUrl(paramsUrl){
    if (!paramsUrl) return '';
    const params = queryString.parse(paramsUrl) || {};   
    return params.cuser || ''    
}

export function getGameInfo(alias,games){
    if (!!alias){
        let idx = games.findIndex((game) => game.alias === alias);
        if (idx >= 0){
            return games[idx]
        }
        return null
    }
    return null     
}
export function getGameId(alias,games){
    const gameInfo = getGameInfo(alias,games);
    if (!!gameInfo && !gameInfo.isMaintain){
        return gameInfo.id
    }
    return null    
}

const handleGetGameEvents = (state,gameId) => {    
    const data = state.events.data[gameId] || {};
    return {
        sync:state.events.sync,
        error:state.events.error,
        lastUpdated:state.events.lastUpdated,
        events:data.events || null,
        sender_id:data.sender_id || null   
    } 
}

export function getGameEvents(state,gameId){   
    return handleGetGameEvents(state,gameId)                
}

export function getPropertyGameEvents(state,gameId){
    const gameEvents = handleGetGameEvents(state,gameId);
    return function(property){
        if (!!property){
            return gameEvents[property] || null
        } else {
            return null
        }
    }
}
export function getGameSenderId(state,gameId){
    const gameEvents = state.events.data[gameId];
    if (!!gameEvents){
        return gameEvents.sender_id || ''
    }
    return null
}

export function getGameEventsFilter(state,gameId){    
    const gameEvents = handleGetGameEvents(state,gameId);
    if (!gameEvents.events) return gameEvents;
    return Object.assign({},gameEvents,{
        events:gameEvents.events.filter((event) => Number(event.status) === 1)
    })               
}

export function getDataPurchase(state,gameId){
    const data = state.purchase.data[gameId] || {};
    return {
        sync:state.purchase.sync,
        error:state.purchase.error,
        lastUpdated:state.purchase.lastUpdated,
        events:data.events || null          
    } 
   
}