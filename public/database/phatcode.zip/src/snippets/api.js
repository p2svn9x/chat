import { ajax } from 'rxjs/observable/dom/ajax';
const getFormData = object => Object.keys(object).reduce((formData, key) => {
    formData.append(key, object[key]);
  return formData;
}, new FormData());
const getParamsData = object => Object.keys(object).reduce((params, key) => {
    if (!!object[key]){
        params += `${!!params ? '&' : '?'}${key}=${object[key]}`;
    }    
    return params
},'');

export const getSession = (code) => 
    ajax.get(`/Oauth/reveicev1?code=${code}`)

export const getEvents = (gameid) => 
    ajax.get(`/api/getEvents?game_id=${gameid}`)

export const getServerAPI = (gameid) => 
     ajax.get(`/api/getGameInfo?game_id=${gameid}`)

export const getCharactersAPI = (gameid,serverid) => 
    ajax.get(`/WebPayApi/getCharacter.json?game_id=${gameid}&server=${serverid}`)

export const getGiftcode = (eventid,senderid) => 
    ajax.get(`/api/getGiftcode?event_id=${eventid}&sender_id=${senderid}`)

export const getPurchaseGiftcode = (eventid) => 
    ajax.get(`/GiftcodeFuncoin/eventBuyGiftcode?event_id=${eventid}`)

export const submitGC = (data) => {
    var formdata = getFormData(data);    
    return ajax.post('/api/redeemGiftcode', formdata)
}
export const submitConnectFB = (data) => {
    var formdata = getFormData(data);    
    return ajax.post('/api/reactivejs/react_confirm_user_getcode', formdata)
}
export const getArticle = () => 
    ajax.get('/api/getGuideArticle')

export const getEventsPurchase = (gameid) => 
    ajax.get(`/GiftcodeFuncoin/getGiftcode?game_id=${gameid}`)

export const getWalletAPI = () => 
    ajax.get(`/GiftcodeFuncoin/getUserPayment`)

export const redirectLoginAPI = (params) => {   
    return `https://id.funtap.vn/login${getParamsData(params)}`
}
export const redirectLogoutAPI = () => {
    return `https://id.funtap.vn/oauth/logout?next=https://${window.location.hostname}/users/logout`
}
const GAMEID = (window.location.hostname.indexOf('dev') === 0) ? '512' : '410';
export const getUserFromIdPageAPI = `https://id.funtap.vn/users/requestLogin.json?gameId=${GAMEID}`;
