export function formatTimeEvent(time){
    if (typeof time !== 'number') return '';
    const date = new Date(time * 1000);
    return `${date.getHours() === 0 ? date.getHours() +'0' : date.getHours()}:${date.getMinutes() === 0 ? date.getMinutes() +'0' : date.getMinutes()} ngày ${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`
}

export function formatMoney(money,currency){
    if (typeof money === 'string') money = parseFloat(money);
    if (typeof currency !== 'string') currency = '';
    if (typeof money === 'number'){
        return money.toFixed(0).replace(/./g, function(c, i, a) {
            return i > 0 && c !== "," && (a.length - i) % 3 === 0 ? "." + c : c;
        }) + currency;
    }
    return 'NaN'
}