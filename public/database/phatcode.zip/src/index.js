import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import {createStore,applyMiddleware} from 'redux';
import {createEpicMiddleware} from 'redux-observable';
import queryString from 'query-string';
import rootEpic from './epic';
import {Provider} from 'react-redux';
import {BrowserRouter} from 'react-router-dom';
import RootReducer from './reducers';
import {getGamesInfo} from './actions/games';
import jsonp from 'jsonp';
import {getSession,getUserFromIdPageAPI} from './snippets/api';
import {userLogged,cancelSyncUserInfo,syncUserInfo} from './actions/user';
import './assets/css/mui.min.css';
import './assets/css/style.css';
import './assets/css/style.custom.css';

import {user,list_games} from './fakedata';
 if (window.location.hostname.indexOf('localhost') === 0){  
   window.LISTGAMES = list_games;
   window.DATAUSER = user;
 }
function initFuntapConfig(){
  window.Funtap = {};
  const params = queryString.parse(window.location.search) || {};  
  if (
    params.development === 'testing' || 
    window.location.hostname.indexOf('dev') === 0 || 
    window.location.hostname.indexOf('192') === 0 ||
    window.location.hostname.indexOf('localhost') === 0){
    window.Funtap.development = 'testing'
  }    
}
initFuntapConfig();
//import registerServiceWorker from './registerServiceWorker';
const epicMiddleware = createEpicMiddleware(rootEpic);
const store = createStore(RootReducer,applyMiddleware(epicMiddleware));
//store.subscribe(() => console.log(store.getState()))

function cancelSyncUser(){
  store.dispatch(cancelSyncUserInfo())
}
if (!!window.LISTGAMES && window.LISTGAMES.length > 0){ 
    store.dispatch(getGamesInfo(window.LISTGAMES));   
    window.LISTGAMES = null 
} 
if (!!window.DATAUSER && window.DATAUSER.id){
    store.dispatch(userLogged(window.DATAUSER)); 
    window.DATAUSER = null       
  } else {     
    store.dispatch(syncUserInfo());
    jsonp(getUserFromIdPageAPI, null, function (err, response) {
      if (err) {
        console.error(err.message);    
        cancelSyncUser()    
      } else {                    
        if (!!response.code){
          getSession(response.code).subscribe((data) => {
            const response = data.response;
            if (!!response.User && !!response.User.id){
              store.dispatch(userLogged(response.User))                              
            } else {
              cancelSyncUser()
            }
          },(err) => {
            console.error(err);
            cancelSyncUser()
          })
        } else {
          cancelSyncUser()
        }
      }
    })      
  }

ReactDOM.render(
    <BrowserRouter>
      <Provider store={store}>
      <App /></Provider>
    </BrowserRouter>, document.getElementById('root')
);

//registerServiceWorker();