const user = {
    "username": "dkvn94",
    "name": "Vương D Long",
    "role": "User",
    "email": "dkvn94@yahoo.com.vn",
    "id": "5077697",
    "facebook_uid": "1790399331243670",
    "active": true,
    "avatar": "https://graph.facebook.com/1790399331243670/picture?type=large",
    "created": "2016-08-10 15:17:59",
    "vip": "Default",
    "check_profile": false
}
const list_games = [
    {"id":"378","alias":"tam-quoc-truyen-ky-mobile","title":"Tam Quốc Truyền Kỳ Mobile","icon":"https://cdn.smobgame.com/5a549291c5db9outbound200x200.png","is_new":!0,"isRedeem":!0},
    {"id":"439","alias":"co-kiem-truyen-ky","title":"Cổ Kiếm Truyền Kỳ","icon":"https://cdn.smobgame.com/5a3ccd6d7d306outbound200x200.png","is_new":true},
    {"id":"428","alias":"digi-dai-chien","title":"Digi Đại Chiến","icon":"https://cdn.smobgame.com/5a4d90620fc5coutbound200x200.png","is_new":true},
    {"id":"420","alias":"dau-truong-haki","title":"Đấu Trường Haki","icon":"https://cdn.smobgame.com/5a4f013ce4a83outbound200x200.png","is_new":true},
    {"id":"443","alias":"ngao-kiem-ky-duyen","title":"Ngạo Kiếm Kỳ Duyên","icon":"https://cdn.smobgame.com/5a602c2b84d16outbound200x200.png","is_new":true},
    {"id":"462","alias":"tho-san-linh-hon","title":"Thợ Săn Linh Hồn","icon":"https://cdn.smobgame.com/5a65a9e200473outbound200x200.png","is_new":false},
    {"id":"301","alias":"kiem-vuong-chi-mong","title":"Kiếm Vương Chi Mộng","icon":"https://cdn.smobgame.com/590fe808072a3outbound200x200.png","is_new":false},
    {"id":"299","alias":"tam-quoc-go","title":"Tam Quốc Go","icon":"https://cdn.smobgame.com/59bba9053985foutbound200x200.png","is_new":false},
    {"id":"271","alias":"xich-bich-3d","title":"Xích Bích 3D","icon":"https://cdn.smobgame.com/59b36d661d1d8outbound200x200.png","is_new":false},
    {"id":"236","alias":"haki-ba-vuong","title":"Haki Bá Vương","icon":"https://cdn.smobgame.com/588029b5d05bboutbound200x200.png","is_new":false},
    {"id":"466","alias":"vua-chien-ham","title":"Vua Thủy Chiến","icon":"https://cdn.smobgame.com/5a62d4fbac55doutbound200x200.png","is_new":false},
    {"id":"71","alias":"vua-tam-quoc","title":"Vua Tam Quốc","icon":"https://cdn.smobgame.com/58943dcd65990outbound200x200.png","is_new":false},
    {"id":"233","alias":"sieu-manga-2017","title":"Siêu Manga 2017","icon":"https://cdn.smobgame.com/58db5ebf9ccffoutbound200x200.png","is_new":false}
    ];
export {
    user,
    list_games
}