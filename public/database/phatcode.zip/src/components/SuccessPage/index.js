import React from 'react';
import {compose} from 'redux';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import img_done from '../../assets/images/ico-done.png';
import withGame from '../withGame';
import withAccountInGame from '../withAccountInGame';
import Helmets from '../Helmets';
import { successPageMeta } from '../../constants/meta';

const LineResult = ({label,value}) => {
    if (!!value){
        return (
            <p><span className="txt-tb-l">{label}</span>: <span className="txt-tb-r">{value}</span> </p>
        )        
    }
    return null
} 
const Button = ({classColor,to,label}) => (
    <Link className={`mui-btn ${classColor ? classColor : 'f-btn-gray'} mui-btn--raised`} to={to}>{label}</Link>
)

const SuccessPage = ({gameInfo,accountInfo,email}) => (
    <div style={{height:'100%'}}>  
        <Helmets meta={successPageMeta} />             
        <div id="content-wrapper">                   
            <div className="box-main">
                <div className="box-thongbao">
                    <img src={img_done} width="80" href="80" alt="Thành công" />
                    <h2>Đổi quà thành công</h2>
                    <LineResult label="Game" value={gameInfo.title} />
                    <LineResult label="Server" value={accountInfo.areaName} />
                    <LineResult label={gameInfo.alias === 'vua-chien-ham' ? 'ID' : 'Tên nhân vật'} value={accountInfo.roleName} />
                    <LineResult label="Email" value={gameInfo.alias === 'vua-chien-ham' ? email : ''} />
                    <div className="box-tb-btn">
                        <Button to={{pathname:`/${gameInfo.alias}`}} label="Trang chủ" />
                        <Button classColor="f-btn-orage" to={{pathname:`/${gameInfo.alias}/nhapcode`}} label="Đổi tiếp" />                                
                    </div>
                    <p className="txt-tb-ok">
                        Mời bạn vào game nhận quà tặng
                    </p>
                </div>
            </div>
        </div>
    </div>
)    

export default compose(
    withGame,
    withAccountInGame,
    connect((state) => ({
        email:state.userInfo.email
    }),null)
)(SuccessPage);
 
