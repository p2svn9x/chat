import React from 'react';
import {connect} from 'react-redux';

const HeaderGameDetail = ({gameIcon,gameTitle,username}) => (
    <div className="box-hgame box-hgame-thanhtoan">
        <img src={gameIcon} width="60" height="60" className="box-hgame-thumb" />
        <div className="mui--text-subhead">{gameTitle}</div>
        <div className="box-text-hgame">
            <span className="txt-hgame-dt">Tên đăng nhập</span>:
            <span className="txt-hgame-cc">{username}</span>
        </div>
    </div>
)

export default connect((state) => ({
    username:state.userInfo.username || ''
}),null)(HeaderGameDetail);