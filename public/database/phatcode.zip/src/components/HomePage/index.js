import React from 'react';
import {Link} from 'react-router-dom';
import {Container,Row,Col} from 'muicss/react';
import {connect} from 'react-redux';
import img_preload from '../../assets/dot.png';
import ErrorBlock from '../ErrorBlock';
import Helmets from '../Helmets';
import { homePageMeta } from '../../constants/meta';

const Games = ({games}) => {
    if (!games || games.length === 0){
        return <ErrorBlock message="Opps, Đã có lỗi xảy ra!" /> 
    }
    return (
        <div>
            <div className="f-title-main" style={{margin:'0 -15px'}}>Chọn game</div>
            <Row className="f-lstGame">
                {games.map((game) => (
                    <Col xs="6" sm="4" md="3" key={game.id}>
                        <Link to={`/${game.alias}`} className={`f-gameCt ripple ${game.is_new ? 'f-gameCt-new' : ''}`}>
                            <img 
                                src={img_preload} 
                                style={{background: `url('${game.icon}') no-repeat center`}} 
                                className="f-thumb" 
                                alt={game.title} 
                            />
                            <span className="f-name">{game.title}</span>
                        </Link>
                    </Col>
                ))}
            </Row> 
        </div>
    )
}
const HomePage = ({games}) => (
    <div style={{height:'100%'}}>                
        <div id="content-wrapper">                  
            <Helmets meta={homePageMeta} />
            <div className="box-main"> 
                <Container fluid={!0}>                            
                    <Games games={games} />                                                    
                </Container>
            </div>
        </div>
    </div>
)    

export default connect(
    (state) => ({games:state.games}),null
)(HomePage);