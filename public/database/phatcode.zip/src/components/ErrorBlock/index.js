
import React from 'react';

class ErrorBlock extends React.Component {
    constructor(){
        super();
        this.calcHeight = this.calcHeight.bind(this)
    }
    state = {
        height:'100px'
    }
    componentWillMount(){
        this.calcHeight();
        window.addEventListener('resize',this.calcHeight)
    }
    componentWillUnmount(){
        window.removeEventListener('resize',this.calcHeight)
    }
    calcHeight = () => {
        this.setState({height:window.innerHeight - 112})        
    }
    render(){
        const {message} = this.props;
        const {height} = this.state;
        return (
            <div style={{height:'100%'}}>                    
                <div id="content-wrapper">            
                    <div className="box-fullh" style={{height}}>
                        <div className="box-fullh-center">                               
                            <div className="mui--text-subhead mui--text-center" style={{fontSize:'20px'}}>{message}</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
} 
export default ErrorBlock;