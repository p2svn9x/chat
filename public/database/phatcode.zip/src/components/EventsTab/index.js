import React from 'react';
import {connect} from 'react-redux';
import ErrorBlock from '../ErrorBlock';


class EventsTab extends React.Component {
    shouldComponentUpdate(nextProps){
        return (
            this.props.lastUpdated !== nextProps.lastUpdated ||
            this.props.sync !== nextProps.sync
        )
    }
    render(){    
        const {component:Event,gameId,gameTitle,error,events,sync} = this.props;
        if (sync){
            return <ErrorBlock message="Loading..." />
        }
        if (!!error.message){
            return <ErrorBlock message={error.message} />
        }
        if (!events){
            return null
        }
        if (!!events.error){
            return <ErrorBlock message={events.error} />
        }
        if (events.length === 0){
            return <ErrorBlock message="Không có sự kiện nào!" />
        }
        return (
           <React.Fragment>
                {events.map((event) => (
                    <Event 
                        event={event} 
                        gameId={gameId}
                        gameTitle={gameTitle}                       
                        key={event.id} 
                    />
                ))}                
            </React.Fragment>        
        )  
    }
} 

export default connect((state,{gameId,onGetEvents}) => {
    const data = onGetEvents(state,gameId);       
    return data
},null)(EventsTab);