import React from 'react';
import {Button} from 'muicss/react';

const BlockRetry = ({error,onRetry}) => {
    if (!error){
        return null
    }
    if (error.code === 501){
        return (
            <div style={{padding:'15px',textAlign:'center'}}>
                <span style={{color:'red'}}>{error.message}</span> <br />
                <Button onClick={() => onRetry()} className="f-btn-orage">Thử lại</Button>
            </div>
        )
    }
    return (
        <div style={{padding:'15px',color:'red'}}>{error.message}</div>
    )
} 
export default BlockRetry;