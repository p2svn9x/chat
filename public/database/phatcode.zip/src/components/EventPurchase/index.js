import React from 'react';
import EventHeader from '../EventHeader';
import EventDueTime from '../EventDueTime';
import EventDescription from '../EventDescription';
import EventReward from '../EventReward';
import EventPurchaseButton from '../EventPurchaseButton';

const EventPrice = ({price}) => {
    if (price){
        return (
            <p className="txt-code">
                <i className="ico-fc"></i>
                {price} FC
            </p> 
        )
    }
    return null
}

const EventPurchase = ({event,gameId,onCopied,onFoward}) => (
    <div className="box-blockcode box-blockcode-funcoin">
        <EventHeader 
            isNew={event.is_new} 
            title={event.title}
            giftcode={event.giftcode}
            status={event.status}
            onCopied={onCopied}
            onFoward={onFoward}
        />
        <div className="code-main">
            <EventDueTime 
                startTime={event.start_time} 
                endTime={event.end_time} 
            />               
            <EventDescription 
                status={event.status}
                message={event.message}
                description={event.description}               
            />
            <EventReward reward={event.reward} />  
            <EventPrice price={event.price} />
            <EventPurchaseButton event={event} gameId={gameId} />                 
        </div>            
    </div>
)

export default EventPurchase;   