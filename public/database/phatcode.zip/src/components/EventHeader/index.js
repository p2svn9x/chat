import React from 'react';
import DropMenu from '../EventDropMenu';

const EventHeader = ({isNew,title,giftcode,status,onCopied,onFoward}) => (
    <div className="code-header">
        <i className="ico-codeh"></i>
        <div className="code-header-i">
            {isNew && (<i className="ico-news"></i>)}
            {title}
        </div>
        <DropMenu 
            giftcode={giftcode || ''} 
            status={status}
            onCopied={onCopied}
            onFoward={onFoward}
        />
    </div>
)

export default EventHeader;