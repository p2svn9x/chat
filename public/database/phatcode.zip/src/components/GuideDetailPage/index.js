import React from 'react'
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import {Container} from 'muicss/react';
import ErrorBlock from '../ErrorBlock';
import HelMet from '../Helmets';
import {getArticle} from '../../snippets/api';
import { mergeDataGuides } from '../../actions/guides';
import {createMetaPage} from '../../constants/meta';

const ArticleInner = ({article}) => {
    if (!!article){
        return (
            <Container fluid={!0}>
                <HelMet meta={createMetaPage(article.title)} /> 
                <div className="f-title-main">{article.title}</div>                
                <div className="articleContent" dangerouslySetInnerHTML={{ __html: article.content }} />
            </Container>
        )
    }
    return null
}

class GuideDetailPage extends React.Component {
    constructor(props){
        super(props);
        this.article = props.article;
        this.state = {
            error:'',
            loading:!1
        }
    }    
    componentWillMount(){
        if (!this.props.article){
            this.getArticle();
        }
    }   
    setErrorServerResponse(message){
        this.setState({loading:!1,error:message})
    }
    setSuccessServerResponse(article){        
        this.article = article;
        this.props.onMergeGuide([article])
        this.setState({loading:!1})
    }
    getArticle(){
        const _this = this;  
        this.setState({loading:!0});
        getArticle().subscribe((r) => {
            const response = r.response;
            try {
                if (!!response.data){
                    _this.setSuccessServerResponse(response.data)
                } else {
                    _this.setErrorServerResponse('Đã có lỗi xảy ra, vui lòng thử lại sau!')
                }
            } catch(err){
                _this.setErrorServerResponse('Đã có lỗi xảy ra, vui lòng thử lại sau!')
            }           
        },() => {
            _this.setErrorServerResponse('Mất kết nối tới máy chủ!')
        }) 
    } 
    render(){
        const {article} = this;
        const {error,loading} = this.state; 
        if (!!error){
            return <ErrorBlock message={error} />
        }
        if (loading){
            return <ErrorBlock message="Loading..." />
        }
        return (
            <div style={{height:'100%'}}>                                               
                <div id="content-wrapper">                                                       
                    <div className="box-main">    
                        <ArticleInner 
                            article={article} 
                        />                         
                    </div>  
                </div>
            </div>
        )        
    }
}
export default connect((state) => ({
    article:state.guides.data[0] || null
}),(dispatch) => ({
    onMergeGuide:bindActionCreators(mergeDataGuides,dispatch)
}))(GuideDetailPage);