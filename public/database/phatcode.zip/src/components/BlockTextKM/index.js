import React from 'react';
//import {withRouter} from 'react-router';

const Link = ({children,href}) => (
    <a className="link-ads-block" style={{
        display:'block',
        lineHeight:'20px',
        padding:'10px 16px',
        fontSize:'13px',
        color:'#fff',
        textDecoration:'underline',
        background:'rgba(0,0,0,0.87)'
    }} href={href} target="_blank" rel="noopener noreferrer">
    {children}
    </a>
)

const BlockTextKM = ({pathname}) => {   
    let alias = pathname.split('/')[1];
    if (alias === 'nhat-kiem-giang-ho-mobile'){
        return (
            <Link href="https://nhatkiemgiangho.vn/huong-dan/cap-25-mo-nap-the-cap-35-mo-giftcode">
                Chú ý: Cấp 25 mở Nạp, Cấp 35 mở Giftcode. Hướng dẫn nhập Giftcode.
            </Link>
        )
    } else if (alias === 'tam-quoc-du-hi'){
        return (
            <Link href="https://tamquocduhi.vn/huong-dan/huong-dan-nhap-giftcode">
                Chú ý: Nhân vật đạt level 10 mở nạp thẻ và giftcode. Hướng dẫn nhập Giftcode.
            </Link>
        )
    } else if (alias === 'lang-quai-thu'){
        return (
            <Link href="https://langquaithu.vn/huong-dan/huong-dan-nhap-code-trong-game-va-tren-web">
                Chú ý: Cấp 8 mở Nạp, Cấp 10 mở Giftcode. HD nhập Giftcode.
            </Link>
        )
    } else if (alias === 'ngoa-long-truyen'){
        return (
            <Link href="https://ngoalongtruyen.vn/su-kien/chuoi-phuc-loi-uu-dai-server-moi">
                Chú ý: Nạp thẻ tuần 50k, thẻ tháng 100k; cấp 10 mở nạp, mở nhập code; X2 nạp đầu từng mệnh giá.               
            </Link>
        )
    } else if (alias === 'luc-dia-hoan-my'){
        return (
            <Link href="http://lucdiahoanmy.vn/news/guides/huong-dan-cach-nhap-giftcode">
                Lưu ý: Level 72 mở nạp và nhập Giftcode trong game. Click để xem hướng dẫn nhập Giftcode.              
            </Link>
        )
    } else if (alias === 'tinh-kiem-3d'){
        return (
            <React.Fragment>
            <Link href="https://tinhkiem3d.vn/huong-dan/huong-dan-chuoi-su-kien-nap-uu-dai">
                LƯU Ý: Cấp 8 mở nạp, nhận code; X2 nạp đầu từng mệnh giá. Click xem chi tiết.              
            </Link>
            <Link href="https://tinhkiem3d.vn/huong-dan/huong-dan-nhap-giftcode">
                Hướng dẫn nhập Code trong game.              
            </Link>
            </React.Fragment>
        )
    }
    return null    
}

BlockTextKM.defaultProps = {
    pathname:''
}

export default BlockTextKM;

//export default withRouter(BlockTextKM);