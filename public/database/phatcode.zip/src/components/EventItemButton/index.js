import React from 'react';
import { bindActionCreators } from 'redux';
import {connect} from 'react-redux';
import {Button} from 'muicss/react';
import {formatTimeEvent} from '../../snippets/format';
import {getGiftcodeByEventId} from '../../actions/giftcode';

const ALink = ({href,className,label,style}) => (
    <a href={href} target="_blank" style={style} rel="noopener noreferrer" className={className}>{label}</a>
)
ALink.defaultProps = {
    className:'',
    style:{}
}

const ButtonStatus0 = ({postId}) => (
    <ALink 
        href={`https://facebook.com/${postId}`} 
        className="mui-btn mui-btn--danger f-btn-100" 
        label="Tham gia ngay" 
    />    
)

const ButtonStatus1 = connect(null,(dispatch,props) => ({
    onGetGiftcode:(callback) => bindActionCreators(getGiftcodeByEventId,dispatch)(props.eventId,props.gameId,callback)
}))(({onGetGiftcode}) => (
    <Button onClick={(e) => {
        const target = e.target;       
        target.classList.add('mui-is--disabled');
        target.setAttribute('disabled',!0);        
        onGetGiftcode((response) => {            
            if (!!response.error){                               
                target.classList.remove('mui-is--disabled');               
                target.removeAttribute('disabled');
                alert(response.error)
            } 
        })
    }} className="mui-btn--primary f-btn-100">
        Nhận code ngay
    </Button>
))

export const ButtonStatus2 = ({giftcode,message,expried}) => {
    if (giftcode){
        return (
            <p className="txt-code">
                <i className="ico-ccode"></i>
                Giftcode: <span>{giftcode}</span>
                {!!message && <span className="txt-codeerr">{message}</span>}<br />
                Hạn dùng: {formatTimeEvent(expried)}
            </p>
        )
    }
    return null
} 

const ButtonStatus3 = ({children}) => (
    <p className="txt-code txt-codeerr">
        <i className="ico-ccode"></i>                
        {children}                    
    </p>
)

const EventItemButton = ({event,gameId}) => {
    const status = Number(event.status);
    if (status === 0){
        if (Number(event.giftcode_left) === 0){
            const style = {
                textDecoration:'underline',
                padding:'0',
                color:'#ff0d06'
            };
            return (
                <ButtonStatus3>
                    Đã phát hết code. 
                    Xem <ALink href={`https://facebook.com/${event.fanpage_post_id}`} style={style} label="sự kiện" />
                </ButtonStatus3>
            )
        } else {
            return (
                <ButtonStatus0 postId={event.fanpage_post_id} />
            )
        }       
    } else if (status === 1){        
        return <ButtonStatus1 eventId={event.id} gameId={gameId} />
    } else if (status === 2){
        return <ButtonStatus2 giftcode={event.giftcode} message={event.message} expried={event.expire_time} />
    } else if (status === 3){
        return <ButtonStatus3>{event.message}</ButtonStatus3>
    } else {
        return null
    }
}

export default EventItemButton;