import React from 'react';

const BlockLoading = () => {
    return (
        <div style={{padding:'20px 0'}}>            
            <div className="cssload-container">
                <div className="cssload-double-torus"></div>
            </div>
        </div>
    )
}
export default BlockLoading;