import React from 'react';

const EventReward = ({reward}) => {
    if (reward){
        return (
            <p className="txt-code">
                <i className="ico-cgt"></i>
                {reward}
            </p>
        )
    }
    return null
} 

export default EventReward;