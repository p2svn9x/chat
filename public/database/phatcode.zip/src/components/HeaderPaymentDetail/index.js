import React from 'react';
import {connect} from 'react-redux';
import {Container,Col,Row} from 'muicss/react';
import {formatMoney} from '../../snippets/format';

const PaymentDetail = ({value,label,type}) => (
    <Col md="6" xs="6" className="mui--text-center">
        <div className="mui--text-title">
            {formatMoney(value || 0)} {type === 'fc' ? 'FC' : <i className="ic-thoc"></i>}
        </div>
        <div className="mui--text-caption mui--text-dark-secondary">
            {label}<i className="spr f-ico f-ico-hd"></i>
        </div>
    </Col>
)

const HeaderPaymentDetail = ({funcoin,money}) => (
    <Container fluid={!0}>
        <Row className="f-box-tttl">
            <PaymentDetail label="Tài khoản funcoin" value={funcoin} type="fc" />
            <PaymentDetail label="Tài khoản tttt" value={money} />
        </Row>
    </Container>
)

export default connect((state) => ({
    funcoin:state.userInfo.funcoin,
    money:state.userInfo.money
}),null)(HeaderPaymentDetail);