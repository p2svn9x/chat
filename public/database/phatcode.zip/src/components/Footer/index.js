import React from 'react';

const LinkFooter = ({href,label}) => (
    <a href={href} rel="noopener noreferrer" target="_blank" className="f-txtlink">{label}</a>
)
const Footer = () => (
    <footer id="footer">
        <p className="mui--text-left">
            <LinkFooter href="https://funtap.vn/" label="Funtap" />
            <LinkFooter href="https://funtap.vn/dieu-khoan" label="Điều khoản" />
            <LinkFooter href="https://funtap.vn/bao-mat" label="Bảo mật" />
            <LinkFooter href="https://hotro.funtap.vn/" label="Hỗ trợ" />
        </p>
    </footer>
)

export default Footer;