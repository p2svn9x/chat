import React from 'react';
import { connect } from 'react-redux';
import NotFound from '../NotFound';
import ErrorBlock from '../ErrorBlock';
import {getGameInfo} from '../../snippets/filters';
/** 
    Checking game is exsits and available
    @param {Component}
    @return {Component add props gameInfo}
 */

export default function withGame(Component){
    function ComposedComponent({gameInfo,dispatch,...props}){              
        if (!gameInfo){
            return <NotFound />
        } else if (gameInfo.isMaintain){
            return <ErrorBlock message="Hệ thống đang bảo trì" />
        }
        return <Component {...props} gameInfo={gameInfo} />
    }
    return connect((state,props) => ({
        gameInfo:getGameInfo(props.location.pathname.split('/')[1],state.games)
    }),null)(ComposedComponent)
}
