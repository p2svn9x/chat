import React from 'react';
import { TransitionGroup, CSSTransition } from "react-transition-group";
import {Route} from 'react-router';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import ErrorBlock from '../ErrorBlock';
import { redirectLoginAPI } from '../../snippets/api';
import {setHeaderTitle} from '../../actions/header'; 
import {getGameInfo, getCuserFromParamsUrl} from '../../snippets/filters';
import { GAME_TITLE } from '../../constants/headerTitle';
import NotFound from '../NotFound';
//import {EventEmitter} from 'events';

class Transition extends React.Component {
    componentWillMount(){
        this.props.onEnter()
    }    
    render(){
        const {component:Component,onEnter,...rest} = this.props;
        const {pathname} = this.props.location;
        return (
            <TransitionGroup>
                <CSSTransition 
                    classNames="fade" 
                    key={pathname} 
                    timeout={300} 
                    onEnter={() => onEnter()}                     
                    mountOnEnter={!1} 
                    unmountOnExit={!1}>
                    <Component {...rest} />
                </CSSTransition>
            </TransitionGroup>
        )
    }
}  

export const PublicRoute = connect(null,(dispatch,props) => ({
    onSetHeaderTitle:() => bindActionCreators(setHeaderTitle,dispatch)(props.title || '')
}))(({component: Component,...rest,onSetHeaderTitle}) => (
    <Route {...rest} render={props => {
        return (
            <Transition onEnter={onSetHeaderTitle} component={Component} {...props} />
        )
    }} />
)) 

export const AuthRoute = connect(
    (state,props) => {
        const gameInfo = getGameInfo(props.location.pathname.split('/')[1],state.games) || {};
        return {
            sync:state.userInfo.sync,
            isAuthenticated:!!state.userInfo.id && !!state.userInfo.username,        
            gameTitle:gameInfo.title
        }
    },
    (dispatch) => ({
        onSetHeaderTitle:bindActionCreators(setHeaderTitle,dispatch)
    }),
    (stateProps,dispatchProps,ownProps) => ({
        ...ownProps,
        ...stateProps,
        onSetHeaderTitle:() => dispatchProps.onSetHeaderTitle(ownProps.title === GAME_TITLE ? (stateProps.gameTitle || '') : (ownProps.title || '')),
    })
)(({component: Component,sync,onSetHeaderTitle,isAuthenticated,title,gameTitle,...rest}) => (
    <Route {...rest} render={props => { 
        if (sync){
            return (
                <ErrorBlock message="Loading..." />
            )
        }
        if (isAuthenticated){
            return (
                <Transition onEnter={onSetHeaderTitle} component={Component} {...props} /> 
            )
        } else {       
            if (!!props.match.params && !!props.match.params.alias && !gameTitle){
                return <NotFound />
            } else {
                const cuser = getCuserFromParamsUrl(props.location.search);
                const params = {
                    reditectTo:window.location.hostname,
                    option:props.location.pathname.substr(1),
                    cuser
                }
                window.location.href = redirectLoginAPI(params)
                return (
                    <ErrorBlock message="Bạn chưa đăng nhập!" />
                )
            }   
            
        }
    }} />
));
