import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {ButtonStatus2} from '../EventItemButton';
import { getGiftcodePurchaseByEventId } from '../../actions/giftcode';
import { minusFuncoinUser } from '../../actions/user';

const Modal = ({
    show,
    title,
    description,
    btnLeft,
    btnRight,
    onClose
}) => {
    if (show){
        return (
            <div className="box-modal">
                <div className="modal-inner cnt">
                    <h3 className="rs">
                        {title}
                        <a style={{cursor:'pointer'}} className="ico-hide" onClick={onClose} />
                    </h3>
                    <div className="box-lydo" style={{padding:'16px'}}>
                        <p className="txt-lydo" dangerouslySetInnerHTML={{__html:description}} />                   
                        <div className="box-pop-btn">
                            {btnLeft()}
                            {btnRight()}                                                       
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    return null
} 
Modal.defaultProps = {
    btnLeft:() => {},
    btnRight:() => {}
}

const ButtonModal = ({className,onClick,title}) => (
    <a className={`mui-btn ${className}`} style={{cursor:'pointer'}} onClick={onClick} >{title}</a>
)

class EventPurchaseButton extends React.Component {
    constructor(){
        super();
        this.closeModalConfirm = this.closeModalConfirm.bind(this);
        this.closeModalError = this.closeModalError.bind(this)
    }
    state = {
        requesting:!1,
        modalConfirm:!1,
        modalError:!1
    }
    handleClick = () => {
        const {funcoin} = this.props;
        const {price} = this.props.event;
        if (funcoin < Number(price)){
           this.setState({modalError:!0})
        } else {    
            this.setState({modalConfirm:!0})
        } 
    }
    handleBuyGiftcode = () => {
        if (!this.state.requesting){
            const eventId = this.props.event.id;           
            const {gameId} = this.props;            
            this.setState({requesting:!0,modalConfirm:!1});
            this.props.onGetGiftcode(eventId,gameId,this.handleResponse.bind(this))
        }        
    }
    handleResponse = (response) => {
        if (!!response.error){
            this.setState({requesting:!1});
            alert(response.error);
        } else if (response.message === 'success'){
            this.props.onMinusFuncoin(this.props.event.price)
        }
    }
    closeModalConfirm = () => {
        this.setState({modalConfirm:!1})
    }
    closeModalError = () => {
        this.setState({modalError:!1})
    }
    render(){
        const {modalConfirm,modalError,requesting} = this.state;
        const {price,title,giftcode,message,expire_time} = this.props.event; 
        const status = Number(this.props.event.status);    
        if (status === 2){
            return (
                <ButtonStatus2 giftcode={giftcode} message={message} expried={expire_time} />
            )    
        }
        if (Number(price) === 0){
            return null
        }
        return (
            <div>
                <Modal 
                    show={modalConfirm} 
                    title="Xác nhận mua" 
                    description={`Bạn đồng ý sử dụng ${price} Funcoin để mua <b>${title}</b> không?`}
                    onClose={this.closeModalConfirm}
                    btnLeft={() => <ButtonModal onClick={this.closeModalConfirm} title="Hủy" />}
                    btnRight={() => <ButtonModal className="f-btn-orage" onClick={this.handleBuyGiftcode.bind(this)} title="Đồng ý" />}
                />
                <Modal 
                    show={modalError} 
                    title="Lỗi..."
                    description={`Không đủ Funcoin để mua <b>${title}</b>, bạn có thể nạp thêm hoặc hoàn thành nhiệm vụ của chúng tôi để nhận Funcoin`}
                    onClose={this.closeModalError}
                    btnLeft={() => <ButtonModal className="f-btn-red" onClick={this.closeModalError} title="Tôi đã hiểu" />}
                />
                <a className={`mui-btn mui-btn--danger f-btn-100 ${requesting ? 'mui--is-disabled' : ''}`} disabled={requesting} onClick={this.handleClick}>Mua ngay</a>
            </div>
        )
    }
}

export default connect((state) => ({
    funcoin: Number(state.userInfo.funcoin || 0)    
}),(dispatch) => ({
    onGetGiftcode:bindActionCreators(getGiftcodePurchaseByEventId,dispatch),
    onMinusFuncoin:bindActionCreators(minusFuncoinUser,dispatch) 
}))(EventPurchaseButton);