import React from "react";
import {withRouter} from 'react-router';
import {Helmet} from "react-helmet";
import google_tag from '../../snippets/googletag';

class HelMet extends React.Component {
    componentWillMount(){        
        this.sendAnalytics()       
    }     
    componentWillReceiveProps(nextProps){
        if (nextProps.meta.title !== this.props.meta.title){
            this.sendAnalytics()           
        }
    }  
    sendAnalytics(){
        const {meta,location:{pathname}} = this.props;  
        try {
            if (!!meta){     
                google_tag(meta.title,pathname)
            }
        } catch(err){}   
    }    
    render(){       
        const {meta,location:{pathname}} = this.props;      
        return (
            <Helmet>
                <title>{meta.title}</title>            
                <meta name="description" content={meta.description} />
                <meta name="og:site_name" content="Funtap" />
                <meta name="og:type" content="article" />
                <meta name="og:title" content={meta.title} />
                <meta name="og:url" content={`https://gc.funtap.vn${pathname}`} />
                <meta name="og:description" content={meta.description} />
                <meta name="og:image" content="http://funtap.vn/uncommon/funtap/images/funtap.jpg" />
                <link href={`https://gc.funtap.vn${pathname}`} rel="canonical" />            
            </Helmet>
        )
    }
}

export default withRouter(HelMet);
