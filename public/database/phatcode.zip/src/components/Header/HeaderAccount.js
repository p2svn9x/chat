import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {userLogout} from '../../actions/user';
import { redirectLoginAPI } from '../../snippets/api';


class HeaderAccount extends React.Component {
    constructor(){
        super();
        this.state={open:!1}
        this.handleDropdown = this.handleDropdown.bind(this)
    }
    componentWillReceiveProps(nextProps){
        if (!nextProps.userInfo.username){
            this.setState({open:!1})
        }
    }
    componentWillUnmount(){             
        this.removeEvent()  
     } 
    toggleDropdown = () => {        
        this.setState({open:!this.state.open}); 
        if (!this.state.open){
            this.addEvent()
        } else {
            this.removeEvent()
        }  
    }
    addEvent(){
        document.addEventListener('click',this.handleDropdown);
        document.addEventListener('touchstart',this.handleDropdown)
    }
    removeEvent(){
        document.removeEventListener('click',this.handleDropdown);
        document.removeEventListener('touchstart',this.handleDropdown)
    }
    handleDropdown = (e) => {
        if (this.dropdown && !this.dropdown.contains(e.target) && this.btndrodown && !this.btndrodown.contains(e.target)){
            this.setState({open:!1});
            this.removeEvent()
        }        
    }    
    render(){        
        const {userInfo,onLogout} = this.props;
        if (!userInfo.username || !userInfo.id){
            return (
                <a 
                    className="spr f-login click-animation" 
                    href={redirectLoginAPI({reditectTo:window.location.hostname})} 
                /> 
            )
        }
        const fw = (userInfo.username).charAt(0).toUpperCase();        
        return (
            <div className="box-login-done">
                <a className={`ico-avata no-indent click-animation ${fw}`} 
                    ref={(btn) => this.btndrodown = btn} onClick={this.toggleDropdown} 
                >
                {fw}
                </a>
                <ul className={`mui-dropdown__menu mui-dropdown__menu1 mui-dropdown__menu--right ${this.state.open ? 'mui--is-open' : ''}`} 
                    style={{top: '30px'}} ref={(dropdown) => this.dropdown = dropdown}>
                    <li>
                        <a>
                            <i className={`ico-avata-min avatar-letter ${fw}`}>{fw}</i>
                            {userInfo.username}
                        </a>
                    </li>                                 
                    <li>
                        <a style={{cursor:'pointer'}} onClick={() => onLogout()}>
                            <i className="ico-logout"></i>
                            Thoát
                        </a>
                    </li>
                </ul>
            </div>
        )       
    }
}
export default connect((state) => ({
    userInfo:{
        username:state.userInfo.username,
        id:state.userInfo.id
    }
}),(dispatch) => ({
    onLogout:bindActionCreators(userLogout,dispatch)
}))(HeaderAccount);