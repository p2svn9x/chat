
import React from 'react';
import {Link,NavLink} from 'react-router-dom';
import overlayFn from 'muicss/lib/js/overlay';

const ALink = ({href,icon,label}) =>  (
    <li>        
        <a className="ripple" href={href} target="_blank" rel="noopener noreferrer">
        <i className={`spr f-ico ${icon}`}></i> {label}           
        </a>        
    </li>
)
const NavLinkApp = ({to,icon,label}) => (
    <li>        
        <NavLink className="ripple" to={to} activeClassName="active" onClick={() => overlayFn('off')}>
            <i className={`spr f-ico ${icon}`}></i> {label}           
        </NavLink>        
    </li>
)
const LinkApp = ({to,icon,label}) => (
    <li>        
        <Link className="ripple" to={to}>
            <i className={`spr f-ico ${icon}`}></i> {label}           
        </Link>        
    </li>
)

class Sidebar extends React.Component {
    componentWillUnmount(){ 
        overlayFn('off');   
        if (!!document.getElementById('sidedrawer')){
            document.getElementById('sidedrawer').remove() 
        }  
    }
    showSidebar = (e) => {
        e.preventDefault();        
        var sidedrawer = this.refs.sidedrawer;           
        const options = {
            onclose: function() {
                sidedrawer.classList.remove('active');                
                document.body.appendChild(sidedrawer);
            }
        }         
        const overlay = overlayFn('on', options);     
        overlay.appendChild(sidedrawer);
        setTimeout(function() {
            sidedrawer.classList.add('active');
        }, 20);
    }    
    render(){      
        return (
            <React.Fragment>
                <a className="sidedrawer-toggle js-show-sidedrawer click-animation f-ico-touch" onClick={this.showSidebar} />
                <div style={{display:'none'}} ref="sidedrawwrap">
                    <div id="sidedrawer" className="mui--no-user-select" ref="sidedrawer">
                    <div className="mui-divider"></div>
                        <ul>    
                            <NavLinkApp to="/" icon="f-ico-home" label="Trang chủ" />                              
                            <LinkApp to="/huong-dan" icon="f-ico-home" label="Hướng dẫn nhập code" /> 
                            <ALink href="https://hotro.funtap.vn" icon="f-ico-bl" label="Báo lỗi code" />                    
                            <ALink href="https://nap.funtap.vn" icon="f-ico-pay" label="Nạp tiền" />                                                   
                        </ul>                    
                    </div>
                </div>                
            </React.Fragment>
          )
    }
}

export default Sidebar;