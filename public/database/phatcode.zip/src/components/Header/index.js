import React from 'react';
import {connect} from 'react-redux';
import {compose, bindActionCreators} from 'redux';
import {Link} from 'react-router-dom';
import {withRouter} from 'react-router';
import { Appbar,Container} from 'muicss/react';
import HeaderAccount from './HeaderAccount';
import Sidebar from './Sidebar';
import {getGameId, getCuserFromParamsUrl} from '../../snippets/filters';
import { syncEventsByGame } from '../../actions/events';
import { syncPurchaseEventByGame } from '../../actions/purchase';
import { submitConnectFacebook} from '../../actions/submit';

const BackButton = ({goBack}) => (
    <a onClick={() => { 
        goBack();         
    }} className="sidedrawer-toggle f-ico-back f-ico-arr-back spr click-animation" />
)
const HomeButton = () => (
    <Link className="f-ico-hp click-animation" to="/">Trang chủ</Link>
)

class Header extends React.Component {
    componentWillMount(){   
        this.syncData(this.props.gameId);               
    }
    componentWillReceiveProps(nextProps){
        if (this.props.gameId !== nextProps.gameId){
            this.syncData(nextProps.gameId)
        }
    }
    componentDidUpdate(prevProps){
        if (this.props.isAuthenticated !== prevProps.isAuthenticated){
            this.syncData(this.props.gameId)
        }
    }
    syncData(gameId){
        const {isAuthenticated,onSyncGameEvents,onSyncPurchaseEvents,onSubmitConnectFacebook,location} = this.props;
        if (isAuthenticated && !!gameId){  
            const cuser = getCuserFromParamsUrl(location.search);
            if (!!cuser){
                onSubmitConnectFacebook('CNPARAMS' + cuser,gameId,this.handleConnectResponse.bind(this,gameId))
            } else {
                onSyncGameEvents(gameId)
            }
            onSyncPurchaseEvents(gameId)
        }
    }
    handleConnectResponse = (gameId) => {
        this.props.onSyncGameEvents(gameId)
    }
    render(){
        const {location:{pathname},history,title} = this.props;
        //const title = setTitle(pathname,!!gameId);  
        return (
            <React.Fragment>
                <header id="header" className="header-shadow">
                    <Appbar className="mui--appbar-line-height">
                        <Container fluid={true}>
                            {title !== '' ? (pathname === '/' ? <Sidebar /> : <BackButton goBack={() => history.goBack()} />) : <HomeButton />}                                       
                            {title !== '' && (
                                <div className="mui--text-title f-txtheader">
                                    <h1>{title}</h1>                                                                                    
                                </div>
                            )}
                            <HeaderAccount />   
                        </Container>
                    </Appbar>     
                </header>
                <div className="mui--appbar-height"></div>
            </React.Fragment>
        )
    }
}
export default compose(
    withRouter,
    connect((state,props) => ({
        isAuthenticated:!!state.userInfo.id && !!state.userInfo.username,
        gameId:getGameId(props.location.pathname.split('/')[1],state.games),
        title:state.header.title        
    }),(dispatch) => ({
        onSyncGameEvents:bindActionCreators(syncEventsByGame,dispatch),
        onSyncPurchaseEvents:bindActionCreators(syncPurchaseEventByGame,dispatch),
        onSubmitConnectFacebook:bindActionCreators(submitConnectFacebook,dispatch)     
    }))
)(Header);