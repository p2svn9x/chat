import React from 'react';

const Description = ({text}) => (
    <p className="txt-code">
        <i className="ico-cmv"></i>
        {text}
    </p>
)

const EventDescription = ({status,message,description,gameTitle}) => { 
    if (Number(status) !== 4){
        if (!!description){
            return (
                <Description text={description} />            
            )
        }
        return null
    }
    if (!!message){
        return (
            <Description text={`Tài khoản của bạn chưa đạt đủ điều kiện nạp tối thiểu ${message + '.000'}VNĐ vào game ${gameTitle} để nhận được giftcode. 
                Vui lòng nạp đủ điều kiện để nhận được quyền lợi này.`} 
            />
        )
    }
    return null
}
export default EventDescription;