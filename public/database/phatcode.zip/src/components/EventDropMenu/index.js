import React from 'react';
import CopyToClipboard from 'react-copy-to-clipboard';
import {EventPageContext} from '../EventsPage';

class DropMenu extends React.Component {
    constructor(){
        super();
        this.state = {show:!1};       
        this.handleToggleMenu = this.handleToggleMenu.bind(this)
    }   
    showMenu(){       
        this.setState({show:!0});
        this.addEvent()        
    }
    hideMenu(){       
        this.setState({show:!1});
        this.removeEvent()        
    }
    componentWillUnmount(){             
        this.removeEvent()
    }
    handleToggleMenu = (e) => { 
        if (!!this.menu && !this.menu.contains(e.target)) {
           this.hideMenu()
        }
    }
    addEvent(){
        document.addEventListener('click',this.handleToggleMenu);
        document.addEventListener('touchstart',this.handleToggleMenu);
    }   
    removeEvent(){
        document.removeEventListener('click',this.handleToggleMenu);
        document.removeEventListener('touchstart',this.handleToggleMenu);
    } 
    //!!events.isRedeem && (<li><a className="ripple" onClick={() => events.onFoward(giftcode)}>Đổi code</a></li>)
    render(){
        const {status,giftcode} = this.props;
        const {show} = this.state;        
        if (Number(status) === 2){
            return (
                <EventPageContext.Consumer>
                    {(events) => (
                        <div className="code-slt">                              
                            <a className="click-animation btn-code-slt" onClick={() => this.showMenu()}></a>                        
                            <ul className={`mui-dropdown__menu mui-dropdown__menu--right ${show ? 'mui--is-open' : ''}`} ref={(menu) => this.menu = menu}>
                                <li>
                                    <CopyToClipboard text={giftcode} onCopy={(e) => events.onCopied(e)}>
                                        <a className="ripple" onClick={() => this.hideMenu()}>Copy code</a>
                                    </CopyToClipboard>
                                </li>
                                <li><a className="ripple" onClick={() => events.onFoward(giftcode)}>Đổi code</a></li>                 
                                <li><a className="ripple" href="https://hotro.funtap.vn">Báo lỗi code</a></li>
                            </ul>                        
                        </div>
                    )}                
                </EventPageContext.Consumer>
            )
        }
        return null
    }
}

export default DropMenu;

