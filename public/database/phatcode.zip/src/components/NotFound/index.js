import React from 'react';
import Helmet from '../Helmets';
import { notFoundPageMeta } from '../../constants/meta';

class NotFound extends React.Component {
    constructor(){
        super();
        this.calcHeight = this.calcHeight.bind(this)
    }
    state = {
        height:''
    }
    componentWillMount(){
        this.calcHeight();
        window.addEventListener('resize',this.calcHeight)
    }
    componentWillUnmount(){
        window.removeEventListener('resize',this.calcHeight)
    }
    calcHeight = () => {
        this.setState({height:window.innerHeight - 64})        
    }
    render(){
        return (
            <div style={{height:'100%'}}>
                <Helmet meta={notFoundPageMeta} />
                <style dangerouslySetInnerHTML={{__html: `#footer { display:none !important }`}} />               
                <div id="content-wrapper">                    
                    <div className="box-fullh" style={{height:this.state.height}}>
                    <div className="box-fullh-center">
                        <div className="mui--text-display3 mui--text-center">404</div>
                        <div className="mui--text-subhead mui--text-center">Không tìm thấy trang</div>
                    </div>
                </div>
                </div>
            </div>
        )
    }
}

export default NotFound;