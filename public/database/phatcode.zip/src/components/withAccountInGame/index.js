import React from 'react';
//import { connect } from 'react-redux';
//import NotFound from '../notfound';
import ErrorBlock from '../ErrorBlock';
/** 
    Checking account game is exsits and available
    @param {Component}
    @return {Component add props accountInfo}
 */
export default function withAccountInGame(Component){
    return function ComposedComponent(props){   
        const accountFrom = props.location.state || props.accountInfo || {}; // props accountInfo from result success
        const accountInfo = {
            roleId:accountFrom.roleId,
            roleName:accountFrom.roleName,
            areaId:accountFrom.areaId,
            areaName:accountFrom.areaName
        } 
        if (!accountInfo.roleId || !accountInfo.areaId){
            return <ErrorBlock message="Bạn chưa chọn nhân vật, hãy quay lại chọn nhân vật" />
        }        
        return <Component {...props} accountInfo={accountInfo} />
    }
}
