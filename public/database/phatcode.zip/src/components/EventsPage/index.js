import React from 'react';
// import { compose,bindActionCreators } from 'redux';
// import {connect} from 'react-redux';
import withGame from '../withGame';
import HeaderGameDetail from '../HeaderGameDetail';
import HeaderPaymentDetail from '../HeaderPaymentDetail';
import ConnectFacebook from '../ConnectFacebook';
import BlockTextKM from '../BlockTextKM';
import EventsTab from '../EventsTab';
import EventItem from '../EventItem';
import EventPurchase from '../EventPurchase';
import { 
    getGameEvents,
    getDataPurchase,
    getGameEventsFilter 
} from '../../snippets/filters';
import Helmet from '../Helmets';
import { createMetaPage } from '../../constants/meta';
//import {setHeaderTitle} from '../../actions/header';

const tabs = [
    {label:'Tất cả',hash:'tat-ca',component:EventItem,onGetEvents:(state,gameId) => getGameEvents(state,gameId)},
    {label:'Chưa nhận',hash:'chua-nhan',component:EventItem,onGetEvents:(state,gameId) => getGameEventsFilter(state,gameId)},
    {label:'Mua giftcode',hash:'mua-giftcode',component:EventPurchase,onGetEvents:(state,gameId) => getDataPurchase(state,gameId)}
]

const TabTitle = ({label,active,onClick}) => (
    <li className={`${active ? 'mui--is-active' : ''}`}>
        <a className="ripple" onClick={onClick}>{label}</a>
    </li>
)

export const EventPageContext = React.createContext();


class EventsPage extends React.Component {
    constructor(){
        super();
        this.state = {
            active:'',
            giftcode:''
        }
        this.onFoward = this.onFoward.bind(this);
        this.onCopied = this.onCopied.bind(this)
    }    
    componentWillMount(){      
        this.changeTabActive(0)
    }   
    changeTabActive(idx){
        this.setState({active:idx})
    }   
    onFoward = (giftcode) => {
        const gameAlias = this.props.gameInfo.alias;     
        this.props.history.push({
            pathname:`/${gameAlias}/nhapcode`,
            state:{giftcode:giftcode || this.state.giftcode}
        })
    } 
    onCopied = (giftcode) => {
        this.setState({giftcode});
        this.showCopy();
    }
    hideCopy(){
        if (this.timeout){
            clearTimeout(this.timeout);            
            this.refs.copypop.style.opacity = 0;
        }
    }
    showCopy(){        
        this.hideCopy();               
        this.refs.copypop.style.opacity = 0.75;         
        this.timeout = setTimeout(() => {
            this.refs.copypop.style.opacity = 0;
        },1500)       
    }
    render(){
        const {gameInfo,location:{pathname}} = this.props;
        const {active} = this.state;
        return (
            <div>
                <Helmet meta={createMetaPage(`Nhận giftcode ${gameInfo.title}`)} />
                <style dangerouslySetInnerHTML={{__html:'.header-shadow {box-shadow:none;-webkit-box-shadow:none}'}} />
                <div id="header-fix" className="box-htab">
                    <ul className="mui-tabs__bar">
                        {tabs.map((tab,i) => (
                            <TabTitle 
                                key={`tabnav-${i}`} 
                                label={tab.label} 
                                active={i === active} 
                                onClick={() => this.changeTabActive(i)}
                            />
                        ))}                        
                    </ul>
                </div>
                <div id="content-wrapper">
                    <div className="mui-tabs__height" />
                    <div className="box-mainc">
                        <div className="box-thongtin">
                            <HeaderGameDetail 
                                gameIcon={gameInfo.icon} 
                                gameTitle={gameInfo.title}
                            />
                            <HeaderPaymentDetail />
                            <BlockTextKM pathname={pathname} />  
                        </div>
                        <div className="box-lstTab">
                            <ConnectFacebook gameId={gameInfo.id} />  
                            <EventPageContext.Provider value={{onFoward:this.onFoward,onCopied:this.onCopied,isRedeem:!!gameInfo.isRedeem}}>                          
                                {tabs.map((tab,i) => (
                                    <div key={`tab-${i}`} className={`mui-tabs__pane ${i === active ? 'mui--is-active' : ''}`}>                                        
                                        <EventsTab
                                            gameId={gameInfo.id}  
                                            gameTitle={gameInfo.title} 
                                            {...tab}
                                        />                                        
                                    </div>
                                ))}
                            </EventPageContext.Provider>                                  
                        </div>
                    </div>  
                    <div className="alert-box" ref="copypop">Đã sao chép code</div>
                    <a className="btn-doicode ripple" onClick={() => this.onFoward()} style={{cursor:'pointer'}}>Đổi giftcode</a>                
                </div>
            </div>
        )
    }
}
export default withGame(EventsPage);
