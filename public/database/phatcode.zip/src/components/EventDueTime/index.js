import React from 'react';
import {formatTimeEvent} from '../../snippets/format';

const EventDueTime = ({startTime,endTime}) => (
    <p className="txt-code">
        <i className="ico-ctime"></i>
        {formatTimeEvent(startTime)} - {formatTimeEvent(endTime)}
    </p>
)

export default EventDueTime;