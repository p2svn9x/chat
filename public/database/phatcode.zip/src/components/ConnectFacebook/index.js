import React from 'react';
import { bindActionCreators, compose } from 'redux';
import {connect} from 'react-redux';
import {withRouter} from 'react-router';
import {Link} from 'react-router-dom';
import { submitConnectFacebook, submitCancel } from '../../actions/submit';
import {syncEventsByGame} from '../../actions/events';
import { getGameSenderId, getCuserFromParamsUrl } from '../../snippets/filters';

class ConnectFacebookForm extends React.Component {
    state = {loading:!1,cuser:'',error:''}
    componentWillMount(){        
        const cuser = getCuserFromParamsUrl(this.props.paramsInUrl);
        if (!!cuser){
            this.setState({cuser})           
        }        
    }
    changeInput = (e) => {
        let error = '';
        if (!e.target.value){
            error = 'Bạn chưa nhập mã nối!'
        }
        this.setState({cuser:e.target.value,error})
    }
    submitHandle = (e) => {
        e.preventDefault();
        const {cuser,loading} = this.state;
        if (!loading && !!cuser){
            this.setState({loading:!0,error:''});
            this.props.onSubmit(cuser,this.handleResponse.bind(this))
        }
    }
    handleResponse = (response) => {      
        const {onSyncGameEvents} = this.props; 
        if (!!response.error){            
            this.setState({loading:!1,error:response.error})            
        } else {
            this.setState({loading:!1});
            onSyncGameEvents()
        }
    }
    componentWillUnmount(){
        this.props.onCancel()
    }
    render(){
        const {cuser,error} = this.state;
        return (
            <div className="noi-row">
                <form onSubmit={this.submitHandle}>
                    <input 
                        className="noi-input"                          
                        type="text" 
                        value={cuser} 
                        onChange={this.changeInput} 
                        onBlur={() => window.scrollTo(0,0)} 
                        placeholder="Nhập mã kết nối" 
                    />
                    <button className={`noi-btn ripple ${cuser ? 'active' : ''}`}></button>
                </form>
                {error && <p className="noi-err">{error}</p>}
            </div>
        )
    }
} 

const CustomDescByGame = ({pathname}) => {
    if (pathname.indexOf('tam-quoc-du-hi') >= 0){
        return (
            <span>
                Nếu không nhận được mã kết nối, bạn hãy chat với admin với nội dung: "Nhận mã kết nối" <a href="https://www.messenger.com/t/tamquocduhi" target="_blank">tại đây</a> 
            </span>
        )
    }
    return (
        <span>
            Nếu bạn không nhận được mã kết nối xin vui lòng làm theo hướng dẫn <Link to="/huong-dan">tại đây</Link>
        </span>
    )
} 

const ShortDescription = withRouter(({location:{pathname}}) => (
    <p className="noi-des">
        Bạn cần nhập mã kết nối để nhận được Giftcode sự kiện Like/Comment trên fanpage. 
        Mã kết nối sẽ được gửi qua Facebook inbox khi bạn tham gia sự kiện. 
        <br /><br />
        <CustomDescByGame pathname={pathname} />
    </p>
))

const ConnectFacebook = ({
    location,
    senderId,
    onSubmitForm,
    onSyncGameEvents,
    onSubmitCancel
}) => {    
    if (senderId === ''){
        return (
            <div className="box-blockcode box-blockcode-noi">
                <i className="ico-noifb"></i>
                <h3 className="noi-titles">Code sự kiện trên Facebook</h3>
                <ShortDescription />
                <br/>
                <ConnectFacebookForm 
                    paramsInUrl={location.search}
                    onSubmit={onSubmitForm} 
                    onSyncGameEvents={onSyncGameEvents}
                    onCancel={onSubmitCancel} 
                />
            </div>
        )
    }
    return null
}

export default compose(
    withRouter,
    connect((state,{gameId}) => ({
        senderId:getGameSenderId(state,gameId)   
    }),(dispatch,{gameId}) => ({
        onSubmitForm:(cuser,callback) => bindActionCreators(submitConnectFacebook,dispatch)(cuser,gameId,callback),
        onSubmitCancel: bindActionCreators(submitCancel,dispatch),
        onSyncGameEvents:() => bindActionCreators(syncEventsByGame,dispatch)(gameId,!0)
    }))
)(ConnectFacebook);