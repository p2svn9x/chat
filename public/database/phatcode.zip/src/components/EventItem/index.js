import React from 'react';
import EventHeader from '../EventHeader';
import EventDueTime from '../EventDueTime';
import EventReward from '../EventReward';
import EventDescription from '../EventDescription';
import EventItemButton from '../EventItemButton';

function eventClassName(type,isNew){
    if (typeof type !== 'number') type = Number(type);
    let cls = 'box-blockcode';
    if (!!isNew) cls += " box-blockcode-evtnew";
    if (type === 24 || 
        type === 26 || 
        type === 27 || 
        type === 28 || 
        type === 32 || 
        type === 33
    ){
        cls += " box-blockcode-evtfb";
    } else if (
        type === 7 || 
        type === 18
    ){
        cls += " box-blockcode-vip";
    } else if (type === 14){
        cls += " box-blockcode-khtt";
    } else if (type === 9){
        cls += " box-blockcode-sn";
    } else {
        cls += " box-blockcode-blank";
    }
    return cls
}

const EventItem = ({event,gameTitle,gameId}) => {  
    return (
        <div className={eventClassName(event.type,event.is_new)}>
            <EventHeader 
                isNew={event.is_new} 
                title={event.title}
                giftcode={event.giftcode}
                status={event.status}               
            />
            <div className="code-main">
                <EventDueTime 
                    startTime={event.start_time} 
                    endTime={event.end_time} 
                />               
                <EventDescription 
                    status={event.status}
                    message={event.message}
                    description={event.description}
                    gameTitle={gameTitle}
                 />
                <EventReward reward={event.reward} />               
                <EventItemButton event={event} gameId={gameId} />                 
            </div>            
        </div>
    )  
}

export default EventItem;