import React from 'react';
import {bindActionCreators} from 'redux';
import { connect } from 'react-redux';
import {Form,Input,Button,Select,Option} from 'muicss/react';
import ModalSearchable from './ModalSearchable';
//import Selector from './Selector';
import BlockLoading from '../BlockLoading';
import BlockRetry from '../BlockRetry';
import ErrorBlock from '../ErrorBlock';
import {syncAccountGame,syncCharactersGame} from '../../actions/accounts';
import { submitGiftcode } from '../../actions/submit';

const RowInput = ({children,error}) => {
    return (
        <div className="tt-row">
            {children}
            {error && <div className="rs txt-err">{error}</div>}
        </div>
    )    
}

class SubmitCodeForm extends React.Component {
    constructor(props){
        super(props);
        this.areas = [];
        this.roles = [];        
        this.initRoleId = !1;      
        this.initAreaId = !1;
        this.state = {
            loading:!1,
            areaId:'',
            roleId:'',
            giftcode:props.initValues.giftcode,
            errors:{},
            modal:!1
        }
    }   
    componentWillMount(){
        if (!this.props.accounts) this.props.onSyncAccounts()
    }    
    componentDidMount(){       
        this.onInitAreaId()        
    }
    componentWillUpdate(nextProps,nextState){
        if (this.state.areaId !== nextState.areaId){
            // changed areaId
            this.initRoleId = !1;
            this.roles = [];
            this.onGetRolesId(nextState.areaId) 
         } 
    }
    componentDidUpdate(prevProps){ 
        if (this.props.updated !== prevProps.updated){            
            this.onInitAreaId();
            this.onInitRoleId(this.state.areaId)
        }               
    }   
    onGetRolesId(areaId){        
        const {accounts,onSyncCharacters} = this.props;       
        if (!!accounts && !!accounts[areaId]){
            let characters = accounts[areaId].character;                   
            if (!characters || (!!characters.error && characters.error.code === 501)){ 
                onSyncCharacters(areaId)
            } else {
                this.onInitRoleId(areaId)
            }
        } 
    }
    onInitAreaId(){
        const {accounts} = this.props;
        if (!this.initAreaId && !!accounts && !accounts.error){
            let areas = [];
            for (let areaId in accounts){
                areas.push({
                    value:areaId,
                    label:accounts[areaId].server
                });
            }
            this.initAreaId = !0;
            this.areas = areas;                                         
            this.handleChangeArea(areas.length > 0 ? areas[0].value : '')                          
        }       
    }
    onInitRoleId(areaId){
        const {accounts} = this.props;               
        if (
            !this.initRoleId &&
            !!accounts && 
            !!areaId && 
            !!accounts[areaId] && 
            !!accounts[areaId].character            
        ){  
            const characters = accounts[areaId].character;        
            let roles = [];                       
            for (let roleId in characters){
                if (roleId === 'error'){
                    roles.push({
                        value:'',
                        label:characters[roleId].message
                    })
                } else {
                    roles.push({
                        value:roleId,
                        label:characters[roleId]
                    })
                }                
            }  
            this.initRoleId = !0;
            if (roles.length === 0){
                roles = [{value:'',label:'Không có nhân vật nào!'}]
            }
            this.roles = roles;   
            this.handleChangeInput('roleId',roles[0].value)
        }     
    }
    handleSubmit = (e) => {
        e.preventDefault();
        const errors = {};
        const {accounts} = this.props;
        const {roleId,areaId,giftcode,loading} = this.state;
        if (!areaId){
            errors.areaId = 'Bạn chưa chọn server!';
        } else if (!accounts[areaId]) {
            errors.areaId = 'Không có server trong danh mục chọn!';
        }
        if (!roleId){
            errors.roleId = 'Bạn chưa chọn nhân vật!';
        } else if (!!areaId && !!accounts[areaId] && !accounts[areaId].character[roleId]){
            errors.roleId = 'Không có nhân vật trong danh mục chọn!';
        }   
        if (!giftcode){
            errors.giftcode = 'Bạn chưa nhập giftcode!'
        }     
        this.setState({errors});       
        if (!loading && Object.keys(errors).length === 0){             
            this.props.onSubmitForm({area_id:areaId,role_id:roleId,giftcode},this.handleResponse.bind(this))   
        }
    }    
    handleResponse = (response) => {        
        if (!!response.error){
            if (response.code === 1){
                this.setState({loading:!1,errors:{giftcode:response.error}})
            } else {
                this.setState({loading:!1,errors:{server:response.error}})
            }            
        } else {
            const {accounts} = this.props;
            const {areaId,roleId} = this.state;
            const accountInfo = {
                areaId,
                areaName:accounts[areaId].server,
                roleId,
                roleName:accounts[areaId].character[roleId]
            };
            this.props.onSubmitSuccess(accountInfo)
        }
    }
    handleChangeArea(value){
        this.setState({
            areaId:value,
            roleId:''
        })
    }
    handleChangeInput(name,value){
        this.setState({
            [name]:value
        })
    }
    showModalSearchable(){
        this.setState({modal:!0})
    }
    render(){
        const {sync,error,accounts,onSyncAccounts} = this.props;
        const {roleId,areaId,giftcode,errors,modal,loading} = this.state; 
        const {areas,roles} = this;
        const enableSearchable = areas.length > 10;    
            
        if (sync){
            return (                
                <BlockLoading />                
            )
        }  else if (!!error.message){                
            return (   
                <BlockRetry error={error} onRetry={() => onSyncAccounts()} /> 
            )
        } else if (!accounts){
            return null
        } else if (!!accounts.error){
            return (
                <div className="box-napthe">
                    <ErrorBlock message={accounts.error.message} />
                </div>
            )            
        }           
        return (
            <div className="box-napthe">
                {loading && (<div className="f-loading" style={{top:0,left:0}} />)}
                <ModalSearchable 
                    show={enableSearchable && modal} 
                    areas={areas}
                    value={areaId}
                    onSelect={(value) => this.handleChangeArea(value)}
                    onClose={() => this.setState({modal:!1})} 
                />
                <Form onSubmit={this.handleSubmit}>
                    {!!errors.server && (<p className="txt-noticer">{errors.server}</p>)}
                    <RowInput error={errors.areaId}> 
                        <div>                       
                            <Select                            
                                label="Tên Server"
                                    value={areaId} 
                                    onClick={(e) => {
                                        if(enableSearchable){
                                            e.preventDefault()
                                            this.showModalSearchable()
                                        }
                                    }} 
                                    onChange={(e) => this.handleChangeArea(e.target.value)}
                            >                                
                                {areas.map(area => (
                                    <Option key={area.value} value={area.value} label={area.label} />
                                ))}
                            </Select>
                            {enableSearchable && (
                                <a onClick={() => this.showModalSearchable()} style={{
                                    position:'absolute',left:0,top:0,bottom:0,right:0,cursor:'pointer'}}>
                                </a>
                            )} 
                        </div>
                    </RowInput> 
                    <RowInput error={errors.roleId}>
                        <Select label="Tên nhân vật" value={roleId} onChange={(e) => this.handleChangeInput('roleId',e.target.value)}>
                            {roles.map(role => (
                                <Option key={role.value || 'role'} value={role.value} label={role.label} />
                            ))} 
                        </Select>                      
                    </RowInput>
                    <RowInput error={errors.giftcode}>
                        <Input 
                            value={giftcode} 
                            onChange={(e) => this.handleChangeInput('giftcode',e.target.value)}
                           
                            label="Giftcode"
                            floatingLabel={!0}
                        />
                    </RowInput>                
                    <Button className={`f-btn-orage f-btn-oragedh f-btn-100 ${!!areaId && !!roleId && !!giftcode ? '' : 'disabled'}`}>Tiếp tục</Button>
                </Form>
            </div>
        )
    }
}

export default connect((state,{gameId}) => ({      
    sync:state.accounts.sync,
    error:state.accounts.error,
    accounts:state.accounts.data[gameId] || null,
    updated:state.accounts.updated   
}),(dispatch,{gameId}) => ({
    onSyncAccounts:() => bindActionCreators(syncAccountGame,dispatch)(gameId),
    onSyncCharacters:(areaId) => bindActionCreators(syncCharactersGame,dispatch)(gameId,areaId),
    onSubmitForm:(data,callback) => bindActionCreators(submitGiftcode,dispatch)({game_id:gameId,...data},callback)
}))(SubmitCodeForm);

SubmitCodeForm.defaultProps = {
    onSubmitSuccess: () => {}
}