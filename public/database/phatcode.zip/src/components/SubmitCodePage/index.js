import React from 'react';
// import {connect} from 'react-redux';
// import {compose} from 'redux';
//import {Redirect} from 'react-router-dom';
import withGame from '../withGame';
import HeaderGameDetail from '../HeaderGameDetail';
import SubmitCodeForm from './SubmitCodeForm';
import Helmet from '../Helmets';
import { selectAccountGamePage } from '../../constants/meta';
import BlockTextKM from '../BlockTextKM';

class SubmitCodePage extends React.Component { 
    render(){ 
        const {gameInfo,location:{state,pathname},history} = this.props;
        let giftcode = '';   
        if (!!state && typeof state === 'object'){
            giftcode = state.giftcode || ''
        }
        // if (gameInfo.isRedeem){
        //     return <Redirect to={`/${gameInfo.alias}`} />
        // }     
        return ( 
            <div style={{height:'100%'}}>
                <Helmet meta={selectAccountGamePage} />
                <div id="content-wrapper">
                    <div className="box-main">
                        <HeaderGameDetail gameIcon={gameInfo.icon} gameTitle={gameInfo.title} />
                        <BlockTextKM pathname={pathname} />
                        <SubmitCodeForm 
                            gameId={gameInfo.id} 
                            initValues={{giftcode}} 
                            onSubmitSuccess={(accountInfo) => history.push({
                                pathname:`/${gameInfo.alias}/nhapcode/success`,
                                state:accountInfo
                            })}
                        />
                    </div>
                </div>
            </div>         
        )
    }
} 

export default withGame(SubmitCodePage);