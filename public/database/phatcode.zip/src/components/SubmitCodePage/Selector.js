import React from 'react';
import {Select, Option} from 'muicss/react';
import {RowInput} from './SubmitCodeForm';
import ModalSearchable from './ModalSearchable';

const Characters = ({value,onChange,characters}) => {
    if (!characters){
        return (
            <Select label="Tên nhân vật">
                <Option value="" label="" />
            </Select>
        )
    } else if (!!characters.error){
        return (
            <Select label="Tên nhân vật">
                <Option value="" label={characters.error.message} />
            </Select>
        )
    }
    return (
        <Select name="roleId" label="Tên nhân vật" value={value} onChange={onChange}>
            {Object.keys(characters).map((key) => (
                <Option key={key} value={key} label={characters[key]} />
            ))}
        </Select>
    )
}

class Selector extends React.Component {
    constructor(){
        super();       
        this.initialCharacters = !1;
    }       
    componentDidMount(){
        const {accounts,onChangeValue} = this.props;
        if (!accounts.error){
            let areaId = Object.keys(accounts)[0];  
            onChangeValue({areaId}) 
        }
    }        
    componentDidUpdate(prevProps){
        const {onSyncCharacters,accounts,values:{areaId}} = this.props;        
        if (areaId !== prevProps.areaId){
            if (!!accounts[areaId]){
                let characters = accounts[areaId].character;
                this.initialCharacters = !0;
                if (!characters || (characters.error && characters.error.code === 501)){                    
                    onSyncCharacters(areaId)
                } 
            }
        }
        if (!!areaId && !!accounts[areaId] && !!accounts[areaId].character && this.initialCharacters){
            this.initialCharacters = !1;
            let roleId = Object.keys(accounts[areaId].character)[0];            
            this.setState({roleId:roleId !== 'error' ? roleId : ''})           
        }       
    }  
    changeArea(value){
        this.props.onChangeValue({
            areaId:value,
            roleId:''
        })
    }
    changeRole(value){
        this.props.onChangeValue('roleId',value)        
    }
    showModalSearchable(){
        this.setState({modal:!0})
    }
    render(){
        const {
            accounts,
            enableSearchable,
            errors
        } = this.props;
        const {areaId,roleId} = this.props.values;
        const characters = !!accounts[areaId] ? accounts[areaId].character : null;       
        if (accounts.error){
            return (
                <div className="txt-err" style={{padding:'15px'}}>
                    {accounts.error.message}
                </div>
            )
        }        
        return (            
            <div>                
                <RowInput error={errors.areaId}> 
                    <div>                       
                        <Select                            
                            label="Tên Server"
                                value={areaId} 
                                onClick={(e) => {
                                    if(enableSearchable){
                                        e.preventDefault()
                                        this.showModalSearchable()
                                    }
                                }} 
                                onChange={(e) => this.changeArea(e.target.value)}
                        >
                            {Object.keys(accounts).map((key) => (
                                <Option key={key} value={key} label={accounts[key].server} />
                            ))}
                        </Select>
                        {enableSearchable && (
                            <a onClick={() => this.showModalSearchable()} style={{
                                position:'absolute',left:0,top:0,bottom:0,right:0,cursor:'pointer'}}>
                            </a>
                        )} 
                    </div>
                </RowInput> 
                <ModalSearchable 
                    show={this.state.modal} 
                    accounts={accounts}
                    value={areaId}
                    onSelect={(value) => this.changeArea(value)}
                    onClose={() => this.setState({modal:!1})} 
                />                
                <RowInput error={errors.roleId}>
                    <Characters 
                        value={roleId} 
                        onChange={(e) => this.changeRole(e.target.value)} 
                        characters={characters} 
                    />
                </RowInput>
            </div>    
        )
    }
}
export default Selector;