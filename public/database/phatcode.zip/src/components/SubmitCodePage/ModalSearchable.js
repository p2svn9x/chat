import React from 'react';
import {Input} from 'muicss/react';

function convertTextToLatin(str){
    if (!str) return ''; 
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/gi, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/gi, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/gi, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/gi, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/gi, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/gi, "y");
    str = str.replace(/đ/gi, "d");
    // Some system encode vietnamese combining accent as individual utf-8 characters
    str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ""); // Huyền sắc hỏi ngã nặng 
    str = str.replace(/\u02C6|\u0306|\u031B/g, ""); // Â, Ê, Ă, Ơ, Ư  
    return str
} 

const SearchResults = ({results,value,onSelect,onClose}) => {
    if (results.length === 0){
        return <div>Không có kết quả nào!</div>
    }
    return (
        <React.Fragment>
            {results.map((option) => (
                <a className={`result ${option.value === value ? 'active' : ''}`} onClick={() => {onSelect(option.value);onClose()}} key={option.value}>{option.label}</a>
            ))}
        </React.Fragment>
    )
}

class ModalSearchable extends React.Component { 
    constructor(props){
        super();
        this.options = props.areas;
        this.state = {
            query:'',
            results:props.areas
        }
    }       
    componentWillReceiveProps(nextProps){
        if (nextProps.areas.length !== this.props.areas.length){
            this.options = nextProps.areas;            
            this.setState({results:nextProps.areas})
        }
    }
    componentWillUpdate(nextProps,nextState){
        if ((nextState.query !== this.state.query) && !!this.options){
            let query = convertTextToLatin(nextState.query);
            if (!!query){
                try {
                    query = query.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');                    
                    const regex = new RegExp(query,'gi');
                    const filterOpts = this.options.filter((option) => {
                        let label = convertTextToLatin(option.label)
                        return !!label.match(regex)
                    })               
                    this.setState({results:filterOpts})
                } catch(err){
                    console.error(err);
                    this.setState({results:this.options}) 
                }
                
            } else {
                this.setState({results:this.options})
            }            
        }
    }    
    render(){
        const {show,areas,onSelect,onClose,value} = this.props;
        const {query,results} = this.state;
        if (!show || areas.length === 0){
            return null
        }      
        return (
            <div style={{position:'fixed',left:0,right:0,top:0,bottom:0,zIndex:100}}>
                <div style={{position:'fixed',background:'#000',opacity:'0.5',left:0,right:0,top:0,bottom:0,zIndex:30}} onClick={() => onClose()}></div>
                <div className="searchable-modal">
                    <div className="header-searchable">
                        Tên server
                        <a className="close" onClick={() => onClose()}>{`\u00D7`}</a>
                    </div>
                    <div className="body-searchable">
                        <div className="input-searchable">
                            <Input value={query} placeholder="Tìm kiếm" onChange={(e) => this.setState({query:e.target.value})} />
                        </div>
                        <div className="searchable-results">
                            <SearchResults results={results} value={value} onSelect={onSelect} onClose={onClose} />                            
                        </div>                    
                    </div>
                </div>
                
            </div>
        )
    }
}

export default ModalSearchable;