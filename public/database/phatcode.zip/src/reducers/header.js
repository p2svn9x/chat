import {SET_HEADER_TITLE} from '../constants/headerType';
const initState = {
    title:''   
}
export default function meta(state=initState,action={}){
    switch(action.type){
        case SET_HEADER_TITLE:
        return {
            title:action.title           
        }        
        default: return state
    }
}