import {GET_GAMES_INFO} from '../constants/gamesType';
export default function games(state = [], action = {}){
	switch (action.type){
		case GET_GAMES_INFO: 
		return action.data			
		default: return state;
	}
} 