import {
    SYNC_EVENTS,
    CANCEL_SYNC_EVENTS,
    SYNC_ERROR_EVENTS,
    MERGE_DATA_EVENTS
} from '../constants/eventsType';

const initState = {
    sync:!1,
    error:{},
    data:{
        // [gameid]:{
        //     sender_id:,
        //     events:
        // }
    },
    lastUpdated:null
}

export default function events(state=initState,action={}){
    switch(action.type){
        case SYNC_EVENTS:
        return {
            ...state,
            sync:!0,
            error:{}            
        }
        case SYNC_ERROR_EVENTS:
        return {
            ...state,
            sync:!1,
            error:action.error
        }
        case CANCEL_SYNC_EVENTS:
        return {
            ...state,
            sync:!1
        }
        case MERGE_DATA_EVENTS:
        return {
            ...state,
            sync:!1,
            data:action.payload.data,
            lastUpdated:Date.now()
        }
        default: return state
    }    
}