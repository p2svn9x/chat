import {MERGE_DATA_GUIDES} from '../constants/guidesType';

const initState = {
    sync:!1,
    error:{},
    data:[]
}

export default function guides(state=initState,action={}){
    switch(action.type){
        case MERGE_DATA_GUIDES:
        return {
            ...state,
            sync:!1,
            data:action.data
        }
        default: return state
    }
}