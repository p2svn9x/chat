import {
    SYNC_ACCOUNT_GAME,
    SYNC_CANCEL_ACCOUNT,
    SYNC_ERROR_ACCOUNT,
    MERGE_DATA_ACCOUNT,    
    REMOVE_ALL_ACCOUNT
} from '../constants/accountsType';
const initState = {
    sync:!1,
    error:{},
    data:{},
    updated:null
};

export default function accounts(state=initState,action={}){
    switch (action.type){
        case SYNC_ACCOUNT_GAME:
        return {
            ...state,
            sync:!0,
            error:{}
        }
        case SYNC_CANCEL_ACCOUNT:
        return {
            ...state,
            sync:!1
        }
        case SYNC_ERROR_ACCOUNT:
        return {
            ...state,
            sync:!1,
            error:action.error
        }
        case MERGE_DATA_ACCOUNT:        
        return {
            ...state,
            sync:!1,
            data:action.payload.data,
            updated:Date.now()
        }
        case REMOVE_ALL_ACCOUNT:
        return initState
        default: return state
    }
}