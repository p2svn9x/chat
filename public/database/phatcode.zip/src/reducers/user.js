import {
	USER_LOGGED,
	USER_MERGE_DATA,
	SYNC_USERINFO,
	CANCEL_SYNC_USERINFO
} from '../constants/userType';
const initState = {
	sync:!1,
	money:0,
	funcoin:0	
}
export default function user(state=initState, action = {}){
	switch (action.type){
		case SYNC_USERINFO:
		return {
			...state,
			sync:!0
		}
		case CANCEL_SYNC_USERINFO:
		return {
			...state,
			sync:!1
		}
		case USER_LOGGED: 
		return {
			...state,
			...action.user,
			sync:!1
		}
		case USER_MERGE_DATA:
		return action.data
		
		default: return state
	}
} 