import { combineReducers } from 'redux';
import user from './user';
import games from './games';
import header from './header';
import guides from './guides';
import events from './events';
import purchase from './purchase';
import accounts from './accounts';
//import games from './games';
export default combineReducers({
    userInfo: user,
    accounts,
    games,
    header,
    guides,
    events,
    purchase    
});