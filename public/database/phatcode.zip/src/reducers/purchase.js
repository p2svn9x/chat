import {
    SYNC_PURCHASE_EVENTS,
    SYNC_ERROR_PURCHASE,
    SYNC_CANCEL_PURCHASE,
    MERGE_PURCHASE_EVENTS
} from '../constants/purchaseType';
const initState = {
    sync:!1,
    error:{},
    data:{},
    lastUpdated:null
}
export default function purchase(state=initState,action={}){
    switch(action.type){
        case SYNC_PURCHASE_EVENTS:
        return {
            ...state,
            sync:!0,
            error:{}
        }
        case SYNC_ERROR_PURCHASE:
        return {
            ...state,
            sync:!1,
            error:action.error
        }
        case SYNC_CANCEL_PURCHASE:
        return {
            ...state,
            sync:!1
        }
        case MERGE_PURCHASE_EVENTS:
        return {
            ...state,
            sync:!1,
            data:action.payload.data,
            lastUpdated:Date.now()
        }
        default: return state
    }
}