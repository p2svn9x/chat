import {
    SYNC_PURCHASE_EVENTS,
    SYNC_ERROR_PURCHASE,
    SYNC_CANCEL_PURCHASE,
    MERGE_PURCHASE_EVENTS,
    EDIT_PURCHASE_EVENT
} from '../constants/purchaseType';

export const syncPurchaseEventByGame = (gameId) => ({
    type:SYNC_PURCHASE_EVENTS,
    payload:{gameId}
})

export const syncErrorPurchase = (error) => ({
    type:SYNC_ERROR_PURCHASE,
    error
})

export const syncCancelPurchase = () => ({
    type:SYNC_CANCEL_PURCHASE    
})

export const mergePurchaseEvents = (data) => ({
    type:MERGE_PURCHASE_EVENTS,
    payload:{data}
})

export const editPurchaseEventByGame = (gameId,eventId) => ({
    type:EDIT_PURCHASE_EVENT,
    payload:{
        gameId,
        eventId
    }    
})