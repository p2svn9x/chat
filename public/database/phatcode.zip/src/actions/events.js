import {
    SYNC_EVENTS,
    SYNC_ERROR_EVENTS,
    CANCEL_SYNC_EVENTS,
    REMOVE_EVENT,
    EDIT_EVENT,
    MERGE_DATA_EVENTS
} from '../constants/eventsType';

export const syncEventsByGame = (gameId,resync) => ({
    type:SYNC_EVENTS,
    payload:{gameId},
    meta:{resync}
})
export const syncEventError = (error) => ({
    type:SYNC_ERROR_EVENTS,
    error
})
export const cancelSyncEvents = () => ({
    type:CANCEL_SYNC_EVENTS    
})
export const removeEventByGame = (gameid,eventid) => ({
    type:REMOVE_EVENT,
    gameid,
    eventid 
})
export const editEventByGame = (gameId,eventId,data) => ({
    type:EDIT_EVENT,
    payload:{data,gameId,eventId}    
})
export const mergeDataEvents = (data) => ({
    type:MERGE_DATA_EVENTS,
    payload:{data}
})