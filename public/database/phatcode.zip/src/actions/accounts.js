import {
    SYNC_ACCOUNT_GAME,
    SYNC_CHARACTERS_GAME,
    SYNC_CANCEL_ACCOUNT,
    SYNC_ERROR_ACCOUNT,
    MERGE_DATA_ACCOUNT,    
    REMOVE_ALL_ACCOUNT,
    REMOVE_ACCOUNT_GAME
} from '../constants/accountsType';

export const syncAccountGame = (gameId) => ({
    type:SYNC_ACCOUNT_GAME,
    payload:{gameId}    
})
export const syncCharactersGame = (gameId,areaId) => ({
    type:SYNC_CHARACTERS_GAME,
    payload:{
        gameId,
        areaId
    }    
})
export const syncCancelAccount = () => ({
    type:SYNC_CANCEL_ACCOUNT    
})
export const syncErrorAccount = (error) => ({
    type:SYNC_ERROR_ACCOUNT,
    error
})
export const mergeDataAccount = (data) => ({
    type:MERGE_DATA_ACCOUNT,
    payload:{data}    
})
export const removeAllAccount = () => ({
    type:REMOVE_ALL_ACCOUNT    
})
export const removeAccountGame = (gameid) => ({
    type:REMOVE_ACCOUNT_GAME,
    gameid    
})