import {
    SYNC_USER_WALLET,    
    SYNC_USERINFO,
    CANCEL_SYNC_USERINFO,
    USER_LOGGED,
    USER_LOGOUT,
    USER_MERGE_DATA,    
    MINUS_FUNCOIN_USER,
    MINUS_THOC_USER
} from '../constants/userType';

export const syncWallet = () => ({
    type:SYNC_USER_WALLET
})
export const syncUserInfo = () => ({
    type:SYNC_USERINFO    
})
export const cancelSyncUserInfo = () => ({
    type:CANCEL_SYNC_USERINFO    
})
export const userLogged = (user) => ({
    type:USER_LOGGED,
    user
})
export const userLogout = () => ({
    type:USER_LOGOUT    
})
export const mergeDataUser = (data) => ({
    type:USER_MERGE_DATA,
    data   
})
export const minusFuncoinUser = (funcoin) => ({
    type:MINUS_FUNCOIN_USER,
    funcoin    
})
export const minusThocUser = (thoc) => ({
    type:MINUS_THOC_USER,
    thoc    
})