import {GET_GIFTCODE_EVENT,GET_GIFTCODE_PURCHASE} from '../constants/giftcodeType';

export const getGiftcodeByEventId = (eventId,gameId,callback) => ({
    type:GET_GIFTCODE_EVENT,
    payload:{eventId,gameId},
    meta:{callback}
})

export const getGiftcodePurchaseByEventId = (eventId,gameId,callback) => ({
    type:GET_GIFTCODE_PURCHASE,
    payload:{eventId,gameId},
    meta:{callback}
})