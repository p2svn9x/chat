import {GET_GAMES_INFO} from '../constants/gamesType';

export const getGamesInfo = (data) => ({
    type:GET_GAMES_INFO,
    data
})