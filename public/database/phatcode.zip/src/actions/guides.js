import {MERGE_DATA_GUIDES} from '../constants/guidesType';

export const mergeDataGuides = (data) => ({
    type:MERGE_DATA_GUIDES,
    data
}) 