import {SET_HEADER_TITLE} from '../constants/headerType';

export const setHeaderTitle = (title) => ({
    type:SET_HEADER_TITLE,
    title
})