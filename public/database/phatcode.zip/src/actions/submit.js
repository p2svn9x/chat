import {SUBMIT_CONNECT_FACEBOOK, SUBMIT_GIFTCODE, SUBMIT_CANCEL} from '../constants/submitType'; 

export const submitConnectFacebook = (cuser,gameId,callback) => ({
    type:SUBMIT_CONNECT_FACEBOOK,
    payload:{
        cuser,
        gameId
    },
    meta:{callback} 
})

export const submitGiftcode = (data,callback) => ({
    type:SUBMIT_GIFTCODE,
    payload:data,
    meta:{callback}
})

export const submitCancel = () => ({
    type:SUBMIT_CANCEL
})