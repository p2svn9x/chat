export default function empty(){
    return {type:'EMPTY_ACTION'}
}