import React from 'react';
import { Switch, withRouter} from 'react-router';
import GuideDetailPage from './components/GuideDetailPage';
import { PublicRoute, AuthRoute } from './components/TransitionRoute';
import SubmitCodePage from './components/SubmitCodePage';
import NotFound from './components/NotFound';
import EventsPage from './components/EventsPage';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import Header from './components/Header';
import SuccessPage from './components/SuccessPage';
import { 
  HOME_TITLE, 
  GUIDE_TITLE,
  GAME_TITLE, 
  SUBMIT_CODE_TITLE 
} from './constants/headerTitle';


class App extends React.Component { 
  componentWillMount(){
    const {location,history} = this.props;    
    history.push('/');
    try {
      history.push(location);
    } catch(err){}   
    history.listen(() => {      
        window.scrollTo(0,0)     
    })
  } 
  render() {
    //<Authenticated path="/:alias/chonnhanvat" exact component={PickComponent} /> 

    //<TransitionRoute path="/:alias/nhapcode" exact component={PickComponent} auth={!0} />  
    return (
      <div>
        <Header />
        <Switch>
          <PublicRoute path="/" exact component={HomePage} title={HOME_TITLE} />  
          <PublicRoute path="/huong-dan" exact component={GuideDetailPage} title={GUIDE_TITLE} /> 
          <AuthRoute path="/:alias" exact component={EventsPage} title={GAME_TITLE} />     
          <AuthRoute path="/:alias/nhapcode" exact component={SubmitCodePage} title={SUBMIT_CODE_TITLE} />       
          <AuthRoute path="/:alias/nhapcode/success" exact component={SuccessPage} /> 
          <PublicRoute component={NotFound} />
        </Switch>
        <Footer />
      </div>  
    );
  }
}
export default withRouter(App);
